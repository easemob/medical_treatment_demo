<?php
return array(
    "TITLE" => '标题',
    "DESCRIPTION" => '描述',
    "LINK" => '链接',
    "IMAGE" => '图片',
    "VIEW" => '查看',
    "ALL" => '全部'
);