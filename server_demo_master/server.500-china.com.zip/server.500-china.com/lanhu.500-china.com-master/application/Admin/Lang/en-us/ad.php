<?php
return array(
    "NAME" => "Ad Name",
    "HOW_TO_USE" => 'How to Use',
    "AD_CONTENT" => "Ad Content"
);