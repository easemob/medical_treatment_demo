<?php
namespace User\Controller;

use Common\Controller\HomebaseController;
use Think\Easemob;
class ConsultationController extends HomebaseController {
	protected $consultation_model; 
	protected $consumessgae_model; 
	protected $easemob; 
	
	public function _initialize() {
		parent::_initialize();
		$this->consultation_model = M("Consultation");
		$this->consumessgae_model = M("ConsultationMessage");
		$options['client_id'] = 'YXA61epvIH7aEeaqXJfnedRFiQ';
		$options['client_secret'] = 'YXA6j79LmoNuaMRs78ztKWt_0tOs4_c'; 
		$options['org_name'] = 'comcaesar';
		$options['app_name'] = 'ecchat'; 
		$this->easemob = new Easemob($options);
	}

	// 获取一个用户加入的所有聊天室
	public function getEasemobRooms() {
		$userid=I('post.userid',2,'intval');
		$userdata=M('Users')->where(array('id'=>$userid))->find();
		$result_ease = $this->easemob->getChatRoomJoined($userdata['user_login']);
		if($result_ease){
			$this->successJson("获取用户聊天室成功！",$result_ease);
		}else{
			$this->errorJson("获取用户聊天室失败！");
		}
	}
	//获取一个聊天室的详情
	public function getEasemobRoomDetail() {
		$chatroom_id=I('post.chatroom_id');
		$result_ease = $this->easemob->getChatRoomDetail($chatroom_id);
		if($result_ease){
			$this->successJson("获取聊天室详情成功！",$result_ease);
		}else{
			$this->errorJson("获取聊天室详情失败！");
		}
	}

	// 发送环信聊天室消息
	public function getAllEasemobChats() {
		$result_ease = $this->easemob->getChatRooms();
		if($result_ease){
			$this->successJson("导出环信聊天记录成功！",$result_ease);
		}else{
			$this->errorJson("导出聊天记录失败！");
		}
	}
	// 发送环信聊天室消息
	public function sendEasemobMessage() {

	}

	// 导出环信聊天室聊天记录
	public function getEaseChatRecord() {
		$sql="select+*+where+timestamp>".time()."000";
		$result_ease = $this->easemob->getChatRecord($sql);
		if($result_ease){
			$this->successJson("导出环信聊天记录成功！",$result_ease);
		}else{
			$this->errorJson("导出聊天记录失败！");
		}
	}

	// 创建环信聊天室
	public function createEasemobRoom() {
		$userid=I('post.userid',2,'intval');
		$memberid=I('post.memberid',3,'intval');
		$userdata=M('Users')->where(array('id'=>$userid))->find();
		$memberdata=M('Users')->where(array('id'=>$memberid))->find();
		if($userdata){
			$owner=$userdata['user_login'];
			$member=$memberdata['user_login'];
			$roomname=$owner.'#'.time();
			$optiones ['name'] = $roomname;
			$optiones ['description'] = $roomname;
			$optiones ['maxusers'] = 2;
			$optiones ['owner'] = $owner;
			$optiones['members']=Array($owner,$member);
			$result_ease = $this->easemob->createChatRoom($optiones);
			if($result_ease){
				if($result_ease['action']){
					$optiones['member']=$member;
					$optiones['createtime'] = date("Y-m-d H:i:s",time());
					$optiones['roomid']=$result_ease['data']['id'];
					$optiones['easemob']=json_encode($result_ease);
					$crid=M("Chatrooms")->add($optiones);
					$this->successJson("环信聊天室创建成功！",$crid);
				}else{
					$this->errorJson("环信聊天室创建失败！");
				}
			}else{
				$this->errorJson("环信聊天室创建失败！");
			}
		}else{
			$this->errorJson("环信聊天室创建失败！");
		}
	}

	// 患者发布新的问诊
	public function postNewConsultationsJson() {
		$userid=I('post.userid',2,'intval');
		$condoc=I('post.docid',3,'intval');
		$contype=I('post.ctype',1,'intval');
		$contitle=I('post.contitle');
		$conphotos=I('post.photos_url');
		if($conphotos){
			$conphotos=htmlspecialchars_decode($conphotos);
		}
		$userdata=M('Users')->where(array('id'=>$userid))->find();
		$memberdata=M('Users')->where(array('id'=>$condoc))->find();
		if($userdata){
			$owner=$userdata['user_login'];
			$member=$memberdata['user_login'];
			$conname=$userdata['user_nicename'];
			$useravatar=$userdata['avatar'];
			$roomname=$owner.'#'.time();
			$optiones ['name'] = $roomname;
			$optiones ['description'] = $roomname;
			$optiones ['maxusers'] = 2;
			$optiones ['owner'] = $owner;
			$optiones['members']=Array($owner,$member);
			$result_ease = $this->easemob->createChatRoom($optiones);
			
			if($result_ease){
				if($result_ease['action']){
					$optiones['member']=$member;
					$optiones['createtime'] = date("Y-m-d H:i:s",time());
					$optiones['roomid']=$result_ease['data']['id'];
					$optiones['easemob']=json_encode($result_ease);
					$crid=M("Chatrooms")->add($optiones);

					if($crid){
						$condata=array(
							'consultation_doc' => $condoc,
							'consultation_author' => $userid,
							'consultation_authorname' =>$conname,
							'consultation_avatar' => $useravatar,
							'consultation_title' => $contitle,
							'createtime' => date("Y-m-d H:i:s",time()),
							'consultation_photos' => $conphotos,
							'consultation_type' => $contype,
							'crid' => $crid,
							'chatroomid' => $optiones['roomid'],
							'chatroomname' => $roomname
						);
						$conid=$this->consultation_model->add($condata);
						if($conid){
							$this->successJson("患者问诊发布成功",$conid);
						}else{
							$this->errorJson("患者问诊发布失败！");
						}
					}else{
						$this->errorJson("问诊创建失败！");
					}
				}else{
					$this->errorJson("问诊创建失败！");
				}
			}else{
				$this->errorJson("问诊创建失败！");
			}
		}else{
			$this->errorJson("问诊创建失败！");
		}
	}
	

	// 获取首页推荐医生列表
	public function getRecommendDoctors() {
		$keyword=I('post.keyword');
		if(isset($keyword)){
			$keyword_complex=array();
			$keyword_complex['d.docname'] = array('like', "%$keyword%");
			$keyword_complex['d.doclevel'] = array('like', "%$keyword%");
			$keyword_complex['d.dochospital'] = array('like', "%$keyword%");
			$keyword_complex['d.docpartment']  = array('like',"%$keyword%");
			$keyword_complex['d.doctag']  = array('like',"%$keyword%");
            $keyword_complex['_logic'] = 'or';
            $where['_complex'] = $keyword_complex;
		}
		$join = '__USER_DOCTOR__ as d on user.id = d.uid';
		$fields='d.uid,d.docname,user.user_login,user.avatar,d.doclevel,d.dochospital,d.docpartment,d.doctag,d.docexpert,d.docconsultation,d.docresponse,d.docfootprice';
		$where['user.user_type']=3;
		$where['d.doc_status']=2;
		$where['d.con_state']=1;
		$recommenddocs=M("Users")
		->alias("user")
		->join($join,'LEFT')
		->field($fields)
		->where($where)
		->order(array("user.id" => "DESC"))
		->select();
		// echo M()->getLastSql();exit;
		if($recommenddocs){
			$this->successJson("获取推荐医生列表成功!",$recommenddocs);
		}else{
			$this->errorJson("暂无匹配推荐医生！");
		}
	}
	
	// 获取患者问诊列表
	public function getPatConsultations() {
		$condoc=I('post.userid',1,'intval');
		$where['consul.consultation_doc']=$condoc;
		$where['consul.status']=1;
		$where['consul.crid']=array('neq',0);
		$join = '__CONSULTATION_MESSAGE__ as conmessage on consul.id = conmessage.consultation_id';
		$consultation_list=$this->consultation_model
		->alias("consul")
		->join($join,'LEFT')
		->where($where)
		->order(array("consul.id" => "DESC"))
		->select();
		if($consultation_list){
			foreach ($consultation_list as $key=>$value){
				$consultation_list[$key]['consultation_photos']=json_decode($value['consultation_photos'], true);
			}
			$this->successJson("获取患者问诊列表成功!",$consultation_list);
		}else{
			$this->errorJson("暂无患者问诊！");
		}
    }
	
	// 获取问诊的医生列表
	public function getDocConsultations() {
		$userid=I('post.userid',1,'intval');
		$where['consul.consultation_author']=$userid;
		$where['consul.status']=1;
		$where['consul.crid']=array('neq',0);
		$join = '__USER_DOCTOR__ as d on consul.consultation_doc = d.uid';
		$join1 = '__USERS__ as user on user.id = d.uid';
		$join2 = '__CONSULTATION_MESSAGE__ as conmessage on consul.id = conmessage.consultation_id';
		$fields='d.uid,d.docname,user.avatar,d.doclevel,d.docpartment,consul.consultation_title,consul.consultation_photos,consul.createtime,
		consul.consultation_type,consul.consultation_status,consul.chatroomid,consul.chatroomname,conmessage.*';
		$consultation_list=$this->consultation_model
		->alias("consul")
		->join($join,'LEFT')
		->join($join1)
		->join($join2)
		->field($fields)
		->order(array("consul.id" => "DESC"))
		->where($where)->select();
		if($consultation_list){
			foreach ($consultation_list as $key=>$value){
				$consultation_list[$key]['consultation_photos']=json_decode($value['consultation_photos'], true);
			}
			$this->successJson("获取问诊列表成功!",$consultation_list);
		}else{
			$this->errorJson("您暂未发布过问诊！");
		}

	}

	// 患者发布新的问诊
	public function postConsultationsJson() {
		$userid=I('post.userid',2,'intval');
		$condoc=I('post.docid',1,'intval');
		$conname=I('post.username');
		$useravatar=I('post.useravatar');
		$contitle=I('post.contitle');
		$conphotos=I('post.photos_url');
		if($conphotos){
			$conphotos=htmlspecialchars_decode($conphotos);
		}
		$contype=I('post.ctype',1,'intval');
		$data=array(
	        'consultation_doc' => $condoc,
	        'consultation_author' => $userid,
	        'consultation_authorname' =>$conname,
			'consultation_avatar' => $useravatar,
			'consultation_title' => $contitle,
			'createtime' => date("Y-m-d H:i:s",time()),
			'consultation_photos' => $conphotos,
			'consultation_type' => $contype
	    	);
		$resid=$this->consultation_model->add($data);
		if($resid){
			$data['consultation_id']=$resid;
			$this->successJson("患者问诊发布成功",$data);
		}else{
			$this->errorJson("患者问诊发布失败！");
		}
	}
	
	// 关联问诊详情
	public function postConsuMessageJson() {
		$conid=I('post.conid',1,'intval');
		$realname=I('post.realname');
		$idnumber=I('post.idnumber');
		$patgenderd=I('post.genderd');
		$patbirthday=I('post.birthday');
		$patweight=I('post.weight');
		$patallergic=I('post.allergic');
		$patfall=I('post.fall');
		$patliver=I('post.liver');
		$patkidney=I('post.kidney');
		$patappointday=I('post.appointday');
		if(empty($patappointday)){
			$patappointday=Date('Y-m-d H:i:s', time());
		}
		$data=array(
			'consultation_id' => $conid,
			'patient_realname' => $realname,
			'patient_idnumber' => $idnumber,
			'patient_genderd' => $patgenderd,
			'patient_birthday' => $patbirthday,
			'patient_weight' => $patweight,
			'patient_allergic' => $patallergic,
			'patient_fall' => $patfall,
			'patient_liver' => $patliver,
			'patient_kidney' => $patkidney,
			'patient_appointday' => $patappointday,
			);

		$this->consultation_model->where(array('id'=>$conid))->save(array('status'=>1));
		
		$resid=$this->consumessgae_model->add($data);
		if($resid){
			$where['consul.status']=1;
			$where['consul.crid']=array('neq',0);
			$where['conmessage.mid']=$resid;
			$join = '__USER_DOCTOR__ as d on consul.consultation_doc = d.uid';
			$join1 = '__USERS__ as user on user.id = d.uid';
			$join2 = '__CONSULTATION_MESSAGE__ as conmessage on consul.id = conmessage.consultation_id';
			$fields='d.uid,d.docname,user.avatar,d.doclevel,d.docpartment,consul.consultation_title,consul.consultation_photos,consul.createtime,
			consul.consultation_type,consul.consultation_status,consul.chatroomid,consul.chatroomname,conmessage.*';
			$consultation_data=$this->consultation_model
			->alias("consul")
			->join($join,'LEFT')
			->join($join1)
			->join($join2)
			->field($fields)
			->where($where)->find();
			$consultation_data['consultation_photos']=json_decode($consultation_data['consultation_photos'], true);
			$this->successJson("关联问诊发布成功",$consultation_data);
		}else{
			$this->errorJson("关联问诊发布失败！");
		}
	}
	
	// 更新问诊信息
	public function updateConsultationStatus() {
		$conid=I('post.conid',1,'intval');
		$restatus=I('post.restatus',2,'intval');
		$consuldata['consultation_status']=$restatus;
		$consuldata['consultation_modified']=Date('Y-m-d H:i:s', time());
		$conres=$this->consultation_model->where(array('id'=>$conid))->save($consuldata);
		if($conres){
			$this->successJson("更新问诊信息成功",$conres);
		}else{
			$this->errorJson("更新问诊信息失败！");
		}

	}
}
