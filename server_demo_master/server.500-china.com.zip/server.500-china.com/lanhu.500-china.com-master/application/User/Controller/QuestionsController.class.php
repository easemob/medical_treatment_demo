<?php
namespace User\Controller;

use Common\Controller\HomebaseController;

class QuestionsController extends HomebaseController {
	
    // 问答中心列表
	public function indexPsersonalQuestionDataJson() {
		$questions_owner=I('questions_owner',1);
		$question_model=M("Questions");
		$qoods_model=M("Goods");
		$question_list=$question_model->where(array("state"=>1,"questions_owner"=>$questions_owner))->select();
		$goods_field='goods_id,goods_name,shop_price,goods_img';
		if($question_list){
			foreach ($question_list as $key => $value) {
    			if(!empty($value['goods_id'])){
					$goods_data=$qoods_model->field($goods_field)->where(array("goods_id"=>$value['goods_id']))->find();
					$question_list[$key]['goods_data']=$goods_data;
				}
			}
		}
		$this->successJson("获取问答列表成功!",$question_list);
    }
	
	// 用户提问列表
	public function indexPsersonalAnswerJson() {
		$comment_author=I('comment_author',1);
		$type=I('type',0,'intval');
		$question_model=M("Questions");
		$quement_model=M("QuestionsComment");
		$field = 'questions_author,questions_authorname,questions_avatar,questions_title,questions_comment.*';
		$order = "createtime DESC";
    	$limit = '0,20';
		$where['comment_author'] = array('eq',$comment_author);
		$where['questions_comment.type'] = array('eq',0);
		$where['questions_comment.status'] = array('eq',1);
		$question_field='id,questions_author,questions_authorname,questions_avatar,questions_title';
		$join = '__QUESTIONS__ as questions on questions_comment.question_id = questions.id';
		$answer_list=$quement_model
    	    ->alias("questions_comment")
    	    ->join($join)
    	    ->field($field)
    	    ->where($where)
    	    ->order($order)
    	    ->limit($limit)
    	    ->select();
		$this->successJson("获取问答列表成功!",$answer_list);
    }
	
	// 问答中心首页
	public function index_json() {
		$question_id=I('question_id',1);
		$question_model=M("Questions");
		$qoods_model=M("Goods");
		$quement_model=M("QuestionsComment");
		$goods_field='goods_id,goods_name,shop_price,goods_img';
		$question_data=$question_model->where(array("id"=>$question_id))->find();
		if($question_data){
			if(!empty($question_data['goods_id'])){
				$goods_data=$qoods_model->field($goods_field)->where(array("goods_id"=>$question_data['goods_id']))->find();
				$question_data['goods_data']=$goods_data;
			}
			$answer_data=$quement_model->where(array("question_id"=>$question_id,"type"=>1))->find();
			if($answer_data){
				$question_data['answer_data']=$answer_data;
			}
			$comment_data=$quement_model->where(array("question_id"=>$question_id,"type"=>0))->select();
			if($comment_data){
				$question_data['comment_data']=$comment_data;
			}
			$question_data['comment_data']=$comment_data;
			$this->successJson("获取问答信息成功!",$question_data);
		}else{
			$this->errorJson("抱歉暂无此提问！");
		}
    }
	
	// 问答中心首页
	public function question_answer_json() {
		$question_id=I('question_id',1);
		$quement_model=M("QuestionsComment");
		$quement_data=$quement_model->where(array("question_id"=>1))->find();
		$this->successJson("获取问答信息成功!",$question_data);
    }
	
	// 问答解答（评论）
	public function post_answer_json() {
		$question_model=M("Questions");
		$type_array = array('评论','解答');
		$question_id=I('question_id',1);
		$question_data=$question_model->where(array("id"=>$question_id))->find();
		if(empty($question_data)){
			$this->errorJson("无此提问！");
		}
		$comment_author=I('comment_author',1);
		$to_uid=I('to_uid',1);
		$content=I('content');
		$type=I('type',0,'intval');
		$parentid=I('parentid');
		$createtime=date("Y-m-d H:i:s",time());
		$users_model=M('Users');
		$quement_model=M("QuestionsComment");
		$users=$users_model->where(array("id"=>$comment_author))->find();
		$data=array(
	        'question_id' => $question_id,
	        'comment_author' => $comment_author,
	        'comment_authorname' =>$users['user_nicename'],
	        'comment_avatar' =>$users['avatar'],
	        'to_uid' => $to_uid,
	        'createtime' => $createtime,
			'content' => $content,
			'type' => $type,
			'parentid' => $parentid
	    	);
		$result=$quement_model->add($data);
		if($result){
			$this->successJson("恭喜，".$type_array[$type]."成功！");
		}else {
			$this->errorJson("抱歉，".$type_array[$type]."失败！");
		}
    }
	
	// 添加问答
	public function post_question_json() {
		$questions_owner=I('questions_owner',1);
		$questions_author=I('questions_author',1);
		$goods_id=I('goods_id',0);
		$questions_title=I('questions_title');
		$createtime=date("Y-m-d H:i:s",time());
		$users_model=M('Users');
		$question_model=M("Questions");
		$users=$users_model->where(array("id"=>$questions_author))->find();
		$data=array(
	        'questions_owner' => $questions_owner,
	        'questions_author' => $questions_author,
	        'questions_authorname' =>$users['user_nicename'],
	        'questions_avatar' =>$users['avatar'],
	        'questions_title' => $questions_title,
	        'createtime' => $createtime,
			'goods_id' => $goods_id,
			'questions_modified' => $createtime
	    	);
		$result=$question_model->add($data);
		if($result){
			$this->successJson("恭喜，提问成功！");
		}else {
			$this->errorJson("抱歉，提问失败！");
		}
    }
}
