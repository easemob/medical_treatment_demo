<?php
namespace User\Controller;

Vendor('JPush.autoload');
use JPush\Client as JPushClient;

use Common\Controller\HomebaseController;

class PublicController extends HomebaseController {
    protected $users_model,$role_model;

	public function _initialize() {
		parent::_initialize();
		$this->users_model = D("Common/Users");
		$this->role_model = D("Common/Role");
	}

	public function sendcalltest() {
		$jpush = new JPushClient(C('JPUSH_APP_KEY'), C('JPUSH_MASTER_SECRET'));
			echo json_encode(array(C('JPUSH_APP_KEY'), C('JPUSH_MASTER_SECRET')));
		$push_payload = $jpush->push()
    	->setPlatform('all')
    	->addAllAudience()
    	->setNotificationAlert('Hi, JPush');
		try {
    	$response = $push_payload->send();
    	print_r($response);
		} catch (\JPush\Exceptions\APIConnectionException $e) {
    	// try something here
    	print $e;
		} catch (\JPush\Exceptions\APIRequestException $e) {
    	// try something here
    	print $e;
		}
	}

	public function sendcallpushing() {
		$userid=I('post.userid');
		$targetid=I('post.targetid');
		// echo json_encode(I('post.'));exit;
		// echo $targetid;exit;
		$users_model=M("Users");
		$field='id,user_login,user_nicename,avatar,trtcuuid';
		$users_info=$users_model->where(array("id"=>$userid))->field($field)->find();
		$target_info=$users_model->where(array("id"=>$targetid))->find();
		$registration_id=$target_info['registrationid'];
		// echo M()->getLastSql();exit;
		if(empty($registration_id)){
			$this->errorJson("目标用户暂未登录！");
		}
		// echo $registration_id;exit;
		$users_trtcuuid=$users_info['trtcuuid'];
		$users_info['roomid']=10000+$userid;
		$users_info['retype']='request';
		$users_info['restate']=1;
		$ptitle="随律App视频请求";
		$pmessage="随律App发来一条视频求助信息";
		$this->sendpushingmessage($ptitle,$pmessage,$registration_id,$users_info);
		$this->successJson("极光推送发送成功！");
  	} 

	public function cancelpushing() {
		$userid=I('post.userid');
		$targetid=I('post.targetid');
		$users_model=M("Users");
		$target_info=$users_model->where(array("id"=>$targetid))->find();
		$registration_id=$target_info['registrationid'];
		$users_info=array();
		$users_info['retype']='request';
		$users_info['restate']=0;
		$ptitle="随律App通话取消";
		$pmessage="随律App取消了求助通话";
		$this->sendpushingmessage($ptitle,$pmessage,$registration_id,$users_info);
		$this->successJson("极光推送发送成功！",$users_info);
	}

	public function receiverpushing() {
		$userid=I('post.userid');
		$targetid=I('post.targetid');
		$users_model=M("Users");
		$field='id,user_login,user_nicename,avatar,trtcuuid';
		$users_info=$users_model->where(array("id"=>$userid))->field($field)->find();
		$target_info=$users_model->where(array("id"=>$targetid))->find();
		$registration_id=$target_info['registrationid'];
		if(empty($registration_id)){
			$this->errorJson("目标用户暂未登录！");
		}
		$users_trtcuuid=$users_info['trtcuuid'];
		$users_info['roomid']=10000+$userid;
		$users_info['retype']='receiver';
		$users_info['restate']=1;
		$ptitle="随律App接受了请求";
		$pmessage="随律App接受了求助信息";
		$this->sendpushingmessage($ptitle,$pmessage,$registration_id,$users_info);
		$this->successJson("极光推送发送成功！");
  	} 

	public function rejectpushing() {
		$userid=I('post.userid');
		$targetid=I('post.targetid');
		$users_model=M("Users");
		$target_info=$users_model->where(array("id"=>$targetid))->find();
		$registration_id=$target_info['registrationid'];
		// echo $registration_id;exit;
		// echo json_encode($target_info);exit;
		$users_info=array();
		$users_info['retype']='receiver';
		$users_info['restate']=0;
		$ptitle="随律App拒绝了请求";
		$pmessage="随律App拒绝了求助信息";
		$this->sendpushingmessage($ptitle,$pmessage,$registration_id,$users_info);
		$this->successJson("极光推送发送成功！",$users_info);
	}

	public function sendpushingmessage($title,$message,$registration_id,$message_info) {
		$jpush = new JPushClient(C('JPUSH_APP_KEY'), C('JPUSH_MASTER_SECRET'));
		$jpush->push()
        ->setPlatform(array('ios', 'android'))
        // 一般情况下，关于 audience 的设置只需要调用 addAlias、addTag、addTagAnd  或 addRegistrationId
        // 这四个方法中的某一个即可，这里仅作为示例，当然全部调用也可以，多项 audience 调用表示其结果的交集
        // 即是说一般情况下，下面三个方法和没有列出的 addTagAnd 一共四个，只适用一个便可满足大多数的场景需求
        ->addRegistrationId($registration_id)
        ->setNotificationAlert("随律App消息")
        ->iosNotification($title, array(
            'sound' => 'sound.caf',
            'category' => 'jiguang',
            'extras' => $message_info,
        ))
        ->androidNotification($title, array(
            'title' => $message,
            'extras' => $message_info,
        ))
        ->message($message, array(
            'title' => $title,
            'content_type' => $message,
            'extras' => $message_info,
        ))
          ->options(array(
            'apns_production' => false,
        ))
        ->send();
		// $this->successJson("极光推送发送成功！",$registration_id);
	}
	
	// 获取用组户头像
    public function get_avatararray_json() {
      	$userarray=I('post.userarray');
		$users_model=M("Users");
		//echo json_encode(explode(",", $userarray));exit;
		$result=$users_model->field('id,uuid,user_login,user_nicename,avatar')->where(array("user_login"=>array("in",explode(",", $userarray))))->select();
    	if($result){
        	$this->successJson("获取用户组头像成功！",$result);
    	}else{
    		$this->errorJson("获取用户组头像失败！");
    	}
    		    
	} 
	
	// 发表文章评论
    public function post_comment_json(){
		$comments_model=M("Comments");
		$post_table_model=M("Posts");
		$uid=I('post.uid',1,'intval');
		$post_id=I('post.post_id',0,'intval');
		$_POST['post_table']='post_comment_json';
		$_POST['createtime']=date("Y-m-d H:i:s",time());
		$user=M('Users')->field("user_login,avatar")->where("id=$uid")->find();
		$_POST['url']=$user['avatar'];
		$_POST['full_name']=$user['user_login'];
		$data=$comments_model->create();
		if ($data!==false){
		$result=$comments_model->add();
		if ($result!==false){
			$pk=$post_table_model->getPk();
			$post_table_model->create(array("comment_count"=>array("exp","comment_count+1")));
			$post_table_model->where(array($pk=>intval($_POST['post_id'])))->save();
			$post_table_model->create(array("last_comment"=>time()));
			$post_table_model->where(array($pk=>intval($_POST['post_id'])))->save();
			$this->successJson("评论成功！",$result);
		}else{
			$this->errorJson("评论失败！");
		}}else{
		$this->errorJson($comments_model->getError());
		}
	}
	
	// 文章浏览
    public function do_hit_json(){
    	
    	$id = I('post.object_id');//posts表中id
    	$posts_model=M("Posts");
    	$common_action_log_model=M("CommonActionLog");
		$action="Portal-Article-do_hits";
		$uid=I("post.userid");
		$object="posts$id";
		if(empty($uid)){
			$this->errorJson("用户ID不能为空！");
		}
		$ip=get_client_ip(0,true);//修复ip获取
		$where=array("user"=>$uid,"action"=>$action,"object"=>$object);
		$find_log=$common_action_log_model->where($where)->find();
		$time=time();
		if($find_log){
			$common_action_log_model->where($where)->save(array("count"=>array("exp","count+1"),"last_time"=>$time,"ip"=>$ip));
		}else{
		$common_action_log_model->add(array("user"=>$uid,"postid"=>$id,"action"=>$action,"object"=>$object,"count"=>array("exp","count+1"),"last_time"=>$time,"ip"=>$ip));
		}
      	//$posts_model->where(array('id'=>$id))->setInc('post_hits');
      	$posts_model->where(array('id'=>$id))->setInc('post_hits');
      	$posts_detail=$posts_model->where(array('id'=>$id))->find();
      	$posts_count=$posts_detail['post_hits'];
      	//echo json_encode($posts_res);exit;
		//$posts_model->save(array("id"=>$id,"post_hits"=>array("exp","post_hits+1")));
    	$this->successJson("浏览好啦！",$posts_count);
	
    }
	
	// 文章浏览
    public function do_hits_json(){
    	
    	$id = I('post.object_id');//posts表中id
    	$posts_model=M("Posts");
    	$common_action_log_model=M("CommonActionLog");
		$action="Portal-Article-do_hits";
		$uid=I("post.userid");
		$object="posts$id";
		if(empty($uid)){
			$this->errorJson("用户ID不能为空！");
		}
		$ip=get_client_ip(0,true);//修复ip获取
		$where=array("user"=>$uid,"action"=>$action,"object"=>$object,"postid"=>$id);
		$find_log=$common_action_log_model->where($where)->find();
		$time=time();
		if($find_log){
			$common_action_log_model->where($where)->save(array("count"=>array("exp","count+1"),"last_time"=>$time,"ip"=>$ip));
		}else{
		$common_action_log_model->add(array("user"=>$uid,"action"=>$action,"object"=>$object,"count"=>array("exp","count+1"),"last_time"=>$time,"ip"=>$ip));
		}
    	$this->successJson("浏览好啦！");
	
    }
	
	// 用户类别收藏
    public function do_follow_json(){
		$uid = I('post.userid');//users表中id
		$follow_id = I('post.follow_id');//category表中id
		$users_model=M("Users");
		$user_data=$users_model->field('follow_id')->where(array("id"=>$uid))->find();
		$user_follows=$user_data['follow_id'];
		if(empty($user_follows)){
			$data['follow_id']=$follow_id;
    		$data['id']=$uid;
			$users_model->save($data);
			$this->successJson("用户类别收藏成功！");
		}else{
			$follows_user=false;
			$follow_array =explode(",",$user_follows);
			foreach ($follow_array as $follow){
            	if($follow==$follow_id){
					$follows_user=true;
				}
            }
			//echo json_encode($user_follows);exit;
			if(!$follows_user){
				$data['follow_id']=$user_follows.','.$follow_id;
    			$data['id']=$uid;
				$users_model->save($data);
				$this->successJson("用户类别收藏成功！",$data);
			}else{
				$this->errorJson("您已收藏过该类别！");
			}
		}
	}
	
	// 用户类别收藏
    public function do_nofollow_json(){
		$uid = I('post.userid');//users表中id
		$follow_id = I('post.follow_id');//category表中id
		$users_model=M("Users");
		$user_data=$users_model->field('follow_id')->where(array("id"=>$uid))->find();
		$user_follows=$user_data['follow_id'];
		if(empty($user_follows)){
			$this->errorJson("您还未收藏过任何类别！");
		}else{
			$follows_user=false;
			$follow_array =explode(",",$user_follows);
			foreach ($follow_array as $key => $value){
            	if($value==$follow_id){
					$follows_user=true;
					unset($follow_array[$key]);
				}
            }
			//echo json_encode($user_follows);exit;
			if($follows_user){
				if(empty($follow_array)){
					$data['follow_id']='0';	
				}else{
					$data['follow_id']=implode(',',$follow_array);
				}
    			$data['id']=$uid;
				$users_model->save($data);
				$this->successJson("用户取消类别收藏成功！",$data);
			}else{
				$this->errorJson("您还未收藏过该类别！");
			}
		}
	}
  
  // 用户钢厂收藏
    public function do_follow_factory_json(){
		$uid = I('post.userid');//users表中id
		$follow_uid = I('post.follow_uid');//category表中id
		$users_model=M("Users");
		$user_data=$users_model->field('follow_uid')->where(array("id"=>$uid))->find();
		$user_followus=$user_data['follow_uid'];
		if(empty($user_followus)){
			$data['follow_uid']=$follow_uid;
    		$data['id']=$uid;
			$users_model->save($data);
			$this->successJson("用户钢厂收藏成功！");
		}else{
			$follows_user=false;
			$follow_uarray =explode(",",$user_followus);
			foreach ($follow_uarray as $followu){
            	if($followu==$follow_uid){
					$follows_user=true;
				}
            }
			//echo json_encode($user_follows);exit;
			if(!$follows_user){
				$data['follow_uid']=$user_followus.','.$follow_uid;
    			$data['id']=$uid;
				$users_model->save($data);
				$this->successJson("用户钢厂收藏成功！");
			}else{
				$this->errorJson("您已收藏过该钢厂！");
			}
		}
	}
	
	// 用户钢厂取消收藏
    public function do_nofollow_factory_json(){
		$uid = I('post.userid');//users表中id
		$follow_uid = I('post.follow_uid');//category表中id
		$users_model=M("Users");
		$user_data=$users_model->field('follow_uid')->where(array("id"=>$uid))->find();
		$user_followus=$user_data['follow_uid'];
		if(empty($user_followus)){
			$this->errorJson("您还未收藏过任何钢厂！");
		}else{
			$follows_user=false;
			$follow_uarray =explode(",",$user_followus);
			foreach ($follow_uarray as $key => $value){
            	if($value==$follow_uid){
					$follows_user=true;
					unset($follow_uarray[$key]);
				}
            }
			//echo json_encode($user_follows);exit;
			if($follows_user){
				if(empty($follow_uarray)){
					$data['follow_uid']='0';	
				}else{
					$data['follow_uid']=implode(',',$follow_uarray);
				}
    			$data['id']=$uid;
				$users_model->save($data);
				$this->successJson("用户取消钢厂收藏成功！");
			}else{
				$this->errorJson("您还未收藏过该钢厂！");
			}
		}
	}
	
	// 文章点赞
    public function do_like_json(){
    	
    	$id = I('post.object_id');//posts表中id
    	$posts_model=M("Posts");
    	$common_action_log_model=M("CommonActionLog");
		$action="Portal-Article-do_like";
		$uid=I("post.userid");
		$object="posts$id";
		if(empty($uid)){
			$this->errorJson("用户ID不能为空！");
		}
		$ip=get_client_ip(0,true);//修复ip获取
		$where=array("user"=>$uid,"action"=>$action,"object"=>$object);
		$find_log=$common_action_log_model->where($where)->find();
		$time=time();
		if($find_log){
			$this->errorJson("您已赞过啦！");
		}else{
		$common_action_log_model->add(array("user"=>$uid,"action"=>$action,"object"=>$object,"count"=>array("exp","count+1"),"last_time"=>$time,"ip"=>$ip));
		$posts_model->save(array("id"=>$id,"post_like"=>array("exp","post_like+1")));
    		$this->successJson("赞好啦！");
		}
	
    }
	
	// 用户收藏
	public function do_favorite_json(){
		$user_favorites_model=M("UserFavorites");
		$rules = array(
						//array(验证字段,验证规则,错误提示,验证条件,附加规则,验证时间)
						array('uid', 'require', '用户ID不能为空！', 1 ),
						array('title','require','收藏内容标题不能为空！',1), // 验证email字段格式是否正确
						array('table','require','收藏内容分类不能为空！',1),
						array('object_id','require','收藏内容来源不能为空！',1),
						
				);
		if($user_favorites_model->validate($rules)->create()===false){
			$this->errorJson($user_favorites_model->getError());
		}else{
			$uid=I("post.uid");
			$title=I("post.title");
			$table=I("post.table");
			$object_id=I("post.object_id");
		$find_favorite=$user_favorites_model->where(array('table'=>$table,'object_id'=>$object_id,'uid'=>$uid))->find();
		if($find_favorite){
			$this->errorJson("亲，您已收藏过啦！");
		}else {
			$post['createtime']=time();
			$result=$user_favorites_model->add($post);
			if($result){
				$this->successJson("收藏成功！");
			}else {
				$this->errorJson("收藏失败！");
			}
		}
		}
	}
	
    // 用户头像api
	public function avatar(){
		$users_model=M("Users");
		$id=I("get.id",0,"intval");
		
		$find_user=$users_model->field('avatar')->where(array("id"=>$id))->find();
		
		$avatar=$find_user['avatar'];
		$avatar=preg_replace("/^avatar\//", '', $avatar);//2.2以后头像路径统一以avatar/开头
		$should_show_default=false;
		
		if(empty($avatar)){
			$should_show_default=true;
		}else{
			if(strpos($avatar,"http")===0){
				header("Location: $avatar");exit();
			}else{
				$avatar_dir=C("UPLOADPATH")."avatar/";
				$avatar=$avatar_dir.$avatar;
				if(file_exists($avatar)){
					$imageInfo = getimagesize($avatar);
					if ($imageInfo !== false) {
					    $fp=fopen($avatar,"r");
					    $file_size=filesize($avatar);
						$mime=$imageInfo['mime'];
						header("Content-type: $mime");
						header("Accept-Length:".$file_size);
						$buffer=1024*64;
						$file_count=0;
						//向浏览器返回数据
						while(!feof($fp) && $file_count<$file_size){
						    $file_content=fread($fp,$buffer);
						    $file_count+=$buffer;
						    echo $file_content;
						    flush();
						    ob_flush();
						}
						fclose($fp);
					}else{
						$should_show_default=true;
					}
				}else{
					$should_show_default=true;
				}
			}
			
			
		}
		
		if($should_show_default){
			$imageInfo = getimagesize("public/images/headicon.png");
			if ($imageInfo !== false) {
				$mime=$imageInfo['mime'];
				header("Content-type: $mime");
				echo file_get_contents("public/images/headicon.png");
			}
			
		}
		exit();
		
	}
  
  // 客户端二维码收款
    public function getcode_for_user() {
		if (IS_POST) {
			$users_model=M("Users");
			$paylist_model=M("UserPaylist");
    	    $user_sum_add=I('post.user_sum_add');
			$sum_touserID=I('post.sum_touserID');
			$sum_foruserID=I('post.sum_foruserID');
    		if(empty($user_sum_add)){
    			$this->error("收款金额不能为空！");
    		}
    		$sum_touser=$users_model->where(array('id'=>$sum_touserID))->find();
			$sum_foruser=$users_model->where(array('id'=>$sum_foruserID))->find();
			$old_sumto=$sum_touser['user_sum'];
			$paytoName=$sum_touser['user_login'];
			if($old_sumto>$user_sum_add){
			$old_sumfor=$sum_foruser['user_sum'];
			$payforName=$sum_touser['user_login'];
			$data['user_sum']=$old_sumto-$user_sum_add;
    		$data['id']=$sum_touserID;
    		$r=$users_model->save($data);
			$data1['user_sum']=$old_sumfor+$user_sum_add;
			$data1['id']=$sum_foruserID;
			$r=$users_model->save($data1);
			$pr=$paylist_model->add(array('payforId'=>$sum_foruserID,'payforName'=>$payforName,'paytoId'=>$sum_touserID,'paytoName'=>$paytoName,'payAmount'=>$user_sum_add,'payforSum'=>$data1['user_sum'],'paytoSum'=>$data['user_sum'],'paydataTime'=>date("Y-m-d H:i:s")));
    		if ($r!==false) {
    			$this->successJson("收款成功！",$data1);
    		} else {
    			$this->errorJson("收款失败！");
    		}}else{
				$this->errorJson("付款方金额不足！");
			}
		}
		
	}
	
	// 客户端余额更新
    public function get_sum_user() {
		if (IS_POST) {
			$users_model=M("Users");
			$userID=I('post.userID');
			$userInfo=$users_model->where(array('id'=>$userID))->find();
			$user_sum=$userInfo['user_sum'];
			if ($userInfo) {
    			$this->successJson("余额更新成功！",$userInfo);
    		} else {
    			$this->errorJson("余额更新失败！");
    		}
		}
	
	}
	
	// 根据用户名查询用户ID
    public function get_userid_forname() {
		if (IS_POST) {
			$users_model=M("Users");
			$username=I('post.username');
			$userInfo=$users_model->where(array('user_login'=>$username))->find();
			if ($userInfo) {
    			$this->successJson("获取用户信息成功！",$userInfo);
    		} else {
    			$this->errorJson("获取用户信息失败！");
    		}
		}
	
	}
	
	// 获取用户交易记录列表
    public function get_user_paylist() {
		if (IS_POST) {
			$paylist_model=M("UserPaylist");
			$userID=I('post.userID');
			$where['payforId']=$userID;
	    	$where['paytoId']=$userID;
	    	$where['_logic'] = 'OR';
			$paylist=$paylist_model->field('payforName,paytoName,payamount,paydataTime')->where($where)->order(array("paydataTime" => "DESC"))->select();
			if ($paylist) {
    			$this->successJson("获取交易记录成功！",$paylist);
    		} else {
    			$this->errorJson("获取交易记录失败！");
    		}
		}
	
	}
	
	
	// 客户端二维码付款
    public function getcode_to_user() {
		if (IS_POST) {
			$users_model=M("Users");
			$paylist_model=M("UserPaylist");
    	    $user_sum_add=I('post.user_sum_add');
			$sum_touserID=I('post.sum_touserID');
			$sum_foruserID=I('post.sum_foruserID');
    		if(empty($user_sum_add)){
    			$this->error("付款金额不能为空！");
    		}
    		$sum_touser=$users_model->where(array('id'=>$sum_touserID))->find();
			$sum_foruser=$users_model->where(array('id'=>$sum_foruserID))->find();
			$old_sumto=$sum_touser['user_sum'];
			$paytoName=$sum_touser['user_login'];
			if($old_sumto>$user_sum_add){
			$old_sumfor=$sum_foruser['user_sum'];
			$payforName=$sum_foruser['user_login'];
			$data['user_sum']=$old_sumto-$user_sum_add;
    		$data['id']=$sum_touserID;
    		$r=$users_model->save($data);
			$data1['user_sum']=$old_sumfor+$user_sum_add;
			$data1['id']=$sum_foruserID;
			$r=$users_model->save($data1);
			$pr=$paylist_model->add(array('payforId'=>$sum_foruserID,'payforName'=>$payforName,'paytoId'=>$sum_touserID,'paytoName'=>$paytoName,'payAmount'=>$user_sum_add,'payforSum'=>$data1['user_sum'],'paytoSum'=>$data['user_sum'],'paydataTime'=>date("Y-m-d H:i:s")));
    		if ($r!==false) {
    			$this->successJson("付款成功！",$data);
    		} else {
    			$this->errorJson("付款失败！");
    		}}else{
				$this->errorJson("付款方金额不足！");
			}
		}
		
	}
	
	// 客户端二维码付款
    public function getcode_to_username() {
		if (IS_POST) {
			$users_model=M("Users");
			$paylist_model=M("UserPaylist");
    	    $user_sum_add=I('post.user_sum_add');
			$sum_touserID=I('post.sum_touserID');
			$sum_foruserName=I('post.sum_foruserName');
    		if(empty($user_sum_add)){
    			$this->error("付款金额不能为空！");
    		}
    		$sum_touser=$users_model->where(array('id'=>$sum_touserID))->find();
			$sum_foruser=$users_model->where(array('user_login'=>$sum_foruserName))->find();
			$old_sumto=$sum_touser['user_sum'];
			$paytoName=$sum_touser['user_login'];
			if($old_sumto>$user_sum_add){
			$old_sumfor=$sum_foruser['user_sum'];
			$payforName=$sum_foruser['user_login'];
			$sum_foruserID=$sum_foruser['id'];
			$data['user_sum']=$old_sumto-$user_sum_add;
    		$data['id']=$sum_touserID;
    		$r=$users_model->save($data);
			$data1['user_sum']=$old_sumfor+$user_sum_add;
			$data1['id']=$sum_foruserID;
			$r=$users_model->save($data1);
			$pr=$paylist_model->add(array('payforId'=>$sum_foruserID,'payforName'=>$payforName,'paytoId'=>$sum_touserID,'paytoName'=>$paytoName,'payAmount'=>$user_sum_add,'payforSum'=>$data1['user_sum'],'paytoSum'=>$data['user_sum'],'paydataTime'=>date("Y-m-d H:i:s")));
    		if ($r!==false) {
    			$this->successJson("付款成功！",$data);
    		} else {
    			$this->errorJson("付款失败！");
    		}}else{
				$this->errorJson("付款方金额不足！");
			}
		}
		
	}
	
	// 获取会员认证资料
	public function get_review_json(){
		$role_user_model=M("RoleUser");
		$user_id = $_POST['user_id'];
		$result=$role_user_model->where(array("user_id"=>$user_id))->find();
		$this->successJson("获取会员认证资料成功！",$result);
	}
	
	// 会员认证资料添加提交
	public function add_review_json(){
		$role_user_model=M("RoleUser");
		$role_id = $_POST['role_id'];
		$user_id = $_POST['user_id'];
		$user_check_image01 = $_POST['user_check_image01'];
		$user_check_image02 = $_POST['user_check_image02'];
		$user_check_image03 = $_POST['user_check_image03'];
		$result=$role_user_model->add(array("role_id"=>$role_id,"user_id"=>$user_id,"user_check_image01"=>$user_check_image01,"user_check_image02"=>$user_check_image02,"user_check_image03"=>$user_check_image03));
		if ($result!==false) {
			$this->users_model->where(array("id"=>$user_id))->save(array("user_type"=>$role_id));
			$this->successJson("会员认证资料提交成功！");
		}else{
			$this->errorJson("会员认证资料提交失败！");
		}
	}
  
  // 钢厂地区分布列表
	public function factory_review_json(){
		$where = array("user_type"=>1);
		/**搜索条件**/
      	$region_code=I('post.region_code',0,'intval');
      	if(!empty($region_code)){
		$where['region_code'] = $region_code;
		}
		$count=$this->users_model->where($where)->count();
		$page = $this->page($count, 20);
		$where['role_user.role_id'] = array('eq',5);
      	$join = '__ROLE_USER__ as role_user on users.id = role_user.user_id';
        $users = $this->users_model
          	->alias("users")
          	->join($join)
            ->where($where)
            ->order("create_time DESC")
            ->limit($page->firstRow, $page->listRows)
            ->select();
      	$this->successJson("钢厂地区分布查询成功！",$users);
	}
	
	// 黄页地区分布列表
	public function company_hot_json(){
		$where = array("user_type"=>1);
		/**搜索条件**/
      	$region_code=I('post.region_code',0,'intval');
      	if(!empty($region_code)){
		$where['region_code'] = $region_code;
		}
		$count=$this->users_model->where($where)->count();
		$page = $this->page($count, 20);
		$where['role_user.role_id'] = array('eq',6);
      	$join = '__ROLE_USER__ as role_user on users.id = role_user.user_id';
        $users = $this->users_model
          	->alias("users")
          	->join($join)
            ->where($where)
            ->order("create_time DESC")
            ->limit($page->firstRow, $page->listRows)
            ->select();
      	$this->successJson("黄页地区分布查询成功！",$users);
	}
	
	// 钢厂地区分布列表及用户关注度
	public function factory_users_json(){
		$uid = I('post.userid');//users表中id
		$where = array("user_type"=>1);
		//$where['role_id'] = 5;
		/**搜索条件**/
      	$region_code=I('post.region_code',0,'intval');
      	if(!empty($region_code)){
		$where['region_code'] = $region_code;
		}
		$count=$this->users_model->where($where)->count();
		$page = $this->page($count, 20);
		$where['role_user.role_id'] = array('eq',5);
      	$join = '__ROLE_USER__ as role_user on users.id = role_user.user_id';
        $users = $this->users_model
          	->alias("users")
          	->join($join)
            ->where($where)
            ->order("create_time DESC")
            ->limit($page->firstRow, $page->listRows)
            ->select();
		$user_data=$this->users_model->field('follow_uid')->where(array("id"=>$uid))->find();
		$user_followus=$user_data['follow_uid'];
		foreach ($users as $key => $value){
        	if(empty($user_followus)){
				$users[$key]['isFlag']=false;
			}else{
				$follows_user=false;
				$follow_uarray =explode(",",$user_followus);
				foreach ($follow_uarray as $followu){
            		if($followu==$value['id']){
						$follows_user=true;
					}
            	}
				$users[$key]['isFlag']=$follows_user;
			}    	
        }
      	$this->successJson("钢厂地区分布及用户关注度查询成功！",$users);
	}
	
	
	// 用户关注钢厂信箱
	public function factory_users_message_json(){
		$uid = I('post.userid');//users表中id
		$where = array("user_type"=>1);
		//$where['role_id'] = 5;
		/**搜索条件**/
		$count=$this->users_model->where($where)->count();
		
		$page = $this->page($count, 20);
		$where['role_user.role_id'] = array('eq',5);
		$user_data=$this->users_model->field('follow_uid')->where(array("id"=>$uid))->find();
		$user_followus=$user_data['follow_uid'];
		$where['role_user.id'] = array('in',$user_followus);
      	$join = '__ROLE_USER__ as role_user on users.id = role_user.user_id';
        $users = $this->users_model
          	->alias("users")
          	->join($join)
            ->where($where)
            ->order("create_time DESC")
            ->limit($page->firstRow, $page->listRows)
            ->select();
      	$this->successJson("用户关注钢厂信箱查询成功！",$users);
	}
    
}
