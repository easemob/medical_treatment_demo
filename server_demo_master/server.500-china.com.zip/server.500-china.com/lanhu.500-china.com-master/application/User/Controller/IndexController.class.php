<?php
namespace User\Controller;

use Common\Controller\HomebaseController;

use Think\Easemob;

class IndexController extends HomebaseController {
    
    // 前台用户首页 (公开)
	public function index() {
	    
		$id=I("get.id",0,'intval');
		
		$users_model=M("Users");
		
		$user=$users_model->where(array("id"=>$id))->find();
		//echo json_encode($user);exit;
		if(empty($user)){
			$this->error("查无此人！");
		}
		
		$this->assign($user);
		$this->display(":index");

	}

	// 认证医生信息
	public function reviewDoctorJson() {
		$rid=I('post.rid',1,'intval');
		$useravatar=I('post.useravatar');
		$doc_img1=I('post.doc_img1');
		$doc_img2=I('post.doc_img2');
		$doc_img3=I('post.doc_img3');
		$doc_data=array(
			'doc_img1' => $doc_img1,
			'doc_img2' => $doc_img2,
			'doc_img3' => $doc_img3
			);
		$userid=M("UserDoctor")->where(array("rid"=>$rid))->getField("uid");
		M("Users")->where(array("id"=>$userid))->save(array('avatar' => $useravatar));
		$result=M("UserDoctor")->where(array("rid"=>$rid))->save($doc_data);
		if($result){
			$this->successJson("认证信息提交成功！",$result);
		}
	}

	// 保存医生信息
    public function saveDoctorJson() {
		$user_data=I('post.');
		$user_data['createtime']= date("Y-m-d H:i:s");
		$result=M("UserDoctor")->save($user_data);
    	if($result){
        	$this->successJson("资料更新成功！");
    	}else{
    		$this->errorJson("资料更新失败！");
    	}
	}

	// 保存用户信息
    public function saveProfileJson() {
		$user_data=I('post.');
		$users_model=M("Users");
		$result=$users_model->save($user_data);
    	if($result){
        	$this->successJson("资料更新成功！");
    	}else{
    		$this->errorJson("资料更新失败！");
    	}
	}
	
	// 编辑用户信息
    public function editProfileJson() {
		$userid=I('post.userid');
		$avatar=I('post.avatar');
		$user_nicename=I('post.user_nicename');
		$sex=I('post.sex');
		$birthday=I('post.birthday');
		$users_model=M("Users");
		$user_data=array();
		if(!empty($avatar)){
			$user_data['avatar']=$avatar;	
		}
		if(!empty($user_nicename)){
			$user_data['user_nicename']=$user_nicename;	
		}
		if(!empty($birthday)){
			$user_data['birthday']=$birthday;	
		}
		if(!empty($sex)){
			$user_data['sex']=$sex;	
		}
		$result=$users_model->where(array("id"=>$userid))->save($user_data);
    	if($result){
        	$this->successJson("资料更新成功！");
    	}else{
    		$this->errorJson("资料更新失败！");
    	}
	}

	// 认证医生信息
	/*`docname` varchar(64) DEFAULT NULL COMMENT '医师名字',
  `doclevel` varchar(64) DEFAULT NULL COMMENT '医师职务',
  `dochospital` varchar(64) DEFAULT '' COMMENT '就职医院',
  `docpartment` varchar(64) DEFAULT NULL COMMENT '就职科室',
  `doctag` varchar(32) DEFAULT NULL COMMENT '医院级别',
  `docexpert` varchar(128) DEFAULT NULL COMMENT '擅长领域',
  `docresume` varchar(128) DEFAULT NULL COMMENT '个人简历',
  `docexperience` varchar(128) DEFAULT NULL COMMENT '职业经历',
  `docconsultation` int(11) DEFAULT NULL COMMENT '问诊量',
  `docresponse` int(11) DEFAULT NULL COMMENT '平均回复时间',
  `docfootprice` int(11) DEFAULT NULL COMMENT '问诊价格',
  `doc_img1` varchar(255) DEFAULT '' COMMENT '医生认证照片1',
  `doc_img2` varchar(255) DEFAULT '' COMMENT '医生认证照片2',
  `doc_img3` varchar(255) DEFAULT '' COMMENT '医生认证照片3',*/
    public function reviewDocJson() {
		$userid=I('post.userid');
		$avatar=I('post.avatar');
		$docname=I('post.docname');
	
		$doclevel=I('post.doclevel');
		$dochospital=I('post.dochospital');
		$docpartment=I('post.docpartment');
		$doctag=I('post.doctag');
		$docexpert=I('post.docexpert');
		$docresume=I('post.docresume');
		$docexperience=I('post.docexperience');
		$docconsultation=I('post.docconsultation');
		$docresponse=I('post.docresponse');
		$docfootprice=I('post.docfootprice');
		$doc_img1=I('post.doc_img1');
		$doc_img2=I('post.doc_img2');
		$doc_img3=I('post.doc_img3');
		$user_data=array();
		$users_model=M("Users");
		$userdoc_model=M("UserDoctor");
		$user_data=array();
		if(!empty($avatar)){
			$user_data['avatar']=$avatar;	
		}
		if(!empty($user_nicename)){
			$user_data['user_nicename']=$docname;	
		}
		$data=array(
			'uid' => $userid,
	        'docname' => $docname,
	        'doclevel' => $doclevel,
	        'dochospital' =>$dochospital,
			'docpartment' => $docpartment,
			'doctag' => $doctag,
			'docexpert' => $docexpert,
			'docresume' => $docresume,
			'docexperience' => $docexperience,
			'docconsultation' => $docconsultation,
			'docresponse' => $docresponse,
			'docfootprice' => $docfootprice,
			'doc_img1' => $doc_img1,
			'doc_img2' => $doc_img2,
			'doc_img3' => $doc_img3,
			'createtime' => date("Y-m-d H:i:s",time())
	    	);
		$result=$users_model->where(array("id"=>$userid))->save($user_data);
		$userdoc_id=$userdoc_model->add($data);
		if($userdoc_id){
			$this->successJson("医生信息认证成功");
		}else{
			$this->errorJson("医生信息认证失败！");
		}
	}
  
  // 保存用户头像
    public function do_avatar_json() {
      	$userid=I('post.userid');
		$imgurl=I('post.imgurl');
		$user_nicename=I('post.user_nicename');
		$user_mobile=I('post.user_mobile');
		$user_address=I('post.user_address');
		$user_data=array();
		$users_model=M("Users");
		$users_info=$users_model->where(array("id"=>$userid))->find();
		$user_login=$users_info['user_login'];
		if(empty($user_nicename)){
		$user_data['user_nicename']=$users_info['user_nicename'];	
		}else{
		$user_data['user_nicename']=$user_nicename;	
		}
		if(empty($user_mobile)){
		$user_data['mobile']=$users_info['mobile'];	
		}else{
		$user_data['mobile']=$user_mobile;
		}
		if(empty($user_address)){
		$user_data['address_message']=$users_info['address_message'];	
		}else{
		$user_data['address_message']=$user_address;
		}
		if(empty($imgurl)){
		$user_data['avatar']=$users_info['avatar'];	
		}else{
		$user_data['avatar']=$imgurl;
		}
		//$resultIm=$this->editImNickName($user_login,$user_nicename);
		$result=$users_model->where(array("id"=>$userid))->save($user_data);
    	if($result){
        	$this->successJson("资料更新成功！");
    	}else{
    		$this->errorJson("资料更新失败！");
    	}
    		    
	}  
	
	// 设置支付密码
    public function reset_user_paypass() {
      	$userid=I('post.userid');
		$user_paypass=I('post.user_paypass');
		$users_model=M("Users");
		$result=$users_model->where(array("id"=>$userid))->save(array("user_paypass"=>$user_paypass));
    	if($result){
        	$this->successJson("用户支付密码设置成功！");
    	}else{
    		$this->errorJson("用户支付密码设置失败！");
    	}
    		    
	} 
	
	// 获取个人资料
    public function get_user_data() {
      	$user_id=I('post.user_id',1);
		$user_model=M("Users");
		$result=$user_model->where(array("id"=>$user_id))->find();
    	if($result){
		$this->successJson("获取个人资料成功！",$result);
		}else{
		$this->errorJson("获取个人资料失败！");
		}
	}
	
	// 获取个人资料(新增足迹和心愿单)
    public function get_user_json() {
		$field = 'id,user_login,user_nicename,avatar,sex,signature,user_type,region_code,user_cares,user_follows,user_posts,user_likes';
      	$user_id=I('post.user_id',1);
		$user_model=M("Users");
		$result=$user_model->where(array("id"=>$user_id))->field($field)->find();
    	if($result){
		$this->successJson("获取个人资料成功！",$result);
		}else{
		$this->errorJson("获取个人资料失败！");
		}
	}
  
  // 获取个人资料
    public function get_user_info() {
      	$user_id=I('post.user_id');
		$userinfo_model=M("UserInfo");
		$result=$userinfo_model->where(array("user_id"=>$user_id))->find();
    	if($result){
		$this->successJson("获取个人资料成功！",$result);
		}else{
		$this->errorJson("获取个人资料失败！");
		}
	}
	
	// 设置个人资料
    public function edit_user_info() {
      	$user_id=I('post.user_id');
		$userinfo_model=M("UserInfo");
		$result=$userinfo_model->where(array("user_id"=>$user_id))->find();
		$real_name=I('post.real_name');
		if(empty($real_name)){
		$real_name=$result['real_name'];	
		}
		$user_idnumber=I('post.user_idnumber');
		if(empty($user_idnumber)){
		$user_idnumber=$result['user_idnumber'];
		}
		$user_address=I('post.user_address');
		if(empty($user_address)){
		$user_address=$result['user_address'];	
		}
		$user_friend=I('post.user_friend');
		if(empty($user_friend)){
		$user_friend=$result['user_friend'];		
		}
		$friend_mobile=I('post.friend_mobile');
		if(empty($friend_mobile)){
		$friend_mobile=$result['friend_mobile'];	
		}
		$user_cardphoto=I('post.user_cardphoto');
		if(empty($user_cardphoto)){
		$user_cardphoto=$result['user_cardphoto'];	
		}
		$data=array(
			'user_id' => $user_id,
			'real_name' => $real_name,
			'user_idnumber' => $user_idnumber,
			'user_address' => $user_address,
			'user_friend' => $user_friend,
			'friend_mobile' => $friend_mobile,
			'user_cardphoto' => $user_cardphoto,
	    );
    	$cresult=$userinfo_model->where(array("user_id"=>$user_id))->save($data);
			if($cresult){
				$this->successJson("设置个人资料成功！");
    		}else{
				$this->errorJson("设置个人资料失败！");
    		}
    		    
	}  
	
	public function editImNickName($username,$nickname){
    	$options['client_id'] = 'YXA6JaYeEG55EeWfDIdFJvc5xQ';
    	$options['client_secret'] = 'YXA6t5BCqNIEnt5h6c2Bb92LMUErQtM'; 
    	$options['org_name'] = 'comcaesar';
    	$options['app_name'] = 'huaxin'; 
    	$e = new Easemob($options);
    	$result_n = $e->editNickname($username,$nickname);
    	return $result_n;
    }
	
	// 获取用组户头像
    public function get_avatararray_json() {
      	$userarray=I('post.userarray');
		$users_model=M("Users");
		//echo json_encode(explode(",", $userarray));exit;
		$result=$users_model->field('id,uuid,user_login,user_nicename,avatar')->where(array("user_login"=>array("in",explode(",", $userarray))))->select();
    	if($result){
        	$this->successJson("获取用户组头像成功！",$result);
    	}else{
    		$this->errorJson("获取用户组头像失败！");
    	}
    		    
	}  
	
	// 获取全部用组户头像
    public function get_allavatars_json() {
		$users_model=M("Users");
		$result=$users_model->field('id,uuid,user_login,user_nicename,avatar')->select();
    	if($result){
        	$this->successJson("获取全部用户组头像成功！",$result);
    	}else{
    		$this->errorJson("获取全部用户组头像失败！");
    	}
    		    
	}  
    
    // 前台ajax 判断用户登录状态接口
    function is_login(){
    	if(sp_is_user_login()){
    		$this->ajaxReturn(array("status"=>1,"user"=>sp_get_current_user()));
    	}else{
    		$this->ajaxReturn(array("status"=>0,"info"=>"此用户未登录！"));
    	}
    }

    //退出
    public function logout(){
    	$ucenter_syn=C("UCENTER_ENABLED");
    	$login_success=false;
    	if($ucenter_syn){
    		include UC_CLIENT_ROOT."client.php";
    		echo uc_user_synlogout();
    	}
    	session("user",null);//只有前台用户退出
    	redirect(__ROOT__."/");
    }
	
	// 获取用户个人相册
	public function personalBrowseListJson(){
		$userid=I('post.userid',0,'intval');
		
	}
	
	//订单管理
	public function myorderjson(){	
		$user_id = I('post.user_id',1);
		$order_status = I('post.order_status',0);
		$where['user_id'] = array('eq',$user_id);
		$where['order_status'] = array('eq',$order_status);
		$order = M('GoodsOrder')->where($where)->order('add_time DESC')->select();	
		$this->successJson("获取订单管理成功！",$order);
	}
	
	// 获取微信APP支付签名 (公开)
	public function getWechatSign() {
		$user_id = I('post.user_id',1);
		$out_trade_no = I('post.out_trade_no',date('YmdHis'));
		$total_fee = I('post.total_fee',1);
		if($user_id=='2'){
		$total_fee =1;
		}
		$body = I('post.body','同行快线APP支付订单');
      	$payObj=new WeChatPay();
		$notify_url="http://thinkcmf.91bim.net/index.php/goods/cart/sumbit_cart_order/order_sn/".$out_trade_no;
      	$params = array(
		'total_fee' => $total_fee,
		'body' => $body,
		'out_trade_no' => $out_trade_no,
		'notify_url' => $notify_url
	  	);
	  	$result=$payObj->doPay($params);
	  	$this->successJson("获取微信APP支付签成功！",$result);
    }

}
