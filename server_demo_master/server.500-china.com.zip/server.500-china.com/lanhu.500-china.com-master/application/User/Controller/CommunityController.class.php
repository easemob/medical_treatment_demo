<?php
namespace User\Controller;

use Common\Controller\AdminbaseController;

class CommunityController extends AdminbaseController {
	
	protected $users_model,$group_model;

	public function _initialize() {
		parent::_initialize();
		$this->users_model = D("Common/Users");
		$this->group_model = D("Common/Groups");
	}
	
    // 社区成员中心首页
	public function index() {
		$where=array();
        $request=I('request.');
        
        if(!empty($request['uid'])){
            $where['id']=intval($request['uid']);
        }
        
        if(!empty($request['keyword'])){
            $keyword=$request['keyword'];
            $keyword_complex=array();
            $keyword_complex['group_name']  = array('like', "%$keyword%");
			$keyword_complex['bulletin']  = array('like', "%$keyword%");
            $keyword_complex['_logic'] = 'or';
            $where['_complex'] = $keyword_complex;
        }
        
    	$group_model=M("Groups");
    	$where['group_state']=1;
    	$count=$group_model->where($where)->count();
    	$page = $this->page($count, 20);
    	
    	$list = $group_model
    	->where($where)
    	->order("createdAt DESC")
    	->limit($page->firstRow . ',' . $page->listRows)
    	->select();
		$this->assign('list', $list);
		//echo json_encode($list);exit;
    	$this->assign("page", $page->show('Admin'));
		$this->display(":community");
    }
	
	// 社区成员中心首页
	public function add() {
		$this->display(":community_add");
    }
	
	// 社区成员中心首页
	public function memberlist() {
		$group_id=I('group_id',1);
		$group_members_model=M("GroupMembers");
		$field = 'users.id,user_login,user_nicename,mobile,avatar,sex,role,member_state';
    	$limit = '0,50';
		$where['group_members.groupId'] = array('eq',$group_id);
		$where['group_members.member_state'] = array('eq',1);
		$where['users.user_status'] = array('eq',1);
		$join = '__USERS__ as users on users.id = group_members.memberId';
    	$order = "group_members.timestamp DESC";
		$member_list=$group_members_model->alias("group_members")->join($join)->field($field)
			->where($where)->order($order)->limit($limit)->select();
		$this->assign('group_id', $group_id);
		$this->assign('member_list', $member_list);
		//echo json_encode($member_list);exit;
		$this->display(":memberlist");
    }
	
	// 社区成员中心首页
	public function add_post() {
		if(IS_POST){
		$user_model=M("Users");
		$group_model=M("Groups");
		$group_members_model=M("GroupMembers");
		$user_id=I('post.user_id',1);
		$group_name=I('post.group_name');
		$group_data=I('post.');
		$group_data['creatorId']=$user_id;
		if(empty($user_id)){
			$this->error("创建者不能为空！");
		}
		if(empty($group_name)){
			$this->error("创建的社区名称不能为空！");
		}
		$result=$group_model->where(array("creatorId"=>$user_id))->find();
		if($result&&$user_id!==1){
			$this->error("您已创建过社区");
		}else{
			$timestamp=time();
			$datetime=date("Y-m-d H:i:s",time());
			$group_data['timestamp']=$timestamp;
			$group_data['createdAt']=$datetime;
			$group_data['updatedAt']=$datetime;
			$group_data['group_state']=1;
			$group_res=$group_model->create($group_data);
			if ($group_res) {
				$res=$group_model->add();
				$user_data=$user_model->where(array("id"=>$user_id))->find();
				$member_data=array(
	        	'groupId' => $res,
	        	'memberId' => $user_id,
	        	'displayName' =>$user_data['user_nicename'],
				'dispalyAvatar'=>$user_data['avatar'],
				'role' => 1,
	        	'member_state' => 1,
				'timestamp' => $timestamp,
				'createdAt' => $datetime,
				'updatedAt' => $datetime,
	    		);
				$group_members_model->add($member_data);
				$this->success("话题的社区创建成功！",U('Community/index'));
			}else{
				$this->error($posts_model->getError());
			}
		}
    }}
	
}
