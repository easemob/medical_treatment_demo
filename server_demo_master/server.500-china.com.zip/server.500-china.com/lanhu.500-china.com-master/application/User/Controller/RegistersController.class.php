<?php
namespace User\Controller;

require  __ROOT__."./vendor/autoload.php";

use Common\Controller\HomebaseController;

use Think\Controller;
use Think\Easemob;
use AlibabaCloud\Client\AlibabaCloud;
use AlibabaCloud\Client\Exception\ClientException;
use AlibabaCloud\Client\Exception\ServerException;
use Qcloud\Sms\SmsSingleSender;
use Qcloud\Sms\SmsMultiSender;
use Qcloud\Sms\SmsVoiceVerifyCodeSender;
use Qcloud\Sms\SmsVoicePromptSender;
use Qcloud\Sms\SmsStatusPuller;
use Qcloud\Sms\SmsMobileStatusPuller;

class RegistersController extends HomebaseController {
	
    // 前台用户注册
	public function index(){
	    if(sp_is_user_login()){ //已经登录时直接跳到首页
	        redirect(__ROOT__."/");
	    }else{
	        $this->display(":register");
	    }
	}
	// 前台用户注册提交
	public function doregisterPhoneSendCode(){
    	//$verifycode= empty($verifycode)?I('request.verify'):$verifycode;
		//echo json_encode($verifycode);exit;
		if(!sp_check_verify_code()){
            //$this->error("验证码错误！");
        }
    	$this->send_code();
	
	}
	
	// 前台用户注册提交
	public function doregister(){
    	
    	if(isset($_POST['email'])){
    	    
    	    //邮箱注册
    	    $this->_do_email_register();
    	    
    	}elseif(isset($_POST['mobile'])){
    	    
    	    //手机号注册
    	    $this->_do_mobile_register();
    	    
    	}else{
    	    $this->error("注册方式不存在！");
    	}
    	
	}
	
	// 前台用户注册提交
	public function doregisterjson(){
    	
    	if(isset($_POST['email'])){
    	    
    	    //邮箱注册
    	    $this->_do_email_register();
    	    
    	}elseif(isset($_POST['mobile'])){
    	    
    	    //手机号注册
    	    $this->_do_mobile_register_json();
    	    
    	}else{
    	    $this->errorJson("注册方式不存在！");
    	}
    	
	}
	
	// 前台用户手机注册
	private function _do_mobile_register(){
	    
	    if(!sp_check_verify_code()){
	        //$this->error("验证码错误！");
	    }
	     
        $rules = array(
            //array(验证字段,验证规则,错误提示,验证条件,附加规则,验证时间)
            array('mobile', 'require', '手机号不能为空！', 1 ),
            array('mobile','','手机号已被注册！！',0,'unique',3),
            array('password','require','密码不能为空！',1),
            array('password','5,20',"密码长度至少5位，最多20位！",1,'length',3),
        );
        	
	    $users_model=M("Users");
	     
	    if($users_model->validate($rules)->create()===false){
	        $this->error($users_model->getError());
	    }
	    $password=I('post.password');
	    $mobile=I('post.mobile');
		$mobile_verify=I('post.mobile_verify');
	    if(!sp_check_mobile_verify_code()){
	        //$this->error("手机验证码错误！");
        }
		$result= false;
		$session_mobile_code=session('mobile_code');
		if(empty($session_mobile_code)){
		$model = M("Code");	
		$mobile_code=$model->where(array('mobile'=>$mobile))->find();	
		if($mobile_code['code']==$mobile_verify)
		$result = true;
		}else{
		if($session_mobile_code==$mobile_verify)
		$result = true;
		}
		
		if(!$result){
		$this->error("手机验证码错误！");	
		}
		
	    $users_model=M("Users");
	    $data=array(
	        'user_login' => '',
	        'user_email' => '',
	        'mobile' =>$mobile,
	        'user_nicename' =>'',
	        'user_pass' => sp_password($password),
	        //'last_login_ip' => get_client_ip(0,true),
	        'create_time' => date("Y-m-d H:i:s"),
	        'last_login_time' => date("Y-m-d H:i:s"),
	        'user_status' => 1,
	        "user_type"=>2,//会员
	    );
	    
	    $result = $users_model->add($data);
	    if($result){
	        //注册成功页面跳转
	        $data['id']=$result;
			//$userinfo_model=M("UserInfo");
			//$userinfo_model->add(array("user_id"=>$result));
	        session('user',$data);
			//$this->success("注册成功！");
	        $this->success("注册成功！",__ROOT__."/");
	         //exit(json_encode($result));
	    }else{
	        $this->error("注册失败！",U("user/register/index"));
	    }
	}
	
	
	// 前台用户手机注册
	private function _do_mobile_register_im(){
	    
	    if(!sp_check_verify_code()){
	        //$this->error("验证码错误！");
	    }
	     
        $rules = array(
            //array(验证字段,验证规则,错误提示,验证条件,附加规则,验证时间)
            array('mobile', 'require', '手机号不能为空！', 1 ),
            array('mobile','','手机号已被注册！！',0,'unique',3),
            array('password','require','密码不能为空！',1),
            array('password','5,20',"密码长度至少5位，最多20位！",1,'length',3),
        );
        	
	    $users_model=M("Users");
	     
	    if($users_model->validate($rules)->create()===false){
	        $this->error($users_model->getError());
	    }
	    $password=I('post.password');
	    $mobile=I('post.mobile');
		$mobile_verify=I('post.mobile_verify');
		$uuid='';
	    if(!sp_check_mobile_verify_code()){
	        //$this->error("手机验证码错误！");
        }
		$result= false;
		$session_mobile_code=session('mobile_code');
		if(empty($session_mobile_code)){
		$model = M("Code");	
		$mobile_code=$model->where(array('mobile'=>$mobile))->find();	
		if($mobile_code['code']==$mobile_verify)
		$result = true;
		}else{
		if($session_mobile_code==$mobile_verify)
		$result = true;
		}
		
		if(!$result){
		$this->error("手机验证码错误！");	
		}
	     
		$resultUser=$this->registerImUser($mobile,$password,$mobile);
	    if($resultUser){
			//注册成功页面跳转
	        $entities=$resultUser['entities'];
			$entity=$entities[0];
			if($entity){
				$uuid=$entity['uuid'];	
				$resultU = true;
			}else{
			$this->error("聊天注册错误！");
			}
		}else{
		$this->error("聊天注册错误！");
		}
		
	    $users_model=M("Users");
	    $data=array(
			'uuid' => $uuid,
	        'user_login' => '',
	        'user_email' => '',
	        'mobile' =>$mobile,
	        'user_nicename' =>'',
	        'user_pass' => sp_password($password),
	        //'last_login_ip' => get_client_ip(0,true),
	        'create_time' => date("Y-m-d H:i:s"),
	        'last_login_time' => date("Y-m-d H:i:s"),
	        'user_status' => 1,
	        "user_type"=>2,//会员
	    );
	    
	    $result = $users_model->add($data);
	    if($result){
	        //注册成功页面跳转
	        $data['id']=$result;
			//$userinfo_model=M("UserInfo");
			//$userinfo_model->add(array("user_id"=>$result));
	        session('user',$data);
			//$this->success("注册成功！");
	        $this->success("注册成功！",__ROOT__."/");
	         //exit(json_encode($result));
	    }else{
	        $this->error("注册失败！",U("user/register/index"));
	    }
	}
	
	// 前台用户手机注册
	private function _do_mobile_register_json(){
	    
	    if(!sp_check_verify_code()){
	        //$this->error("验证码错误！");
	    }
	     
        $rules = array(
            //array(验证字段,验证规则,错误提示,验证条件,附加规则,验证时间)
            array('mobile', 'require', '手机号不能为空！', 1 ),
            array('mobile','','手机号已被注册！！',0,'unique',3),
            array('password','require','密码不能为空！',1),
            array('password','5,20',"密码长度至少5位，最多20位！",1,'length',3),
        );
        	
	    $users_model=M("Users");
	     
	    if($users_model->validate($rules)->create()===false){
	        $this->errorJson($users_model->getError());
	    }
	    $mobile=I('post.mobile');
		$user_login=I('post.user_login');
		$password=I('post.password');
		$avatar=I('post.avatar');
		$user_nicename=I('post.user_nicename');
		if(empty($user_nicename)){
		$user_nicename=$mobile;	
		}
		if(empty($user_login)){
		$user_login=$mobile;	
		}
		if(empty($avatar)){
		$avatar="avatar/default_header.png";	
		}
		$mobile_verify=I('post.mobile_verify');
		
	    if(!sp_check_mobile_verify_code()){
	        //$this->error("手机验证码错误！");
        }
		$result= false;
		$session_mobile_code=session('mobile_code');
		if(!empty($session_mobile_code)){
        	if($session_mobile_code==$mobile_verify){
			$result = true; 
        	}
    	}
  		if(!$result){
        $model = M("Code");	
		$mobile_code=$model->where(array('mobile'=>$mobile))->find();	
		if($mobile_code['code']==$mobile_verify)
		$result = true;
        }
		
		if(!$result){
		//$this->errorJson("手机验证码错误！");	
		}
		
	    $users_model=M("Users");
	    $data=array(
	        'user_login' => $user_login,
	        'user_email' => '',
	        'mobile' =>$mobile,
	        'user_nicename' =>$user_nicename,
	        'user_pass' => sp_password($password),
	        'avatar' => $avatar,
	        'create_time' => date("Y-m-d H:i:s"),
	        'last_login_time' => date("Y-m-d H:i:s"),
	        'user_status' => 1,
	        "user_type"=>2,//会员
	    );
		$result = $users_model->add($data);
	    if($result){
	        //注册成功页面跳转
	        $data['id']=$result;
			//$userinfo_model=M("UserInfo");
			//$userinfo_model->add(array("user_id"=>$result));
	        //session('user',$data);
			//$this->success("注册成功！");
	        $this->successJson("注册成功！",$data);
	         //exit(json_encode($result));
	    }else{
	        $this->errorJson("注册失败！");
	    }
	}
	
	// 前台用户手机注册
	private function _do_mobile_register_im_json(){
	    
	    if(!sp_check_verify_code()){
	        //$this->error("验证码错误！");
	    }
	     
        $rules = array(
            //array(验证字段,验证规则,错误提示,验证条件,附加规则,验证时间)
            array('mobile', 'require', '手机号不能为空！', 1 ),
            array('mobile','','手机号已被注册！！',0,'unique',3),
            array('password','require','密码不能为空！',1),
            array('password','5,20',"密码长度至少5位，最多20位！",1,'length',3),
        );
        	
	    $users_model=M("Users");
	     
	    if($users_model->validate($rules)->create()===false){
	        $this->errorJson($users_model->getError());
	    }
	    $mobile=I('post.mobile');
		$user_login=I('post.user_login');
		$password=I('post.password');
		$avatar=I('post.avatar');
		$user_nicename=I('post.user_nicename');
		if(empty($user_nicename)){
		$user_nicename=$mobile;	
		}
		if(empty($user_login)){
		$user_login=$mobile;	
		}
		if(empty($avatar)){
		$avatar="avatar/default_header.png";	
		}
		$mobile_verify=I('post.mobile_verify');
		$uuid='';
	    if(!sp_check_mobile_verify_code()){
	        //$this->error("手机验证码错误！");
        }
		$result= false;
		$session_mobile_code=session('mobile_code');
		if(!empty($session_mobile_code)){
        	if($session_mobile_code==$mobile_verify){
			$result = true; 
        	}
    	}
  		if(!$result){
        $model = M("Code");	
		$mobile_code=$model->where(array('mobile'=>$mobile))->find();	
		if($mobile_code['code']==$mobile_verify)
		$result = true;
        }
		
		if(!$result){
		//$this->errorJson("手机验证码错误！");	
		}
	     
		$resultUser=$this->registerImUser($user_login,$password,$user_nicename);
	    if($resultUser){
			//注册成功页面跳转
	        $entities=$resultUser['entities'];
			$entity=$entities[0];
			if($entity){
				$uuid=$entity['uuid'];	
				$resultU = true;
			}else{
			$this->errorJson("聊天注册错误！");
			}
		}else{
		$this->errorJson("聊天注册错误！");
		}
		
	    $users_model=M("Users");
	    $data=array(
			'uuid' => $uuid,
	        'user_login' => $user_login,
	        'user_email' => '',
	        'mobile' =>$mobile,
	        'user_nicename' =>$user_nicename,
	        'user_pass' => sp_password($password),
	        'avatar' => $avatar,
	        'create_time' => date("Y-m-d H:i:s"),
	        'last_login_time' => date("Y-m-d H:i:s"),
	        'user_status' => 1,
	        "user_type"=>2,//会员
	    );
		$result = $users_model->add($data);
	    if($result){
	        //注册成功页面跳转
	        $data['id']=$result;
			//$userinfo_model=M("UserInfo");
			//$userinfo_model->add(array("user_id"=>$result));
	        //session('user',$data);
			//$this->success("注册成功！");
	        $this->successJson("注册成功！",__ROOT__."/");
	         //exit(json_encode($result));
	    }else{
	        $this->errorJson("注册失败！",U("user/register/index"));
	    }
	}
	
	//注册用户
 // Orgname:comcaesar
//appname:huaxin
//Client ID:YXA6JaYeEG55EeWfDIdFJvc5xQ
//Client Secret:YXA6t5BCqNIEnt5h6c2Bb92LMUErQtM
    public function registerImUser($username,$password,$nickname){
    	$options['client_id'] = 'YXA6JaYeEG55EeWfDIdFJvc5xQ';
    	$options['client_secret'] = 'YXA6t5BCqNIEnt5h6c2Bb92LMUErQtM'; 
    	$options['org_name'] = 'comcaesar';
    	$options['app_name'] = 'huaxin'; 
    	$e = new Easemob($options);
    	$result_u = $e->createUser($username,$password);
    	$result_n = $e->editNickname($username,$nickname);
    	return $result_n;
    }
	
	// 前台用户邮件注册
	private function _do_email_register(){
	   
        if(!sp_check_verify_code()){
            $this->error("验证码错误！");
        }
        
        $rules = array(
            //array(验证字段,验证规则,错误提示,验证条件,附加规则,验证时间)
            array('email', 'require', '邮箱不能为空！', 1 ),
            array('password','require','密码不能为空！',1),
            array('password','5,20',"密码长度至少5位，最多20位！",1,'length',3),
            array('repassword', 'require', '重复密码不能为空！', 1 ),
            array('repassword','password','确认密码不正确',0,'confirm'),
            array('email','email','邮箱格式不正确！',1), // 验证email字段格式是否正确
        );
	     
	    $users_model=M("Users");
	     
	    if($users_model->validate($rules)->create()===false){
	        $this->error($users_model->getError());
	    }
	     
	    $password=I('post.password');
	    $email=I('post.email');
	    $username=str_replace(array(".","@"), "_",$email);
	    //用户名需过滤的字符的正则
	    $stripChar = '?<*.>\'"';
	    if(preg_match('/['.$stripChar.']/is', $username)==1){
	        $this->error('用户名中包含'.$stripChar.'等非法字符！');
	    }
	     
// 	    $banned_usernames=explode(",", sp_get_cmf_settings("banned_usernames"));
	     
// 	    if(in_array($username, $banned_usernames)){
// 	        $this->error("此用户名禁止使用！");
// 	    }
	    
	    $where['user_login']=$username;
	    $where['user_email']=$email;
	    $where['_logic'] = 'OR';
	    
	    $ucenter_syn=C("UCENTER_ENABLED");
	    $uc_checkemail=1;
	    $uc_checkusername=1;
	    if($ucenter_syn){
	        include UC_CLIENT_ROOT."client.php";
	        $uc_checkemail=uc_user_checkemail($email);
	        $uc_checkusername=uc_user_checkname($username);
	    }
	     
	    $users_model=M("Users");
	    $result = $users_model->where($where)->count();
	    if($result || $uc_checkemail<0 || $uc_checkusername<0){
	        $this->error("用户名或者该邮箱已经存在！");
	    }else{
	        $uc_register=true;
	        if($ucenter_syn){
	             
	            $uc_uid=uc_user_register($username,$password,$email);
	            //exit($uc_uid);
	            if($uc_uid<0){
	                $uc_register=false;
	            }
	        }
	        if($uc_register){
	            $need_email_active=C("SP_MEMBER_EMAIL_ACTIVE");
	            $data=array(
	                'user_login' => $username,
	                'user_email' => $email,
	                'user_nicename' =>$username,
	                'user_pass' => sp_password($password),
	                //'last_login_ip' => get_client_ip(0,true),
	                'create_time' => date("Y-m-d H:i:s"),
	                'last_login_time' => date("Y-m-d H:i:s"),
	                'user_status' => $need_email_active?2:1,
	                "user_type"=>2,//会员
	            );
	            $rst = $users_model->add($data);
	            if($rst){
	                //注册成功页面跳转
	                $data['id']=$rst;
	                session('user',$data);
	                	
	                //发送激活邮件
	                if($need_email_active){
	                    $this->_send_to_active();
	                    session('user',null);
	                    $this->success("注册成功，激活后才能使用！",U("user/login/index"));
	                }else {
	                    $this->success("注册成功！",__ROOT__."/");
	                }
	                	
	            }else{
	                $this->error("注册失败！",U("user/register/index"));
	            }
	             
	        }else{
	            $this->error("注册失败！",U("user/register/index"));
	        }
	         
	    }
	}
	
	// 前台用户邮件注册激活
	public function active(){
		$hash=I("get.hash","");
		if(empty($hash)){
			$this->error("激活码不存在");
		}
		
		$users_model=M("Users");
		$find_user=$users_model->where(array("user_activation_key"=>$hash))->find();
		
		if($find_user){
			$result=$users_model->where(array("user_activation_key"=>$hash))->save(array("user_activation_key"=>"","user_status"=>1));
			
			if($result){
				$find_user['user_status']=1;
				session('user',$find_user);
				$this->success("用户激活成功，正在登录中...",__ROOT__."/");
			}else{
				$this->error("用户激活失败!",U("user/login/index"));
			}
		}else{
			$this->error("用户激活失败，激活码无效！",U("user/login/index"));
		}
		
		
	}
	
	//发送手机验证码
    public function send_code(){
		
		// 短信应用SDK AppID
		$appid = 1400114025; // 1400开头

	// 短信应用SDK AppKey
	$appkey = "61322587fa7b05c89780c851284ceca7";

	// 需要发送短信的手机号码
	$phoneNumbers = "18661289339";

	// 短信模板ID，需要在短信应用中申请
	$templateId = 157358;  // NOTE: 这里的模板ID`7839`只是一个示例，真实的模板ID需要在短信控制台中申请

	// 签名
	$smsSign = "海纳科技二手手机之家"; // NOTE: 这里的签名只是示例，请使用真实的已申请的签名，签名参数使用的是`签名内容`，而不是`签名ID`
	$code = rand(100000,999999);
	$mobile = I("post.mobile",'','trim');//手机号
	//echo json_encode($mobile);exit;
        $type = I("get.type",'1','trim');//分类 1注册 2忘记密码 3更换手机号 4商品购物
        if(empty($mobile) || empty($type)){
			$this->errorJson("参数不能为空！");
            $result = array("result"=>'fail',"info"=>'fail','msg'=>'参数不能为空','code'=>102);
            exit(json_encode($result)); 
        }
        //$check = "/^1[3-5,8]{1}[0-9]{9}$/";  
        $check = "/^1[3-5,7-9]{1}[0-9]{9}$/";
        if(!preg_match($check,$mobile)){
			$this->errorJson("手机号格式不正确！");
            $result = array("result"=>'fail',"info"=>'fail','msg'=>'手机号格式不正确','code'=>103);
            exit(json_encode($result)); 
        }
		
        $model = M("Code");
        $data = array();
        
        if($type == 1){
            $no = "SMS_109680031";
        }elseif($type == 2){
            $no = "SMS_109680030";
        }elseif($type ==3){
            $no = "SMS_109680035";
        }elseif($type == 4){
            $no = "SMS_109680035";
        }
		// 单发短信
	try {
    	$ssender = new SmsSingleSender($appid, $appkey);
    	$result = $ssender->send(0, "86", $mobile,
        $code."为您的登录验证码，请于2分钟内填写。如非本人操作，请忽略本短信。", $code, $code);
    	$rsp = json_decode($result);
	} catch(\Exception $e) {
   	 	
	}
		
       
        //$sendcode = send($mobile,$code,$no);
		$sendcode['Code'] = 'OK';
        if($sendcode['Code'] == 'OK'){//成功
            $data['mobile'] = $mobile;
            $data['code'] = $code;
            $data['type'] = $type;
            $data['create_time'] = time();
            $info = $model->add($data);
			//$this->success("发送成功！");
			session('mobile_code',$code);
            $result = array("result"=>'suc',"info"=>'suc','msg'=>'发送成功','code'=>101,'codemsg'=>$code);
        }else{
			//$this->error("发送失败！");
            $result = array("result"=>'fail',"info"=>'fail','msg'=>'发送失败','code'=>104);
        }
        exit(json_encode($result));
    }
  
  
  //发送手机验证码
    public function send_code_message(){
		
		// 短信应用SDK AppID
		$appid = 1400114025; // 1400开头

	// 短信应用SDK AppKey
	$appkey = "61322587fa7b05c89780c851284ceca7";

	// 需要发送短信的手机号码
	$phoneNumbers = "18661289339";

	// 短信模板ID，需要在短信应用中申请
	$templateId = 157358;  // NOTE: 这里的模板ID`7839`只是一个示例，真实的模板ID需要在短信控制台中申请

	// 签名
	$smsSign = "海纳科技二手手机之家"; // NOTE: 这里的签名只是示例，请使用真实的已申请的签名，签名参数使用的是`签名内容`，而不是`签名ID`
	$code = rand(100000,999999);
	$mobile = I("post.mobile",'','trim');//手机号
	//echo json_encode($mobile);exit;
        $type = I("get.type",'1','trim');//分类 1注册 2忘记密码 3更换手机号 4商品购物
        if(empty($mobile) || empty($type)){
			$this->errorJson("参数不能为空！");
            $result = array("result"=>'fail',"info"=>'fail','msg'=>'参数不能为空','code'=>102);
            exit(json_encode($result)); 
        }
        //$check = "/^1[3-5,8]{1}[0-9]{9}$/";  
        $check = "/^1[3-5,7-9]{1}[0-9]{9}$/";
        if(!preg_match($check,$mobile)){
			$this->errorJson("手机号格式不正确！");
            $result = array("result"=>'fail',"info"=>'fail','msg'=>'手机号格式不正确','code'=>103);
            exit(json_encode($result)); 
        }
		
        $model = M("Code");
        $data = array();
        
        if($type == 1){
            $no = "SMS_109680031";
        }elseif($type == 2){
            $no = "SMS_109680030";
        }elseif($type ==3){
            $no = "SMS_109680035";
        }elseif($type == 4){
            $no = "SMS_109680035";
        }

// Download：https://github.com/aliyun/openapi-sdk-php
// Usage：https://github.com/aliyun/openapi-sdk-php/blob/master/README.md

AlibabaCloud::accessKeyClient('LTAI4iTDVUaYWF0N', 'T6Y0N82glQKSnZntIsqPXKj7rgtYmF')
                        ->regionId('cn-hangzhou') // replace regionId as you need
                        ->asDefaultClient();

try {
    $result = AlibabaCloud::rpc()
                          ->product('Dysmsapi')
                          // ->scheme('https') // https | http
                          ->version('2017-05-25')
                          ->action('SendSms')
                          ->method('POST')
                          ->host('dysmsapi.aliyuncs.com')
                          ->options([
                                        'query' => [
                                          'RegionId' => "default",
                                          'PhoneNumbers' => "18661289339",
                                          'SignName' => "城库货源",
                                          'TemplateCode' => "SMS_171765053",
                                        ],
                                    ])
                          ->request();
    print_r($result->toArray());
} catch (ClientException $e) {
    echo $e->getErrorMessage() . PHP_EOL;
} catch (ServerException $e) {
    echo $e->getErrorMessage() . PHP_EOL;
}


		
       
        //$sendcode = send($mobile,$code,$no);
		$sendcode['Code'] = 'OK';
        if($sendcode['Code'] == 'OK'){//成功
            $data['mobile'] = $mobile;
            $data['code'] = $code;
            $data['type'] = $type;
            $data['create_time'] = time();
            $info = $model->add($data);
			//$this->success("发送成功！");
			session('mobile_code',$code);
            $result = array("result"=>'suc',"info"=>'suc','msg'=>'发送成功','code'=>101,'codemsg'=>$code);
        }else{
			//$this->error("发送失败！");
            $result = array("result"=>'fail',"info"=>'fail','msg'=>'发送失败','code'=>104);
        }
        exit(json_encode($result));
    }
	
	
}