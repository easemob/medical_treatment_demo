<?php
namespace User\Controller;

use Common\Controller\HomebaseController;

class PostsfollowController extends HomebaseController {
	
	protected $follow_model; 
	
	public function _initialize() {
		parent::_initialize();
		$this->follow_model = M("PostsFollow");
	}
	
    // 好友关注首页
	public function index() {
		$this->assign("PostsFollow");
    	$this->display(':postsfollow');
    }
	
	public function post_follow_json() {		
		$userid=I('userid',1);
		$postid=I('postid',2);
		$posts_model=M("Posts");
		$users_model=M("Users");
		$result=$this->follow_model->where(array('user' => $userid,'postid' => $postid))->find();
		if($result){
			$this->follow_model->where(array("user"=>$userid,"postid"=>$postid))->save(array('is_care' => 1));
			$posts_model->save(array("id"=>$postid,"post_like"=>array("exp","post_like+1")));
			$users_model->save(array("id"=>$userid,"user_likes"=>array("exp","user_likes+1")));
			$this->successJson("关注成功！");
		}else{
			$datetime=time();
			$data=array(
	        'user' => $userid,
	        'postid' => $postid,
	        'follow_time' =>$datetime,
	        'is_care' => 1
	    	);
			$res=$this->follow_model->add($data);
			$posts_model->save(array("id"=>$postid,"post_like"=>array("exp","post_like+1")));
			$users_model->save(array("id"=>$userid,"user_likes"=>array("exp","user_likes+1")));
			$this->successJson("关注成功！");
		}
		
    }
	
	public function cancel_follow_json() {		
		$userid=I('userid',1);
		$postid=I('postid',2);
		$posts_model=M("Posts");
		$users_model=M("Users");
		$result=$this->follow_model->where(array('user' => $userid,'postid' => $postid))->find();
		if($result){
			$this->follow_model->where(array("user"=>$userid,"postid"=>$postid))->save(array('is_care' => 0));
			$posts_model->save(array("id"=>$postid,"post_like"=>array("exp","post_like-1")));
			$users_model->save(array("id"=>$userid,"user_likes"=>array("exp","user_likes-1")));
			$this->successJson("取消关注！");
		}else{
			$this->errorJson("您还未关注，请先关注！");
		}
		
    }
	
	public function follow_posts_json() {
		$uid=I('uid',1);
		$userid=I('userid',0,'intval');
		$field = 'tid,object_id,term_id,post_title,post_author,post_date,post_type,post_excerpt,smeta,post_status,post_authorname,post_avatar,photos_urls,post_goods,comment_count,post_hits,post_like,thumb_video';
    	$limit = '0,20';
		$where['posts.post_status'] = array('eq',1);
		$where['follow.user'] = array('eq',$uid);
		$where['follow.is_care'] = array('eq',1);
    	$join = '__POSTS__ as posts on term_relationships.object_id = posts.id';
		$join1 = '__POSTS_FOLLOW__ as follow on follow.postid = posts.id';
		$group = 'convert(post_date,DATE)';
    	$order = "follow.follow_time DESC";
    	$term_relationships_model= M("TermRelationships");
		$follow_posts=$term_relationships_model
    	    ->alias("term_relationships")
    	    ->join($join)
			->join($join1)
    	    ->field($field)
    	    ->where($where)
    	    ->order($order)
    	    ->limit($limit)
    	    ->select();
		$goods_model= M("Goods");
		$comments_model= M("Comments");
		$follow_model = M("PostsFollow");
		$care_model = M("CareFriends");
		$goods_field = 'goods_id,goods_name,goods_remark,goods_img,shop_price,good_desc,store_count';
		$comments_field ='id,post_id,uid,full_name,url,content,createtime';
		if($follow_posts){
        	foreach ($follow_posts as $key => $value) {
				if(!empty($value['smeta'])){
					if(empty($value['photos_urls'])){
					$follow_posts[$key]['photos_urls']=array();
					}else{
					$follow_posts[$key]['photos_urls']=json_decode($value['photos_urls'], true);
					}
					$follow_posts[$key]['smeta']=json_decode($value['smeta'], true);
					$follow_posts[$key]['thumb'] = $follow_posts[$key]['smeta']['thumb'];
					unset($follow_posts[$key]['smeta']);
				}
				if(!empty($value['post_goods'])){
					$goods_where['goods_id'] = array('in',$value['post_goods']);
					$goods_array=$goods_model->field($goods_field)->where($goods_where)->select();
					$follow_posts[$key]['goods_array']=$goods_array;
				}
				if(!empty($value['comment_count'])){
					$comments_where['post_id'] = array('eq',$value['object_id']);
					$comment_array=$comments_model->field($comments_field)->where($comments_where)->select();
					$follow_posts[$key]['comment_array']=$comment_array;
				}
				if(!empty($userid)){
			$care_result=$care_model->where(array('uid'=>$userid,'fuid' =>$value['post_author'],'is_care' => 1))->find();
			$follow_result=$follow_model->where(array('user'=>$userid,'postid'=>$value['object_id'],'is_care'=> 1))->find();
			$follow_posts[$key]['author_follow']=$care_result?true:false;
			$follow_posts[$key]['post_follow']=$follow_result?true:false;		
				}
			}
			$this->successJson("获取关注文章列表成功!",$follow_posts);
		}else{
			$this->errorJson("此用户暂未收藏文章!");
		}
    }
	
	
}
