<?php

namespace User\Controller;
use Common\Controller\HomebaseController;

class ListController extends HomebaseController {

	// 前台文章列表
	public function index() {
	    $term_id=I('get.id',0,'intval');
		$term=sp_get_term($term_id);
		
		if(empty($term)){
		    header('HTTP/1.1 404 Not Found');
		    header('Status:404 Not Found');
		    if(sp_template_file_exists(MODULE_NAME."/404")){
		        $this->display(":404");
		    }
		    return;
		}
		
		$tplname=$term["list_tpl"];
    	$tplname=sp_get_apphome_tpl($tplname, "list");
    	$this->assign($term);
    	$this->assign('cat_id', $term_id);
    	$this->display(":$tplname");
	}

	// 获取推荐人才列表及职位
	public function getRecommendPersonnelList() {
		$user_id = I('user_id',1);
		$page=I('page',0,'intval');
		$limit = ($page*10).','.(10);
		$order = 'listorder DESC';
		$field_per = 'id,user_login,user_nicename,user_type,avatar,mobile,area_address,area_address1';
		$where_per['id'] = array('neq',$user_id);
		$where_per['user_status'] = array('eq',1);
		$where_per['user_type'] = array('eq',3);
		$peopleList=M('Users')->field($field_per)->where($where_per)->order($order)->limit($limit)->select();
		// echo M('Users')->getLastSql();exit;
      	$this->successJson("获取推荐律师列表成功！",$peopleList);
	}

	// 获取指定用户名单
	public function getRecPersonnelList() {
		$user_id = I('user_id',1);
		$page=I('page',0,'intval');
		$limit = ($page*10).','.(10);
		$field_per = 'id,user_login,user_nicename,user_type,avatar,mobile,area_address,area_address1';
		$where_per['id'] = array('neq',$user_id);
		$where_per['user_status'] = array('eq',1);
		$where_per['user_type'] = array('eq',3);
		$peopleList=M('Users')->field($field_per)->where($where_per)->order('rand()')->limit($limit)->select();
		if(empty($page)){
			$where_per['listorder'] = array('gt',0);
			$recomList=M('Users')->field($field_per)->where($where_per)->order('listorder DESC')->limit('0,10')->select();
			if($recomList){
				array_unshift($peopleList,$recomList);
			}
		}
      	$this->successJson("获取推荐律师列表成功！",$peopleList);
	}
	
	
	// 内容管理文章列表
	public function indexJson(){
		$term_id=I('get.cid',0,'intval');
		$lists = sp_sql_posts_paged("cid:$term_id;order:post_date DESC;",20);
		$this->successJson("获取信息列表成功!",$lists);
	}
	
	// 个人内容管理文章列表
	public function indexPersonalHitsJson(){
		$userid=I('get.userid',0,'intval');
		$term_id=I('get.cid');
		$common_action_log_model=M("CommonActionLog");
		$action="Portal-Article-do_hits";
		$where=array("user"=>$userid,"action"=>$action);
		$find_log=$common_action_log_model->where($where)->find();
		$where['term_relationships.term_id']=$term_id;
		if (isset($term_id)) {
    	    $term_id=explode(',', $term_id);
    	    $term_id=array_map('intval', $term_id);
    		$where['term_relationships.term_id'] = array('in',$term_id);
    	}
		$field = '*';
    	$limit = '0,20';
    	$order = 'count DESC';
    
    	//根据参数生成查询条件
    	$where['posts.post_status'] = array('eq',1);
		$join = '__TERM_RELATIONSHIPS__ as term_relationships on common_action_log.postid = term_relationships.object_id';
		$join2 = '__POSTS__ as posts on common_action_log.postid = posts.id';
    	$posts=$common_action_log_model
    	    ->alias("common_action_log")
    	    ->join($join)
    	    ->join($join2)
			->field($field)
    	    ->where($where)
    	    ->order($order)
    	    ->limit($limit)
    	    ->select();
		
		$this->successJson("获取个人相关信息列表成功!",$posts);
	}
	
	// 个人内容管理文章列表
	public function indexPersonalLikeJson(){
		$userid=I('get.userid',0,'intval');
		$term_id=I('get.cid',0,'intval');
		$common_action_log_model=M("CommonActionLog");
		$action="Portal-Article-do_like";
		$where=array("user"=>$userid,"action"=>$action);
		$find_log=$common_action_log_model->where($where)->find();
		$where['term_relationships.term_id']=$term_id;
		$field = '*';
    	$limit = '0,10';
    	$order = 'post_date DESC';
    
    	//根据参数生成查询条件
    	$where['posts.post_status'] = array('eq',1);
		$join = '__TERM_RELATIONSHIPS__ as term_relationships on common_action_log.postid = term_relationships.object_id';
		$join2 = '__POSTS__ as posts on common_action_log.postid = posts.id';
    	$posts=$common_action_log_model
    	    ->alias("common_action_log")
    	    ->join($join)
    	    ->join($join2)
			->field($field)
    	    ->where($where)
    	    ->order($order)
    	    ->limit($limit)
    	    ->select();
		
		$this->successJson("获取个人相关信息列表成功!",$posts);
	}
	
	// 个人内容管理文章列表
	public function indexPersonalFavoriteJson(){
		$uid=I('get.uid',0,'intval');
		$term_id=I('get.cid',0,'intval');
		$user_favorites_model=M("UserFavorites");
		$find_favorite=$user_favorites_model->where(array('table'=>'posts','uid'=>$uid))->find();
		$where['term_relationships.term_id']=$term_id;
		$field = '*';
    	$limit = '0,20';
    	$order = 'post_date DESC';
    
    	//根据参数生成查询条件
    	$where['posts.post_status'] = array('eq',1);
		$join = '__TERM_RELATIONSHIPS__ as term_relationships on common_action_log.postid = term_relationships.object_id';
		$join2 = '__POSTS__ as posts on common_action_log.postid = posts.id';
    	$posts=$common_action_log_model
    	    ->alias("common_action_log")
    	    ->join($join)
    	    ->join($join2)
			->field($field)
    	    ->where($where)
    	    ->order($order)
    	    ->limit($limit)
    	    ->select();
		
		$this->successJson("获取个人相关信息列表成功!",$posts);
	}
	
	// 幻灯片列表
	public function indexReplayJson(){
		$where['parent'] = array('eq',6);
		$terms=M("Terms")->field('term_id,name,parent')->where($where)->order('term_id')->select();
		$replay_terms="";
		foreach ($terms as $r) {
			$replay_terms=$replay_terms.$r['term_id'].",";
		}
		$lists = sp_sql_posts_paged("cid:$replay_terms;order:post_date DESC;",10);
		$this->successJson("获取报价列表成功!",$lists);
	}
	
	// 获取首页主页信息
	public function indexHomeJson(){
		$term_id=I('get.cid',0,'intval');
		$lists1 = sp_sql_posts_paged("cid:1;order:post_date DESC;",10);
		$lists2 = sp_sql_posts_paged("cid:2;order:post_date DESC;",10);
		$lists3 = sp_sql_posts_paged("cid:3;order:post_date DESC;",10);
		$lists5 = sp_sql_posts_paged("cid:5;order:post_date DESC;",10);
		$data=array("lists1"=>$lists1,"lists2"=>$lists2,"lists3"=>$lists3,"lists5"=>$lists5);
		$this->successJson("获取首页主信息成功!",$data);
	}
	
	// 获取首页主页信息
	public function indexHotJson(){
		$term_id=I('get.cid',0,'intval');
		$lists = sp_sql_posts_paged("cid:3;order:post_date DESC;",10);
		$lists1 = sp_sql_posts_paged("cid:2;order:post_date DESC;",10);
		$lists2 = sp_sql_posts_paged("cid:5;order:post_date DESC;",10);
		$data=array("lists"=>$lists,"lists1"=>$lists1,"lists2"=>$lists2);
		$this->successJson("获取首页主信息成功!",$data);
	}
	
	// 文章分类列表接口,返回文章分类列表,用于后台导航编辑添加
	public function nav_index(){
		$navcatname="文章分类";
        $term_obj= M("Terms");

        $where=array();
        $where['status'] = array('eq',1);
        $terms=$term_obj->field('term_id,name,parent')->where($where)->order('term_id')->select();
		$datas=$terms;
		$navrule = array(
		    "id"=>'term_id',
            "action" => "Portal/List/index",
            "param" => array(
                "id" => "term_id"
            ),
            "label" => "name",
		    "parentid"=>'parent'
        );
		return sp_get_nav4admin($navcatname,$datas,$navrule) ;
	}
}
