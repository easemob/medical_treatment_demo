<?php
namespace User\Controller;

use Common\Controller\HomebaseController;

class CarefriendsController extends HomebaseController {
	
	protected $care_model; 
	
	public function _initialize() {
		parent::_initialize();
		$this->care_model = M("CareFriends");
	}
	
    // 好友关注首页
	public function index() {
		$this->assign("User");
    	$this->display(':carefriends');
    }
	
	public function add_care_json() {
		$uid=I('uid',1);
		$fuid=I('fuid',2);
		$users_model=M("Users");
		$result=$this->care_model->where(array('uid' => $uid,'fuid' => $fuid))->find();
		if($result){
			$this->care_model->save(array("uid"=>$uid,"fuid"=>$fuid,'is_care' => 1));
			$users_model->save(array("id"=>$uid,"user_cares"=>array("exp","user_cares+1")));
			$users_model->save(array("id"=>$fuid,"user_follows"=>array("exp","user_follows+1")));
			$this->successJson("关注成功！");
		}else{
			$datetime=date("Y-m-d H:i:s",time());
			$data=array(
	        'uid' => $uid,
	        'fuid' => $fuid,
	        'add_time' =>$datetime,
	        'update_time' =>$datetime,
	        'is_care' => 1
	    	);
			$this->care_model->add($data);
			$users_model->save(array("id"=>$uid,"user_cares"=>array("exp","user_cares+1")));
			$users_model->save(array("id"=>$fuid,"user_follows"=>array("exp","user_follows+1")));
			$this->successJson("关注成功！");
		}
		
    }
	
	public function cancel_care_json() {
		$uid=I('uid',1);
		$fuid=I('fuid',2);
		$result=$this->care_model->where(array('uid' => $uid,'fuid' => $fuid))->find();
		if($result){
			$this->care_model->save(array("uid"=>$uid,"fuid"=>$fuid,'is_care' => 0));
			$users_model->save(array("id"=>$uid,"user_cares"=>array("exp","user_cares-1")));
			$users_model->save(array("id"=>$fuid,"user_follows"=>array("exp","user_follows-1")));
			$this->successJson("取消关注成功！");
		}else{
			$this->errorJson("您还未关注，请先关注！");
		}
		
    }
	
	public function care_friends_json() {
		$uid=I('uid',1);
		$userid=I('userid',2,'intval');
		$where = array('b.uid' => $uid,'b.is_care' => 1);
		$join = '__CARE_FRIENDS__ as b on a.id=b.fuid';
		$field = 'a.id,a.user_login,a.avatar,a.user_nicename,a.sex';
		$order = "add_time desc";
		$care_list=M('Users')
    	    ->alias("a")
    	    ->join($join)
    	    ->field($field)
    	    ->where($where)
    	    ->order($order)
    	    ->select();
			//echo M()->getLastSql();exit;
		$this->successJson("获取关注好友列表成功!",$care_list);
    }
	
	public function follow_friends_json() {
		$fuid=I('fuid',1);
		$userid=I('userid',2,'intval');
		$where = array('b.fuid' => $fuid,'b.is_care' => 1);
		$join = '__CARE_FRIENDS__ as b on a.id=b.uid';
		$field = 'a.id,a.user_login,a.avatar,a.user_nicename,a.sex';
		$order = "add_time desc";
		$care_list=M('Users')
    	    ->alias("a")
    	    ->join($join)
    	    ->field($field)
    	    ->where($where)
    	    ->order($order)
    	    ->select();
		$this->successJson("获取粉丝列表成功!",$care_list);
    }
	
	
	public function personal_cares_json() {
		$uid=I('uid',1);
		$userid=I('userid',2,'intval');
		$join = 'INNER JOIN (SELECT b.fuid,b.add_time , c.uid
FROM (SELECT * FROM `cmf_care_friends` WHERE `uid` ='.$uid.' AND `is_care` =1) AS b LEFT JOIN (SELECT * FROM `cmf_care_friends` WHERE `uid` ='.$userid.' AND `is_care` =1) AS c ON b.fuid = c.fuid) as d on d.fuid = a.id';
		$field = 'a.id,a.user_login,a.avatar,a.user_nicename,a.sex,d.add_time,IFNULL(d.uid,false) as self_friend';
		$order = "add_time desc";
		$care_list=M('Users')
    	    ->alias("a")
    	    ->join($join)
    	    ->field($field)
    	    ->order($order)
    	    ->select();
			//echo M()->getLastSql();exit;
		if($care_list){
		$this->successJson("获取关注好友列表成功!",$care_list);
		}else{
		$this->errorJson("暂无关注好友信息!");
		}
		
	}
	
	public function personal_follows_json() {
		$uid=I('uid',1);
		$userid=I('userid',2,'intval');
		$join = 'INNER JOIN (SELECT b.uid,b.add_time , c.fuid
FROM (SELECT * FROM `cmf_care_friends` WHERE `fuid` ='.$uid.' AND `is_care` =1) AS b LEFT JOIN (SELECT * FROM `cmf_care_friends` WHERE `uid` ='.$userid.' AND `is_care` =1) AS c ON b.uid = c.fuid) as d on d.uid = a.id';
		$field = 'a.id,a.user_login,a.avatar,a.user_nicename,a.sex,d.add_time,IFNULL(d.fuid,false) as self_friend';
		$order = "add_time desc";
		$care_list=M('Users')
    	    ->alias("a")
    	    ->join($join)
    	    ->field($field)
    	    ->order($order)
    	    ->select();
			//echo M()->getLastSql();exit;
		if($care_list){
		$this->successJson("获取粉丝列表成功!",$care_list);
		}else{
		$this->errorJson("暂无粉丝信息!");
		}
		
	}
	
	
}
