<?php
namespace User\Controller;

use Common\Controller\HomebaseController;

class PersonalController extends HomebaseController {
	
	// 获取个人资料(新增商品足迹和心愿单)
    public function get_personal_json() {
		$field = 'id,user_login,user_nicename,avatar,sex,signature,user_type,
		region_code,user_collection,user_cares,user_follows,user_posts,user_likes';
      	$user_id=I('post.user_id',1);
		$user_model=M("Users");
		$result=$user_model->where(array("id"=>$user_id))->field($field)->find();
    	if($result){
		$this->successJson("获取个人资料成功！",$result);
		}else{
		$this->errorJson("获取个人资料失败！");
		}
	}
	
	// 创建某一个话题的社区（后台设置权限）
	public function create_posts_group() {
		$user_model=M("Users");
		$group_model=M("Groups");
		$group_members_model=M("GroupMembers");
		$user_id=I('post.user_id',1);
		$group_name=I('post.group_name');
		$group_data=I('post.');
		$group_data['creatorId']=$user_id;
		if(empty($user_id)){
			$this->errorJson("创建者不能为空！");
		}
		if(empty($group_name)){
			$this->errorJson("创建的社区名称不能为空！");
		}
		$result=$group_model->where(array("creatorId"=>$user_id))->find();
		if($result){
			$this->errorJson("您已创建过社区");
		}else{
			$timestamp=time();
			$datetime=date("Y-m-d H:i:s",time());
			$group_data['timestamp']=$timestamp;
			$group_data['createdAt']=$datetime;
			$group_data['updatedAt']=$datetime;
			$group_data['group_state']=1;
			$group_res=$group_model->create($group_data);
			if ($group_res) {
				$res=$group_model->add();
				$user_data=$user_model->where(array("id"=>$user_id))->find();
				$member_data=array(
	        	'groupId' => $res,
	        	'memberId' => $user_id,
	        	'displayName' =>$user_data['user_nicename'],
				'dispalyAvatar'=>$user_data['avatar'],
	        	'role' => 1,
				'timestamp' => $timestamp,
				'createdAt' => $datetime,
				'updatedAt' => $datetime,
	    		);
				$group_members_model->add($member_data);
				$this->successJson("话题的社区创建成功！");
			}else{
				$this->errorJson($posts_model->getError());
			}
		}
	}
	
	// 加入某一个话题的社区（后台设置权限）
	public function join_posts_group() {
		$user_model=M("Users");
		$group_model=M("Groups");
		$group_members_model=M("GroupMembers");
		$user_id=I('post.user_id',1);
		$group_id=I('post.group_id');
		$member_data=I('post.');
		$result=$group_model->where(array("group_id"=>$group_id))->find();
		if(empty($user_id)){
			$this->errorJson("加入者不能为空！");
		}
		if(empty($group_id)){
			$this->errorJson("加入社区不能为空！");
		}
		if(empty($result)){
			$this->errorJson("暂无此社区");
		}else{
			$res=$group_members_model->where(array("groupId"=>$group_id,"memberId"=>$user_id))->find();
			if($res){
			$this->errorJson("您已加入话题社区,请勿重复操作");
			}else{
			$timestamp=time();
			$datetime=date("Y-m-d H:i:s",time());
			$user_data=$user_model->where(array("id"=>$user_id))->find();
			$member_data['groupId']=$group_id;
			$member_data['memberId']=$user_id;
			$member_data['displayName']=$user_data['user_nicename'];
			$member_data['dispalyAvatar']=$user_data['avatar'];
			$member_data['timestamp']=$timestamp;
			$member_data['createdAt']=$datetime;
			$member_data['updatedAt']=$datetime;
			$res=$group_members_model->add($member_data);
			$group_model->save(array("group_id"=>$group_id,"memberCount"=>array("exp","memberCount+1")));
			$this->successJson("加入话题社区成功！");
			}
		}
		
	}
	
	
	// 某用户加入的所有社区
	public function personal_joined_groups() {
		$group_members_model=M("GroupMembers");
		$user_id=I('post.user_id',1);
		if(empty($user_id)){
			$this->errorJson("用户ID不能为空！");
		}else{
			$field = 'postsgroups.group_id,group_name,portraitUri,memberCount,postCount,bulletin,role';
    		$limit = '0,20';
			$where['group_members.memberId'] = array('eq',$user_id);
			$where['postsgroups.group_state'] = array('eq',1);
			$where['group_members.member_state'] = array('eq',0);
			$join = '__POSTS_GROUPS__ as postsgroups on postsgroups.group_id = group_members.groupId';
    		$order = "group_members.timestamp DESC";
			$group_list=$group_members_model->alias("group_members")->join($join)->field($field)
			->where($where)->order($order)->limit($limit)->select();
			if($group_list){
				$this->successJson("获取关注话题社区成功！",$group_list);
			}else{
				$this->errorJson("暂无关注社区信息");
			}
		}
	}
	
	// 获取某社区下所有成员信息
	public function post_group_members() {
		$group_members_model=M("GroupMembers");
		$group_id=I('post.group_id',1);
		if(empty($group_id)){
			$this->errorJson("社区ID不能为空！");
		}else{
			$field = 'users.id,user_login,user_nicename,avatar,sex,role';
    		$limit = '0,50';
			$where['group_members.groupId'] = array('eq',$group_id);
			$where['group_members.member_state'] = array('eq',1);
			$where['users.user_status'] = array('eq',1);
			$join = '__USERS__ as users on users.id = group_members.memberId';
    		$order = "group_members.timestamp DESC";
			$member_list=$group_members_model->alias("group_members")->join($join)->field($field)
			->where($where)->order($order)->limit($limit)->select();
			if($member_list){
				$this->successJson("获取社区成员成功！",$member_list);
			}else{
				$this->errorJson("暂无此社区");
			}
		}
		
	}
	
	
}
