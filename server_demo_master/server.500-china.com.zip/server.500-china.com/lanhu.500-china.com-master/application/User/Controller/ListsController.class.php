<?php
// +----------------------------------------------------------------------
// | ThinkCMF [ WE CAN DO IT MORE SIMPLE ]
// +----------------------------------------------------------------------
// | Copyright (c) 2013-2014 http://www.thinkcmf.com All rights reserved.
// +----------------------------------------------------------------------
// | Author: Dean <zxxjjforever@163.com>
// +----------------------------------------------------------------------
namespace User\Controller;
use Common\Controller\HomebaseController;

class ListController extends HomebaseController {

	// 前台文章列表
	public function index() {
    	$this->display(":$tplname");
	}
	
	// 获取推荐人才列表及职位
	public function getPersonnelPostList() {
		$user_id = I('post.user_id',1);
		$field_per = 'id,rongid,user_login,user_nicename,user_type,avatar,mobile';
		$where_per['id'] = array('neq',$user_id);
		$where_per['user_status'] = array('eq',1);
		$where_per['user_type'] = array('eq',3);
		$limit = '0,4';
		$pro_result=M('Users')->field($field_per)->where($where_per)->limit($limit)->select();
		$where_per['user_type'] = array('eq',4);
		$ser_result=M('Users')->field($field_per)->where($where_per)->find();
		if($ser_result){
			array_unshift($pro_result,$ser_result);
		}
		$fiel = 'user_recruit.*,users.rongid';
		$joins = '__USERS__ as users on users.id = user_recruit.user_id';
		$recruit_array=M("UserRecruit")->alias("user_recruit")->join($joins)->field($fiel)->where(array('recruit_show'=>'1'))->limit($limit)->select();
		$where = array("post_status"=>1);
		$order = 'post_date DESC';
		$field = 'recruit_post.*,user_company.company_name,users.rongid';
		$join = '__USER_COMPANY__ as user_company on user_company.user_id = recruit_post.post_author';
		$join1 = '__USERS__ as users on users.id = recruit_post.post_author';
		$company_array=M("RecruitPost")->alias("recruit_post")->join($join)->join($join1)->field($field)->where($where)->limit($limit)->order($order)->select();
      	$list['jobList']=$company_array;
      	$list['personnelList']=$recruit_array;
		$list['peopleList']=$pro_result;
      	$this->successJson("获取推荐人才列表成功！",$list);
	}
	
	// 申请职位
	public function applyRecruitPost() {
		$user_id = I('post.user_id',1);
		$post_id = I('post.post_id',1);
		$post_like=M("RecruitPost")->where(array('post_id'=>$post_id))->getField('post_like');
		if(empty($post_like)){
			$res=M("RecruitPost")->where(array('post_id'=>$post_id))->setField('post_like',$user_id);
			$this->successJson("申请职位成功！",$res);	
		}else{
			$apply_array=explode(',',$post_like);
			if(in_array($user_id, $apply_array)){
				$this->errorJson("已经申请，请勿重复申请！");		
			}else{
				$res=M("RecruitPost")->where(array('post_id'=>$post_id))->setField('post_like',$post_like.','.$user_id);
				$this->successJson("申请职位成功！",$res);	
			}
		}
	}
  
 // 获取推荐人才列表
	public function get_personnel_recruits() {
		$recruit_salary = I('post.recruit_salary');
		$recruit_grade = I('post.recruit_grade');
		$recruit_place = I('post.recruit_place');
		$where['recruit_show']= array('eq',1);
		if(!empty($recruit_salary)){
			$where['recruit_salary']= array('eq',$recruit_salary);
		}
		if(!empty($recruit_grade)){
			$where['recruit_grade']= array('eq',$recruit_grade);
		}
		if(!empty($recruit_place)&&($recruit_place!=="100000")){
			$where['recruit_place']= array('eq',$recruit_place);
		}
		$field = 'user_recruit.*,users.rongid';
		$join = '__USERS__ as users on users.id = user_recruit.user_id';
		$recruit_array=M("UserRecruit")->alias("user_recruit")->join($join)->field($field)->where($where)->select();
		if(empty($recruit_array)){
			$this->errorJson("获取推荐人才列表失败！");
		}else{
			$this->successJson("获取推荐人才列表成功！",$recruit_array);
		}
	}
	
	// 获取求职人才列表
	public function getApplyRecruits() {
		$user_id = I('post.user_id',1);
		$field = 'post_id,post_author,post_title,post_like';
		$post_where = array("post_author"=>$user_id);
		$recruitPosts=M("RecruitPost")->field($field)->where($post_where)->select();
		if($recruitPosts){
			foreach ($recruitPosts as $key=>$recruit){
				if(empty($recruit['post_like'])){
					unset($recruitPosts[$key]);
				}else{
					$where['user_id'] = array('in',$recruit['post_like']);
					$where['recruit_show'] = array('eq',1);
					$field = 'user_recruit.*,users.rongid';
					$join = '__USERS__ as users on users.id = user_recruit.user_id';
					$recruit_array=M("UserRecruit")->alias("user_recruit")->join($join)->field($field)->where($where)->select();
					$recruitPosts[$key]['apply_users']=$recruit_array;
				}
			}
			$recruitPosts = array_values($recruitPosts);
			$this->successJson("获取求职列表成功！",$recruitPosts);
		}else{
			$this->errorJson("暂未发布职位！");
		}
	}
  
  // 获取指定标签用户数
	public function getUserNumberForPath(){
		$user_industry = I('post.user_industry',0);//users表中user_industry
		$user_profession = I('post.user_profession',0);//users表中user_industry
		$user_soft = I('post.user_soft',0);//users表中user_industry
		$where['user_status'] = array('eq',1);
      	$user_where=array();
		if(!empty($user_industry)){
		$industry_ids=explode(',', $user_industry);
		array_push($industry_ids,0);
		$industry_str = implode('|', $industry_ids);
		$user_where[] = "CONCAT (',',user_industry,',') REGEXP ',(".$industry_str."),'";
		}
		if(!empty($user_profession)){
		$profession_ids=explode(',', $user_profession);
		array_push($profession_ids,0);
		$profession_str = implode('|', $profession_ids);
		$user_where[] = "CONCAT (',',user_profession,',') REGEXP ',(".$profession_str."),'";
		}
		if(!empty($user_soft)){
		$soft_ids=explode(',', $user_soft);
		array_push($soft_ids,0);
		$soft_str = implode('|', $soft_ids);
		$user_where[] = "CONCAT (',',user_soft,',') REGEXP ',(".$soft_str."),'";
		}
      	if(!empty($user_where)){
		$user_where['_logic'] = 'or'; 
		$where['_complex'] = $user_where;
		}
      	$user_number=M("Users")->where($where)->count();
      	//echo M("Users")->getLastSql();exit;
		$this->successJson("获取指定标签用户数成功!",$user_number);
	}
  
  // 内容管理文章列表
	public function test_json(){
      	$where[] = "CONCAT (',',user_industry,',') REGEXP ',(0|1),'";
      	$where[] = "CONCAT (',',user_profession,',') REGEXP ',(0|1),'";
      	$where['_logic'] = 'or'; 
      	//$lists=M("Users")->where($where)->select();
      	$lists=M("Users")->where($where)->select();
      	echo M("Users")->getLastSql();
		$this->successJson("获取信息列表成功!",$lists);
	}
  
  // 内容管理文章列表
	public function user_industry_json(){
		$lists=M("UserIndustry")->select();	
		$this->successJson("获取信息列表成功!",$lists);
	}
  
 	// 内容管理文章列表
	public function user_profession_json(){
		$lists=M("UserProfession")->select();	
		$this->successJson("获取信息列表成功!",$lists);
	}
  
  	// 内容管理文章列表
	public function user_soft_json(){
		$lists=M("UserSoft")->select();	
		$this->successJson("获取信息列表成功!",$lists);
	}
  
}
