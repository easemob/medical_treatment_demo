<?php
return array(
	//更改googs、user config
	'ORDER_STATUS' => array(
        0 => '<span style="color:#d4282d;">待确认</span>',
        1 => '已确认',
        2 => '订单完成',
        3 => '<span style="color:#d4282d;">退货</span>',                
        4 => '<span style="color:#d4282d;">已取消</span>',
    ),
    'SHIPPING_STATUS' => array(
        0 => '<span style="color:#d4282d;">未发货</span>',
        1 => '已发货',        
        2 => '已收货',        
    ),
    'PAY_STATUS' => array(
        0 => '<span style="color:#d4282d;">等待付款</span>',
        1 => '已付款',
        3 => '货到付款',
    ),	
	
);