<?php
return array(
		"USERNAME" => 'Username',
		"NICENAME" => 'Nicename',
		'GENDER' => 'Gender',
		"EMAIL" => 'Email',
		"REGISTRATION_TIME" => 'Registration Time',
		"LAST_LOGIN_TIME" => "Last Login Time",
		"LAST_LOGIN_IP" => 'Last Login IP',
		"STATUS" => 'Status',
		"ACTIONS" => "Actions",
		"USER_STATUS_BLOCKED" => 'Blocked',
		"USER_STATUS_ACTIVATED" => 'Activated',
		"USER_STATUS_UNVERIFIED" => 'Unverified',
		"BLOCK_USER" =>'Block',
		"BLOCK_USER_CONFIRM_MESSAGE" =>'Are you sure you want to pull black this user?',
		"ACTIVATE_USER" =>'Activate',
		"ACTIVATE_USER_CONFIRM_MESSAGE" =>'Are you sure you want to enable this user?',
		"THIRD_PARTY_USER" => "Third Party User",
		"NOT_FILLED" => "Not Filled"
);