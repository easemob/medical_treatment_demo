<?php
namespace App\Controller;

require  __ROOT__."./vendor/autoload.php";

use Common\Controller\HomebaseController;

use Qcloud\Sms\SmsSingleSender;
use Qcloud\Sms\SmsMultiSender;
use Qcloud\Sms\SmsVoiceVerifyCodeSender;
use Qcloud\Sms\SmsVoicePromptSender;
use Qcloud\Sms\SmsStatusPuller;
use Qcloud\Sms\SmsMobileStatusPuller;

class UsersController extends HomebaseController {
	
	//查看订单
	public function order_detail(){
		$user_id= I("userid"); // 用户ID
		$order_id = I('order_id');
		$where = array('user_id'=>$user_id,'order_id'=>$order_id,'is_del'=>0);
		$order = M('GoodsOrder')->where($where)->find();
		//echo M()->getLastSql();exit;		
		if(empty($order)){
			$this->errorJson('订单不存在');
		}
		//商品信息
		$order_goods = M('GoodsOrderSub')
			->field(array('a.*,b.goods_img',"(a.goods_num * a.member_goods_price)"=>"goods_total"))
			->alias('a')
			->join('__GOODS__ b ON a.goods_id = b.goods_id')
			->where(array("order_id" => $order_id))
			->select();
		$address = getAreaName($order['province'],$order['city'],$order['district']);
		$order['address_info'] = $address;
		
		//订单操作记录
		$log_where['order_id'] = $order_id;
		$log_where['status_desc'] = array(array('neq','cancel'),array('neq','pay'));		 
		$order_log = M('GoodsOrderLog')->group('status_desc')->where($log_where)->order('log_time ASC')->find();
				
		$orderData['order']=$order;
		$orderData['order_goods']=$order_goods;		
		$orderData['order_log']=$order_log;	
		$this->successJson('订单完成',$orderData);
	}
	
	//发送手机验证码
    public function send_code($code=0){
		
		// 短信应用SDK AppID
		$appid = 1400237328; // 1400开头

	// 短信应用SDK AppKey
	$appkey = "c3e031a7221df5c3b86f71f22349fe3f";

	// 需要发送短信的手机号码
	$phoneNumbers = "18661289339";

	// 短信模板ID，需要在短信应用中申请
	$templateId = 386977;  // NOTE: 这里的模板ID`7839`只是一个示例，真实的模板ID需要在短信控制台中申请

	// 签名
	$smsSign = "结绳网络技术有限公司"; // NOTE: 这里的签名只是示例，请使用真实的已申请的签名，签名参数使用的是`签名内容`，而不是`签名ID`
      if(empty($code)){
        $code = rand(100000,999999);
      }
	
      
      $mobile = I("post.mobile",'','trim');//手机号
	//echo json_encode($mobile);exit;
        $type = I("post.type",'1','trim');//分类 1注册 2忘记密码 3更换手机号 4商品购物
        if(empty($mobile) || empty($type)){
			$this->errorJson("参数不能为空！");
            $result = array("result"=>'fail',"info"=>'fail','msg'=>'参数不能为空','code'=>102);
            exit(json_encode($result)); 
        }
        //$check = "/^1[3-5,8]{1}[0-9]{9}$/";  
        $check = "/^1[3-9]{1}[0-9]{9}$/";
        if(!preg_match($check,$mobile)){
			$this->errorJson("手机号格式不正确！");
            $result = array("result"=>'fail',"info"=>'fail','msg'=>'手机号格式不正确','code'=>103);
            exit(json_encode($result)); 
        }
		
        $model = M("Code");
        $data = array();
        
        if($type == 1){
            $no = "SMS_109680031";
        }elseif($type == 2){
            $no = "SMS_109680030";
        }elseif($type ==3){
            $no = "SMS_109680035";
        }elseif($type == 4){
            $no = "SMS_109680035";
        }
		// 单发短信
      $mobile_verify = I("post.mobile_verify",'','trim');//手机号
      if(empty($mobile_verify)){
        //$mobile_verify =$code;
      }
	try {
    	$ssender = new SmsSingleSender($appid, $appkey);
      
      if(empty($mobile_verify)){
        $mobile_verify =$code;
        $result = $ssender->send(0, "86", $mobile,
        $code."为您的登录验证码，请于2分钟内填写。如非本人操作，请忽略本短信。", $code, $code);
    	$rsp = json_decode($result);
        $users_model=M('Users');
        $wherec = array("user_status"=>1);
        $wherec['mobile']=$mobile;
        $result=$users_model->where($wherec)->save(array('user_pass_code' => sp_password($code)));
      }else{
      	$code =$mobile_verify;
       	$templateId = 387679;   
        $result = $ssender->send(0, "86", $mobile,
        "唐山城库，欢迎使用河北城库移动客户端，有色废旧金属资讯实时更新。用户名：".$mobile."，密码：".$code."，欢迎使用。");
      }
    	
	} catch(\Exception $e) {
   	 	
	}
		
       
        //$sendcode = send($mobile,$code,$no);
		$sendcode['Code'] = 'OK';
        if($sendcode['Code'] == 'OK'){//成功
            $data['mobile'] = $mobile;
            $data['code'] = $code;
            $data['type'] = $type;
            $data['create_time'] = time();
            $info = $model->add($data);
			//$this->success("发送成功！");
			session('mobile_code',$code);
            $result = array("result"=>'suc',"info"=>'suc','msg'=>'发送成功','code'=>101,'codemsg'=>$code);
        }else{
			//$this->error("发送失败！");
            $result = array("result"=>'fail',"info"=>'fail','msg'=>'发送失败','code'=>104);
        }
      $this->successJson("发送成功！");
    }
}
