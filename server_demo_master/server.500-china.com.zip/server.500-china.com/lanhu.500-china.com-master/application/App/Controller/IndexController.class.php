<?php
/*
 *      _______ _     _       _     _____ __  __ ______
 *     |__   __| |   (_)     | |   / ____|  \/  |  ____|
 *        | |  | |__  _ _ __ | | _| |    | \  / | |__
 *        | |  | '_ \| | '_ \| |/ / |    | |\/| |  __|
 *        | |  | | | | | | | |   <| |____| |  | | |
 *        |_|  |_| |_|_|_| |_|_|\_\\_____|_|  |_|_|
 */
/*
 *     _________  ___  ___  ___  ________   ___  __    ________  _____ ______   ________
 *    |\___   ___\\  \|\  \|\  \|\   ___  \|\  \|\  \ |\   ____\|\   _ \  _   \|\  _____\
 *    \|___ \  \_\ \  \\\  \ \  \ \  \\ \  \ \  \/  /|\ \  \___|\ \  \\\__\ \  \ \  \__/
 *         \ \  \ \ \   __  \ \  \ \  \\ \  \ \   ___  \ \  \    \ \  \\|__| \  \ \   __\
 *          \ \  \ \ \  \ \  \ \  \ \  \\ \  \ \  \\ \  \ \  \____\ \  \    \ \  \ \  \_|
 *           \ \__\ \ \__\ \__\ \__\ \__\\ \__\ \__\\ \__\ \_______\ \__\    \ \__\ \__\
 *            \|__|  \|__|\|__|\|__|\|__| \|__|\|__| \|__|\|_______|\|__|     \|__|\|__|
 */
// +----------------------------------------------------------------------
// | ThinkCMF [ WE CAN DO IT MORE SIMPLE ]
// +----------------------------------------------------------------------
// | Copyright (c) 2013-2014 http://www.thinkcmf.com All rights reserved.
// +----------------------------------------------------------------------
// | Author: Dean <zxxjjforever@163.com>
// +----------------------------------------------------------------------
namespace App\Controller;

Vendor('JPush.autoload');
use JPush\Client as JPushClient;
use Think\Controller;
// 引入鉴权类
use Qiniu\Auth;
// 引入上传类
use Qiniu\Storage\UploadManager;
use Common\Controller\HomebaseController; 
/**
 * 首页
 */
class IndexController extends HomebaseController {
	
	public function index() {
    	
	}
	
	public function app_version() {
		$data=array(
            'type' => 1101,
            'versionCode' => 107,
			'versionName' => '1.0.7',
			'forceUpdate' => false,
			'versionInfo' =>"版本更新记录 \n 1.界面优化 \n 2.功能完善 \n 3.BUG修复",
			'downloadUrl' =>"https://download.jappstore.com/apps/6046ed5b23389f26e8854e9d/install?download_token=de716fc371e0346439e4d2825cc73f31&source=update"
        );
    	$this->successJson("获取版本成功！",$data);
    }
	
	public function index_jpush() {
    	//	$this->display(":index");
		$jpush = new JPushClient(C('JPUSH.APP_KEY'), C('JPUSH.MASTER_SECRET'));
        $response = $jpush->push()
            ->setPlatform('all')
            ->addAllAudience()
            ->setNotificationAlert('http://thinkcmf.500-china.com/index.php?g=&m=article&a=index&id=73&cid=16')
            ->send();
        //print_r($response);
    	//$this->display(":index");
		$this->successJson("极光推送成功！",$response);
    }
	
	//商品信息保存
    public function get_QiniuAuthJSON(){
		$accessKey ="5w2sPc2GIDfgdxUo4KWa9G-yHQ4gGxND0VM7G-EM";
		$secretKey = "fy2rdLH42Na7mP_fWlO1FOJ6ye4bSf_-p7H7D98E";
		$bucket = "caesarxu";
        // 构建鉴权对象
		$auth = new Auth($accessKey, $secretKey);
		// 生成上传 Token
		$token = $auth->uploadToken($bucket);
		// 要上传文件的本地路径传。
		$this->successJson("Token获取成功！",$token);
    }

}


