<?php
return array(
    "NAME" => '标签名称',
    "POSTS_NUM" => '总数',
    "CATEGORY_DESCRIPTION" => '描述',    
    "SEO_TITLE" => 'SEO标题',
    "SEO_KEYWORDS" => 'SEO关键字',
    "SEO_DESCRIPTION" => 'SEO描述',
    "LIST_TEMPLATE" => '列表页模板',
    "ARTICLE_TEMPLATE" => '单文章模板',
    "GENERAL_SETTING" => '基本属性',
    "SEO_SETTING" => 'SEO设置',
    "TEMPLATE_SETTING" => '模板设置',
    "ALIAS" => '别名',
);