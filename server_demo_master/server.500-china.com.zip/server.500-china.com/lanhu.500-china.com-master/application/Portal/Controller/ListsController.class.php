<?php

namespace Portal\Controller;
use Common\Controller\HomebaseController;

class ListController extends HomebaseController {

	// 前台文章列表
	public function index() {
	    $term_id=I('get.id',0,'intval');
		$term=sp_get_term($term_id);
		
		if(empty($term)){
		    header('HTTP/1.1 404 Not Found');
		    header('Status:404 Not Found');
		    if(sp_template_file_exists(MODULE_NAME."/404")){
		        $this->display(":404");
		    }
		    return;
		}
		
		$tplname=$term["list_tpl"];
    	$tplname=sp_get_apphome_tpl($tplname, "list");
    	$this->assign($term);
    	$this->assign('cat_id', $term_id);
    	$this->display(":$tplname");
	}
	
	// 内容管理文章列表
	public function indexJson(){
		$term_id=I('get.cid',0,'intval');
		$lists = sp_sql_posts_paged("cid:$term_id;order:post_date DESC;",20);
		$this->successJson("获取信息列表成功!",$lists);
	}
  
 	// 内容管理文章列表
	public function indexJsonReport(){
		$term_id=I('get.cid',6,'intval');
		$lists = sp_sql_posts_paged("cid:$term_id;order:post_date DESC;",5);
		$this->successJson("获取信息列表成功!",$lists);
	}
  
  	// 内容管理文章列表
	public function indexJsonLists(){
		$lists = sp_sql_posts_paged("cid:3,4;order:post_date DESC;",20);
		$this->successJson("获取供求信息成功!",$lists);
	}
	
	// 内容管理文章列表
	public function indexJsonByQuery(){
		$term_id=I('post.cid');
		$query=I('post.query');
		$rule_id=I('post.rule',0,'intval');
		$cat_id=I('post.category',0,'intval');
		$region_id=I('post.region');
      	//$version=I('post.version');
        $page=I('post.page',0,'intval');
    	$field = '*';
    	$limit = ($page*20).','.(($page+1)*20);
    	$order = 'post_date DESC';
        if (isset($term_id)) {
    	    $term_id=explode(',', $term_id);
    	    $term_id=array_map('intval', $term_id);
    		$where['term_relationships.term_id'] = array('in',$term_id);
    	}
		if(!empty($query)){
		$where['posts.post_title'] = array('like',"%$query%");
		}
		if(!empty($rule_id)){
		$where['posts.rule_id'] = array('eq',$rule_id);
		}
		if(!empty($cat_id)){
        	$goods_category_model=M("GoodsCategory");
			$category_res=$goods_category_model->where('id='.$cat_id)->find();
			if($category_res['parent_id']==0){
				$where_category['parent_id_path']= array('like',"0-$cat_id-%");
        		$category_list=$goods_category_model->where($where_category)->select();
        		$category_array=array();
        		foreach ($category_list as $category_value) {
    			array_push($category_array,$category_value['id']);
				}
				//echo json_encode($category_array);exit;    
				$where['posts.cat_id'] = array('in',$category_array);
			}else{
				$where_category['parent_id_path']= array('like',$category_res['parent_id_path']."-%");
				//echo json_encode($where_category);exit;
        		$category_list=$goods_category_model->where($where_category)->select();
        		$category_array=array();
        		foreach ($category_list as $category_value) {
    			array_push($category_array,$category_value['id']);
				}
				//echo json_encode($category_array);exit;    
				$where['posts.cat_id'] = array('in',$category_array);
			}
        
		}
		
		if(!empty($region_id)){
			$area_model=M("Area");
			$region_end=substr($region_id,2);
			//echo $region_end;exit;
			if($region_end=='0000'){
				$where_area['area_parent_id']= array('eq',$region_id);
				$area_list=$area_model->where($where_area)->select();
				//echo json_encode($area_list);exit;
				$area_array=array();
        		foreach ($area_list as $area_value) {
    			array_push($area_array,$area_value['id']);
				}
				array_push($area_array,$region_id);
				$where['posts.post_region'] = array('in',$area_array);
			}else{
				$where_area['id']= array('eq',$region_id);
				$area_res=$area_model->where($where_area)->find();
				$area_array=array();
				array_push($area_array,$region_id);
				array_push($area_array,$area_res['area_parent_id']);
				$where['posts.post_region'] = array('in',$area_array);
			}
		}
		//echo json_encode($where);exit;
      	$where['term_relationships.status'] = array('eq',1);
		$where['posts.post_status'] = array('eq',1);
    	$join = '__POSTS__ as posts on term_relationships.object_id = posts.id';
    	$join2= '__USERS__ as users on posts.post_author = users.id';
    	$term_relationships_model= M("TermRelationships");
		$lists=$term_relationships_model
    	    ->alias("term_relationships")
    	    ->join($join)
    	    ->join($join2)
    	    ->field($field)
    	    ->where($where)
    	    ->order($order)
    	    ->limit($limit)
    	    ->select();
      //$res = M()->getLastSql();	echo $res;
      	if($lists){
          	foreach ($lists as $key => $value) {
	    		# code...
	    		$lists[$key]['post_date'] = $this->uc_time_ago($value['post_date']);
              	$lists[$key]['post_mobile'] = trim($lists[$key]['post_mobile']);
              	//if(empty($version)){
              		//$lists[$key]['post_mobile'] = '15033370607';
              		//$lists[$key]['mobile'] = '15033370607';
            	//}
      		}
          	
        	$this->successJson("获取信息列表成功!",$lists);
        }else{
        	$this->errorJson("获取信息列表失败!");
        }
	}
  
  	//时间格式化（时间戳）
function uc_time_ago($ptime) {
	date_default_timezone_set('PRC');
	$ptime = strtotime($ptime);
	$etime = time() - $ptime;
	switch ($etime){
		case $etime <= 60:
			$msg = '刚刚';
			break;
		case $etime > 60 && $etime <= 60 * 60:
			$msg = floor($etime / 60) . ' 分钟前';
			break;
		case $etime > 60 * 60 && $etime <= 24 * 60 * 60:
			$msg = date('Ymd',$ptime)==date('Ymd',time()) ? '今天 '.date('H:i',$ptime) : '昨天 '.date('H:i',$ptime);
			break;
		case $etime > 24 * 60 * 60 && $etime <= 2 * 24 * 60 * 60:
			$msg = date('Ymd',$ptime)+1==date('Ymd',time()) ? '昨天 '.date('H:i',$ptime) : '前天 '.date('H:i',$ptime);
			break;
		case $etime > 2 * 24 * 60 * 60 && $etime <= 12 * 30 * 24 * 60 * 60:
			$msg = date('Y',$ptime)==date('Y',time()) ? date('m月d日',$ptime) : date('Y-m-d',$ptime);
			break;
		default: $msg = date('Y-m-d',$ptime);
	}
	return $msg;
}

  
  // 内容管理文章列表
	public function indexJsonByQueryWithPage(){
		$term_id=I('post.cid');
		$query=I('post.query');
		$rule_id=I('post.rule',0,'intval');
		$cat_id=I('post.category',0,'intval');
		$region_id=I('post.region',0,'intval');
      	$page=I('post.page',0,'intval');
    	$field = '*';
    	$limit = ($page*20).','.(($page+1)*20);
    	$order = 'post_date DESC';
        if (isset($term_id)) {
    	    $term_id=explode(',', $term_id);
    	    $term_id=array_map('intval', $term_id);
    		$where['term_relationships.term_id'] = array('in',$term_id);
    	}
		if(!empty($query)){
		$where['posts.post_title'] = array('like',"%$query%");
		}
		if(!empty($rule_id)){
		$where['posts.rule_id'] = array('eq',$rule_id);
		}
		if(!empty($cat_id)){
        $goods_category_model=M("GoodsCategory");
        $where_category['parent_id_path']= array('like',"0-$cat_id-%");
        $category_list=$goods_category_model->where($where_category)->select();
        $category_array=array();
        foreach ($category_list as $category_value) {
    	array_push($category_array,$category_value['id']);
		}    
		$where['posts.cat_id'] = array('in',$category_array);
		}
		if(!empty($region_id)){
		$where['posts.post_region'] = array('eq',$region_id);
		}
     	 $where['posts.post_status'] = array('eq',1);
      	$where['term_relationships.status'] = array('eq',1);
    	$join = '__POSTS__ as posts on term_relationships.object_id = posts.id';
    	$join2= '__USERS__ as users on posts.post_author = users.id';
    	$term_relationships_model= M("TermRelationships");
		$lists=$term_relationships_model
    	    ->alias("term_relationships")
    	    ->join($join)
    	    ->join($join2)
    	    ->field($field)
    	    ->where($where)
    	    ->order($order)
    	    ->limit($limit)
    	    ->select();
      //$res = M()->getLastSql();	echo $res;
      	if($lists){
          	foreach ($lists as $key => $value) {
	    		# code...
	    		$lists[$key]['post_date'] = $this->uc_time_ago($value['post_date']);
      		}
        	$this->successJson("获取信息列表成功!",$lists);
        }else{
        	$this->errorJson("获取信息列表失败!");
        }
	}
	
	// 内容管理文章列表
	public function indexPersonalJson(){
		$userid=I('get.userid',0,'intval');
		$term_id=I('get.cid',0,'intval');
		$field = '*';
    	$limit = '0,10';
    	$order = 'post_date DESC';
    
    	//根据参数生成查询条件
    	$where['term_relationships.status'] = array('eq',1);
    	$where['posts.post_status'] = array('eq',1);
		$where['posts.post_author'] = $userid;
    	$where['term_relationships.term_id'] = $term_id;
    	
    	if (isset($tag['where'])) {
    		$where['_string'] = $tag['where'];
    	}
    
    	$join = '__POSTS__ as posts on term_relationships.object_id = posts.id';
    	$join2= '__USERS__ as users on posts.post_author = users.id';
    	
    	$term_relationships_model= M("TermRelationships");
    	$content=array();
    
    	$posts=$term_relationships_model
    	    ->alias("term_relationships")
    	    ->join($join)
    	    ->join($join2)
    	    ->field($field)
    	    ->where($where)
    	    ->order($order)
    	    ->limit($limit)
    	    ->select();
		$this->successJson("获取信息列表成功!",$posts);
		
	}
	
	// 个人内容管理文章列表
	public function indexPersonalHitsJson(){
		$userid=I('get.userid',0,'intval');
		$term_id=I('get.cid');
		$common_action_log_model=M("CommonActionLog");
		$action="Portal-Article-do_hits";
		$where=array("user"=>$userid,"action"=>$action);
		$find_log=$common_action_log_model->where($where)->find();
		$where['term_relationships.term_id']=$term_id;
		if (isset($term_id)) {
    	    $term_id=explode(',', $term_id);
    	    $term_id=array_map('intval', $term_id);
    		$where['term_relationships.term_id'] = array('in',$term_id);
    	}
		$field = '*';
    	$limit = '0,10';
    	$order = 'count DESC';
    
    	//根据参数生成查询条件
    	$where['posts.post_status'] = array('eq',1);
		$join = '__TERM_RELATIONSHIPS__ as term_relationships on common_action_log.postid = term_relationships.object_id';
		$join2 = '__POSTS__ as posts on common_action_log.postid = posts.id';
    	$posts=$common_action_log_model
    	    ->alias("common_action_log")
    	    ->join($join)
    	    ->join($join2)
			->field($field)
    	    ->where($where)
    	    ->order($order)
    	    ->limit($limit)
    	    ->select();
		
		$this->successJson("获取个人相关信息列表成功!",$posts);
	}
	
	// 个人内容管理文章列表
	public function indexPersonalLikeJson(){
		$userid=I('get.userid',0,'intval');
		$term_id=I('get.cid',0,'intval');
		$common_action_log_model=M("CommonActionLog");
		$action="Portal-Article-do_like";
		$where=array("user"=>$userid,"action"=>$action);
		$find_log=$common_action_log_model->where($where)->find();
		$where['term_relationships.term_id']=$term_id;
		$field = '*';
    	$limit = '0,10';
    	$order = 'post_date DESC';
    
    	//根据参数生成查询条件
    	$where['posts.post_status'] = array('eq',1);
		$join = '__TERM_RELATIONSHIPS__ as term_relationships on common_action_log.postid = term_relationships.object_id';
		$join2 = '__POSTS__ as posts on common_action_log.postid = posts.id';
    	$posts=$common_action_log_model
    	    ->alias("common_action_log")
    	    ->join($join)
    	    ->join($join2)
			->field($field)
    	    ->where($where)
    	    ->order($order)
    	    ->limit($limit)
    	    ->select();
		
		$this->successJson("获取个人相关信息列表成功!",$posts);
	}
	
	// 个人内容管理文章列表
	public function indexPersonalFavoriteJson(){
		$userid=I('get.userid',0,'intval');
		$term_id=I('get.cid',0,'intval');
		$user_favorites_model=M("UserFavorites");
		$where=array("table"=>'posts',"uid"=>$userid);
		$find_favorite=$user_favorites_model->where($where)->find();
		$where['term_relationships.term_id']=$term_id;
		$field = '*';
    	$limit = '0,10';
    	$order = 'post_date DESC';
    
    	//根据参数生成查询条件
    	$where['posts.post_status'] = array('eq',1);
		$join = '__TERM_RELATIONSHIPS__ as term_relationships on user_favorites.object_id = term_relationships.object_id';
		$join2 = '__POSTS__ as posts on user_favorites.object_id = posts.id';
    	$posts=$user_favorites_model
    	    ->alias("user_favorites")
    	    ->join($join)
    	    ->join($join2)
			->field($field)
    	    ->where($where)
    	    ->order($order)
    	    ->limit($limit)
    	    ->select();
		//echo $user_favorites_model->getLastSql();
		$this->successJson("获取个人相关信息列表成功!",$posts);
	}
  
  	// 个人内容管理文章列表
	public function indexPersonalMessageJson(){
		$userid=I('get.userid',0,'intval');
	}
	
	// 获取报价列表
	public function indexPersonalCommentJson(){
		$userid=I('get.userid',0,'intval');
		$user_comment_model=M("Comments");
		$where=array("uid"=>$userid);
		$lists=$user_comment_model->where($where)->find();
		
		$field = '*';
    	$limit = '0,10';
    	$order = 'post_date DESC';
		
		$join = '__POSTS__ as posts on user_comment.post_id = posts.id';
    	$join2= '__USERS__ as users on posts.post_author = users.id';
		$posts=$user_comment_model
    	    ->alias("user_comment")
    	    ->join($join)
    	    ->join($join2)
			->field($field)
    	    ->where($where)
    	    ->order($order)
    	    ->limit($limit)
    	    ->select();
		
		$this->successJson("获取报价列表成功!",$posts);
		}
	
	// 幻灯片列表
	public function indexReplayJson(){
		$where['parent'] = array('eq',6);
		$terms=M("Terms")->field('term_id,name,parent')->where($where)->order('term_id')->select();
		$replay_terms="";
		foreach ($terms as $r) {
			$replay_terms=$replay_terms.$r['term_id'].",";
		}
		$lists = sp_sql_posts_paged("cid:$replay_terms;order:post_date DESC;",10);
		$this->successJson("获取幻灯片列表成功!",$lists);
	}
	
	// 获取首页主页信息
	public function indexHomeJson(){
		$term_id=I('get.cid',0,'intval');
		$lists1 = sp_sql_posts_paged("cid:1;order:post_date DESC;",10);
		$lists2 = sp_sql_posts_paged("cid:2;order:post_date DESC;",10);
		$lists3 = sp_sql_posts_paged("cid:3;order:post_date DESC;",10);
		$lists5 = sp_sql_posts_paged("cid:5;order:post_date DESC;",10);
      	$lists6 = sp_sql_posts_paged("cid:6;order:post_date DESC;",5);
		$data=array("lists1"=>$lists1,"lists2"=>$lists2,"lists3"=>$lists3,"lists5"=>$lists5,"lists6"=>$lists6);
		$this->successJson("获取首页主信息成功!",$data);
	}
  
  	// 获取首页主页信息
	public function indexHomeAddJson(){
		$term_id=I('get.cid',0,'intval');
		$lists1 = sp_sql_posts_paged("cid:1;order:post_date DESC;",10);
		$lists2 = sp_sql_posts_paged("cid:2;order:post_date DESC;",10);
		$lists3 = sp_sql_posts_paged("cid:3;order:post_date DESC;",10);
		$lists5 = sp_sql_posts_paged("cid:5;order:post_date DESC;",10);
      	$lists6 = sp_sql_posts_paged("cid:6;order:post_date DESC;",5);
		$lists16 = sp_sql_posts_paged("cid:16;order:post_date DESC;",6);
      	$lists17 = sp_sql_posts_paged("cid:17;order:post_date DESC;",5);
		$data=array("lists1"=>$lists1,"lists2"=>$lists2,"lists3"=>$lists3,"lists5"=>$lists5,"lists6"=>$lists6,"lists16"=>$lists16,"lists17"=>$lists17);
		$this->successJson("获取首页主信息成功!",$data);
	}
  
  // 获取首页主页信息
	public function indexHomeNewJson(){
		$term_id=I('get.cid',0,'intval');
		$lists1 = sp_sql_posts_paged("cid:1;order:post_date DESC;",10);
		$lists2 = sp_sql_posts_paged("cid:2;order:post_date DESC;",10);
		$lists3 = sp_sql_posts_paged("cid:3;order:post_date DESC;",10);
		$lists5 = sp_sql_posts_paged("cid:5;order:post_date DESC;",10);
      	$lists6 = sp_sql_posts_paged("cid:6;order:post_date DESC;",5);
		$lists16 = sp_sql_posts_paged("cid:16;order:post_date DESC;",10);
		
		$where['term_relationships.status'] = array('eq',1);
		$where['posts.post_status'] = array('eq',1);
		$where['term_relationships.term_id'] = array('eq',17);
    	$join = '__POSTS__ as posts on term_relationships.object_id = posts.id';
    	$join2= '__USERS__ as users on posts.post_author = users.id';
		$field = '*';
    	$limit = '0,5';
		$group = 'convert(post_date,DATE)';
    	$order = "post_date DESC";
    	$term_relationships_model= M("TermRelationships");
		$posts=$term_relationships_model
    	    ->alias("term_relationships")
    	    ->join($join)
    	    ->join($join2)
    	    ->field($field)
    	    ->where($where)
			->group($group)
    	    ->order($order)
    	    ->limit($limit)
    	    ->select();
      	if($posts){
        	foreach ($posts as $key => $value) {
              	$posts[$key]['query_date'] = date('Y-m-d',strtotime($value['post_date']));
	    		$posts[$key]['post_title'] = date('m月d日',strtotime($value['post_date']))."：".$value['post_title'];
             }
		}
      	$lists17['posts']=$posts;
		$data=array("lists1"=>$lists1,"lists2"=>$lists2,"lists3"=>$lists3,"lists5"=>$lists5,"lists6"=>$lists6,"lists16"=>$lists16,"lists17"=>$lists17);
		$this->successJson("获取首页主信息成功!",$data);
	}
  
  // 获取首页主页信息
	public function indexJsonSectionMessage(){
		$where['term_relationships.status'] = array('eq',1);
		$where['posts.post_status'] = array('eq',1);
		$where['term_relationships.term_id'] = array('eq',17);
    	$join = '__POSTS__ as posts on term_relationships.object_id = posts.id';
    	$join2= '__USERS__ as users on posts.post_author = users.id';
		$field = '*';
    	$limit = '0,10';
		$group = 'convert(post_date,DATE)';
    	$order = "post_date DESC";
    	$term_relationships_model= M("TermRelationships");
		$posts=$term_relationships_model
    	    ->alias("term_relationships")
    	    ->join($join)
    	    ->join($join2)
    	    ->field('convert(post_date,DATE) as query_date')
    	    ->where($where)
			->group($group)
    	    ->order($order)
    	    ->limit($limit)
    	    ->select();	
		//$this->successJson("获取首页主信息成功!",$posts);
		if($posts){
        	foreach ($posts as $key => $value) {
				$where['posts.post_date'] = array('like',$value['query_date']."%");
				$list=$term_relationships_model
    	    	->alias("term_relationships")
    	    	->join($join)
    	    	->join($join2)
    	    	->field($field)
    	    	->where($where)
    	    	->order($order)
    	    	->limit($limit)
    	    	->select();
				$posts[$key]['post_array'] =$list;
             }
			}
			$this->successJson("获取首页主信息成功!",$posts);	
	}
	
	// 获取首页主页信息
	public function indexHomeJsonData(){
		$term_id=I('cid',2,'intval');
      	$query_date=I('post.query_date');
      	$field = '*';
    	$limit = '0,20';
		$where['term_relationships.status'] = array('eq',1);
		$where['posts.post_status'] = array('eq',1);
		$where['term_relationships.term_id'] = array('eq',$term_id);
    	$join = '__POSTS__ as posts on term_relationships.object_id = posts.id';
    	$join2= '__USERS__ as users on posts.post_author = users.id';
		$join3= 'left join __GOODS__ as goods on posts.goods_id = goods.goods_id';
		$group = 'convert(post_date,DATE)';
    	$order = "post_date DESC";
    	$term_relationships_model= M("TermRelationships");
		$posts=$term_relationships_model
    	    ->alias("term_relationships")
    	    ->join($join)
    	    ->join($join2)
			->join($join3)
    	    ->field($field)
    	    ->where($where)
    	    ->order($order)
    	    ->limit($limit)
    	    ->select();
		$this->successJson("获取首页主信息成功!",$posts);
	}
  
  	// 获取首页主页信息
	public function indexJsonNewHome(){
		$term_id=I('cid',2,'intval');
      	$query_date=I('post.query_date');
      	$field = '*';
    	$limit = '0,5';
		$where['term_relationships.status'] = array('eq',1);
		$where['posts.post_status'] = array('eq',1);
		$where['term_relationships.term_id'] = array('eq',$term_id);
    	$join = '__POSTS__ as posts on term_relationships.object_id = posts.id';
    	$join2= '__USERS__ as users on posts.post_author = users.id';
		$group = 'convert(post_date,DATE)';
    	$order = "post_date DESC";
    	$term_relationships_model= M("TermRelationships");
		$posts=array();
		if(empty($query_date)){
          $array=$term_relationships_model
    	    		->alias("term_relationships")
    	    		->join($join)->where($where)->group($group)
    	    ->order($order)
    	    ->limit($limit)
    	    ->select();
			if($array){
        	foreach ($array as $key => $value) {
				$query_date = date('Y-m-d',strtotime($value['post_date']));
				$where['posts.post_date'] = array('like',$query_date."%");
				$post=$term_relationships_model
    	    ->alias("term_relationships")
    	    ->join($join)
    	    ->join($join2)
    	    ->field($field)
    	    ->where($where)
    	    ->order($order)
    	    ->find();
			array_push($posts,$post);
             }
			}
			if($posts){
        	foreach ($posts as $key => $value) {
				$posts[$key]['query_date'] = date('Y-m-d',strtotime($value['post_date']));
	    		$posts[$key]['post_title'] = date('m月d日',strtotime($value['post_date']))."：".$value['post_title'];
             }
			}
		}else{
		$where['posts.post_date'] = array('like',$query_date."%");
		$limit = '0,50';
		$posts=$term_relationships_model
    	    ->alias("term_relationships")
    	    ->join($join)
    	    ->join($join2)
    	    ->field($field)
    	    ->where($where)
    	    ->order($order)
    	    ->limit($limit)
    	    ->select();
		}
      	//echo M()->getLastSql();
		$lists['posts']=$posts;
		$this->successJson("获取首页主信息成功!",$lists);
	}
	
	// 获取首页主页信息
	public function indexHotJson(){
		$term_id=I('get.cid',0,'intval');
		$lists = sp_sql_posts_paged("cid:3;order:post_date DESC;",10);
		$lists1 = sp_sql_posts_paged("cid:2;order:post_date DESC;",10);
		$lists2 = sp_sql_posts_paged("cid:5;order:post_date DESC;",10);
		$data=array("lists"=>$lists,"lists1"=>$lists1,"lists2"=>$lists2);
		$this->successJson("获取首页主信息成功!",$data);
	}
	
	// 文章分类列表接口,返回文章分类列表,用于后台导航编辑添加
	public function nav_index(){
		$navcatname="文章分类";
        $term_obj= M("Terms");

        $where=array();
        $where['status'] = array('eq',1);
        $terms=$term_obj->field('term_id,name,parent')->where($where)->order('term_id')->select();
		$datas=$terms;
		$navrule = array(
		    "id"=>'term_id',
            "action" => "Portal/List/index",
            "param" => array(
                "id" => "term_id"
            ),
            "label" => "name",
		    "parentid"=>'parent'
        );
		return sp_get_nav4admin($navcatname,$datas,$navrule) ;
	}
}
