<?php

namespace Portal\Controller;

Vendor('JPush.autoload');
Vendor('RongCloud.autoload');
use JPush\Client as JPushClient;
use RongCloud\RongCloud as RongCloudCC;

use Common\Controller\HomebaseController;

class ArticleController extends HomebaseController {
	
	function _initialize() {
		parent::_initialize();
		$this->posts_model = D("Portal/Posts");
		$this->terms_model = D("Portal/Terms");
		$this->comments_model=D("Common/Comments");
		$this->term_relationships_model = D("Portal/TermRelationships");
	}
	
	// 获取文章内容详情
	public function indexArticleDataJson(){
		$tid=I('tid',1,'intval');
      	$field = 'tid,object_id,term_id,post_title,post_author,post_date,post_type,post_excerpt,smeta,post_status,
		post_authorname,post_avatar,photos_urls,post_goods,comment_count,post_hits,post_like,thumb_video';
		$where['posts.post_status'] = array('eq',1);
		$where['term_relationships.tid'] = array('eq',$tid);
    	$join = '__POSTS__ as posts on term_relationships.object_id = posts.id';
    	$term_relationships_model= M("TermRelationships");
		$postData=$term_relationships_model
    	    ->alias("term_relationships")
    	    ->join($join)
    	    ->field($field)
    	    ->where($where)
    	    ->find();
		$goods_model= M("Goods");
		$comments_model= M("Comments");
		$follow_model = M("PostsFollow");
		$goods_field = 'goods_id,goods_name,goods_remark,goods_img,shop_price,good_desc,store_count';
		$comments_field ='id,post_id,uid,full_name,url,content,createtime';
		$likes_field ='user,user_login,user_nicename,avatar';
		$like_join = '__USERS__ as users on users.id = posts_follow.id';
		if($postData){
        	if(!empty($postData['smeta'])){
					if(empty($postData['photos_urls'])){
					$postData['photos_urls']=array();
					}else{
					$postData['photos_urls']=json_decode($postData['photos_urls'], true);
					}
					$postData['smeta']=json_decode($postData['smeta'], true);
					$postData['thumb'] = $postData['smeta']['thumb'];
				}
				if(!empty($postData['post_goods'])){
					$goods_where['goods_id'] = array('in',$postData['post_goods']);
					$goods_array=$goods_model->field($goods_field)->where($goods_where)->select();
					$postData['goods_array']=$goods_array;
				}
				if(!empty($postData['comment_count'])){
					$comments_where['post_id'] = array('eq',$postData['object_id']);
					$comment_array=$comments_model->field($comments_field)->where($comments_where)->select();
					$postData['comment_array']=$comment_array;
				}
				if(!empty($postData['post_like'])){
					$like_where['postid'] = array('eq',$postData['object_id']);
					$like_where['is_care'] = array('eq',1);
					$like_array=$follow_model->alias("posts_follow")->join($like_join)
					->field($likes_field)->where($like_where)->limit('0,6')->select();
					$postData['like_array']=$like_array;
				}
				$this->successJson("获取文章内容详情成功!",$postData);
		}else{
			$this->errorJson("获取文章内容详情失败!");
		}	
			
		
	}
	
	//文章内页
    public function jpush_test_json() {
		$jpush = new JPushClient(C('JPUSH.APP_KEY'), C('JPUSH.MASTER_SECRET'));
        $response = $jpush->push()
            ->setPlatform('all')
            ->addAllAudience()
            ->setNotificationAlert('http://thinkcmf.500-china.com/index.php?g=&m=article&a=index&id=73&cid=16')
            ->send();
        //print_r($response);
    	//$this->display(":index");
$this->successJson("极光推送成功！",$response);
		}
	
	//文章内页
    public function index_json() {
    	$article_id=I('get.id',0,'intval');
    	$term_id=I('get.cid',0,'intval');
    	
    	$posts_model=M("Posts");
    	
    	$article=$posts_model
    	->alias("a")
    	->field('a.*,c.user_login,c.user_nicename,b.term_id')
    	->join("__TERM_RELATIONSHIPS__ b ON a.id = b.object_id")
		->join("__USERS__ c ON a.post_author = c.id")
		->where(array('a.id'=>$article_id,'b.term_id'=>$term_id))
		->find();
		
		if($article){
    		$this->successJson("获取文章详情成功！",$article);
    	}else{
    		$this->errorJson("获取文章详情失败！");
    	}
		
	}
	
	// 文章的评论列表
	public function indexCommentJson(){
		$post_id=I('post.post_id',0,'intval');
		$comments_model=M("Comments");
		$where['post_id'] = array('eq',$post_id);
		$comments=$comments_model
		->where($where)
		->field("id,post_id,uid,full_name,url,content,createtime")
		->order("createtime desc")
		->select();
		$this->successJson("获取文章评论成功！",$comments);
		}
    
    //文章内页
    public function index() {
    	$article_id=I('get.id',0,'intval');
    	$term_id=I('get.cid',0,'intval');
    	
    	$posts_model=M("Posts");
    	
    	$article=$posts_model
    	->alias("a")
    	->field('a.*,c.user_login,c.user_nicename,b.term_id')
    	->join("__TERM_RELATIONSHIPS__ b ON a.id = b.object_id")
		->join("__USERS__ c ON a.post_author = c.id")
		->where(array('a.id'=>$article_id,'b.term_id'=>$term_id))
		->find();
    	
    	if(empty($article)){
    	    header('HTTP/1.1 404 Not Found');
    	    header('Status:404 Not Found');
    	    if(sp_template_file_exists(MODULE_NAME."/404")){
    	        $this->display(":404");
    	    }
    	    
    	    return;
    	}
    	
    	$terms_model= M("Terms");
    	$term=$terms_model->where(array('term_id'=>$term_id))->find();
    	
    	$posts_model->where(array('id'=>$article_id))->setInc('post_hits');
    	
    	$article_date=$article['post_date'];
    	
    	$join = '__POSTS__ as b on a.object_id =b.id';
    	$join2= '__USERS__ as c on b.post_author = c.id';
    	
    	$term_relationships_model= M("TermRelationships");
    	
    	$next=$term_relationships_model
    	->alias("a")
    	->join($join)->join($join2)
    	->where(array('b.id'=>array('gt',$article_id),"post_date"=>array("egt",$article_date),"a.status"=>1,'a.term_id'=>$term_id,'post_status'=>1))
    	->order("post_date asc,b.id asc")
    	->find();
    	
    	$prev=$term_relationships_model
    	->alias("a")
    	->join($join)->join($join2)
    	->where(array('b.id'=>array('lt',$article_id),"post_date"=>array("elt",$article_date),"a.status"=>1,'a.term_id'=>$term_id,'post_status'=>1))
    	->order("post_date desc,b.id desc")
    	->find();
		
		//显示标签
		$tag_model = M('tag_posts');
		$tags = $tag_model->alias("a")->join("__TAG__ as b on a.tag_id = b.tag_id")->where("object_id=$article_id")->select();
		
		//
    	
    	$this->assign("next",$next);
    	$this->assign("prev",$prev);
    	
    	$smeta=json_decode($article['smeta'],true);
    	$content_data=sp_content_page($article['post_content']);
    	$article['post_content']=$content_data['content'];
    	
    	$this->assign("page",$content_data['page']);
    	$this->assign($article);
    	$this->assign("smeta",$smeta);
    	$this->assign("term",$term);
    	$this->assign("article_id",$article_id);
    	$this->assign("tags",$tags);
    	
    	$tplname=$term["one_tpl"];
    	$tplname=empty($smeta['template'])?$tplname:$smeta['template'];
    	$tplname=sp_get_apphome_tpl($tplname, "article");
    	//echo $tplname;exit;
    	$this->display(":$tplname");
    }
	
	//文章内页
    public function index_masonry() {
    	$article_id=I('get.id',0,'intval');
    	$term_id=I('get.cid',0,'intval');
    	
    	$posts_model=M("Posts");
    	
    	$article=$posts_model
    	->alias("a")
    	->field('a.*,c.user_login,c.user_nicename,b.term_id')
    	->join("__TERM_RELATIONSHIPS__ b ON a.id = b.object_id")
		->join("__USERS__ c ON a.post_author = c.id")
		->where(array('a.id'=>$article_id,'b.term_id'=>$term_id))
		->find();
    	
    	if(empty($article)){
    	    header('HTTP/1.1 404 Not Found');
    	    header('Status:404 Not Found');
    	    if(sp_template_file_exists(MODULE_NAME."/404")){
    	        $this->display(":404");
    	    }
    	    
    	    return;
    	}
    	
    	$terms_model= M("Terms");
    	$term=$terms_model->where(array('term_id'=>$term_id))->find();
    	
    	$posts_model->where(array('id'=>$article_id))->setInc('post_hits');
    	
    	$article_date=$article['post_date'];
    	
    	$join = '__POSTS__ as b on a.object_id =b.id';
    	$join2= '__USERS__ as c on b.post_author = c.id';
    	
    	$term_relationships_model= M("TermRelationships");
    	
    	$next=$term_relationships_model
    	->alias("a")
    	->join($join)->join($join2)
    	->where(array('b.id'=>array('gt',$article_id),"post_date"=>array("egt",$article_date),"a.status"=>1,'a.term_id'=>$term_id,'post_status'=>1))
    	->order("post_date asc,b.id asc")
    	->find();
    	
    	$prev=$term_relationships_model
    	->alias("a")
    	->join($join)->join($join2)
    	->where(array('b.id'=>array('lt',$article_id),"post_date"=>array("elt",$article_date),"a.status"=>1,'a.term_id'=>$term_id,'post_status'=>1))
    	->order("post_date desc,b.id desc")
    	->find();
		
		//显示标签
		$tag_model = M('tag_posts');
		$tags = $tag_model->alias("a")->join("__TAG__ as b on a.tag_id = b.tag_id")->where("object_id=$article_id")->select();
		
		//
    	
    	$this->assign("next",$next);
    	$this->assign("prev",$prev);
    	
    	$smeta=json_decode($article['smeta'],true);
    	$content_data=sp_content_page($article['post_content']);
    	$article['post_content']=$content_data['content'];
    	
    	$this->assign("page",$content_data['page']);
    	$this->assign($article);
    	$this->assign("smeta",$smeta);
    	$this->assign("term",$term);
    	$this->assign("article_id",$article_id);
    	$this->assign("tags",$tags);
    	
    	$tplname=$term["one_tpl"];
    	$tplname=empty($smeta['template'])?$tplname:$smeta['template'];
    	$tplname=sp_get_apphome_tpl($tplname, "article_masonry");
    	
    	$this->display(":$tplname");
    }
    
    // 文章浏览
    public function do_hits(){
    	$this->check_login();
    	
    	$id = I('get.id',0,'intval');//posts表中id
    	
    	$posts_model=M("Posts");
    	$common_action_log_model=M("CommonActionLog");
		$action=MODULE_NAME."-".CONTROLLER_NAME."-".ACTION_NAME;
		$object="posts$id";
    	$userid=get_current_userid();
		$ip=get_client_ip(0,true);//修复ip获取
		$where=array("user"=>$userid,"action"=>$action,"object"=>$object);
		$find_log=$common_action_log_model->where($where)->find();
		$time=time();
		if($find_log){
			$common_action_log_model->where($where)->save(array("count"=>array("exp","count+1"),"last_time"=>$time,"ip"=>$ip));
		}else{
		$common_action_log_model->add(array("user"=>$userid,"action"=>$action,"object"=>$object,"count"=>array("exp","count+1"),"last_time"=>$time,"ip"=>$ip));
		}
		$posts_model->save(array("id"=>$id,"post_hits"=>array("exp","post_hits+1")));
    		$this->success("浏览好啦！");
	
    }
	
	// 文章点赞
    public function do_like(){
    	$this->check_login();
    	
    	$id = I('get.id',0,'intval');//posts表中id
    	
    	$posts_model=M("Posts");
    	
    	$can_like=sp_check_user_action("posts$id",1);
    	
    	if($can_like){
    		$posts_model->save(array("id"=>$id,"post_like"=>array("exp","post_like+1")));
    		$this->success("赞好啦！");
    	}else{
    		$this->error("您已赞过啦！");
    	}
    }
	
	/**
	 * 获取地区列表的函数。
	 *
	 * @access  public
	 * @param   int     $region_id  上级地区id
	 * @return  void
	 */
	function area_list($region_id=0)
	{
		$area_model = M("Area");
		$row = $area_model->where(" area_parent_id = ".$region_id)->order('id')->select();	
		return $row;
	}
	
	//获取地区地址
	public function getArea(){
        $parent_id = I('get.parent_id'); 
		$area_model = M("Area");
        $data = $area_model->where("area_parent_id=$parent_id")->order('id')->select();
        //$this->successJson($data);
		$html = '<option style="displty:none" selected>请选择</option>';
        if($data){
            foreach($data as $h){
            	$html .= "<option value='{$h['id']}'>{$h['area_name']}</option>";
            }
        }
        echo $html;
    }
	
	//获取关联商品的分类
	public function getCateGoods(){
        $cat_id = I('get.cat_id'); 
		$good_model = M("Goods");
        $data = $good_model->where("cat_id=$cat_id")->order('sort')->select();
        //$this->successJson($data);
		$html = '<option style="display:none" selected>请选择</option>';
        if($data){
            foreach($data as $cate){
            	$html .= "<option value='{$cate['goods_id']}' data='{$cate['shop_price']}'>{$cate['goods_name']}</option>";
            }
        }
        echo $html;
    }
    
    // 前台用户添加文章
    public function add(){
        $this->check_login();
        $this->_getTermTree();
		$area_list = $this->area_list(0);
		$area_list1 = $this->area_list(110000);
		$this->assign("area_list",$area_list);
		$this->assign("area_list1",$area_list1);
        $this->display();
    }
    
    // 前台用户添加文章提交
    public function add_post(){
        if(IS_POST){
            $this->check_login();

            if(empty($_POST['term'])){
                $this->error("请至少选择一个分类！");
            }
			if(!empty($_POST['photos_alt']) && !empty($_POST['photos_url'])){
				foreach ($_POST['photos_url'] as $key=>$url){
					$photourl=sp_asset_relative_url($url);
					$_POST['smeta']['photo'][]=array("url"=>$photourl,"alt"=>$_POST['photos_alt'][$key]);
				}
			}
            $posts_model=M('Posts');
			$users_model=M('Users');
            $term_relationships_model=M('TermRelationships');
            
            $_POST['smeta']['thumb'] = sp_asset_relative_url($_POST['smeta']['thumb']);
            
            $_POST['post']['post_date']=date("Y-m-d H:i:s",time());
            $_POST['post']['post_modified']=date("Y-m-d H:i:s",time());
            $_POST['post']['post_author']=sp_get_current_userid();
			$users=$users_model->where(array("id"=>sp_get_current_userid()))->find();
			
			$_POST['post']['post_authorname']=$users['user_nicename'];
			$_POST['post']['post_source']=$users['user_nicename'];
			$_POST['post']['post_avatar']=$users['avatar'];
			
			//echo json_encode($users);exit;
			//$_POST['post']['post_author']=sp_get_current_userid();
            $article=I("post.post");
			$post_region=$article['post_region'];
			$province_name=$article['province_name'];
			$city_name=$article['city_name'];
			$area_name=$article['area_name'];
			$article['post_area']=$province_name.'-'.$city_name;
            $article['smeta']=json_encode($_POST['smeta']);
            $article['post_content']=safe_html(htmlspecialchars_decode($article['post_content']));
            if ($posts_model->create($article)!==false) {
                $result=$posts_model->add();
                if ($result) {
                    $result=$term_relationships_model->add(array("term_id"=>intval($_POST['term']),"object_id"=>$result));
                    if($result){
                        $this->success("文章添加成功！");
						
                    }else{
                        $posts_model->delete($result);
                        $this->error("文章添加失败！");
                    }
                
                } else {
                    $this->error("文章添加失败！");
                }
            }else{
                $this->error($posts_model->getError());
            }
            
            
        }
    
    }
	
	// 前台用户删除文章提交
    public function remove_post_json(){
		$tid=I("post.tid",0,'intval');
		$term_relationships_model=M('TermRelationships');
      	if(empty($tid)){
        $this->errorJson("缺少文章删除ID！");
        }else{
        $result=$term_relationships_model->where(array('tid'=>$tid))->save(array('status'=>0));
        $this->successJson("文章删除成功！",$result);
        }
		
	}
	
	// 前台用户添加文章提交
    public function add_post_json(){
		//echo 123;exit;
        if(IS_POST){
            //$this->check_login();
            if(empty($_POST['term'])){
                $this->errorJson("请至少选择一个分类！");
            }
          	if(!empty($_POST['photos_url'])){
				foreach ($_POST['photos_url'] as $key=>$url){
					$photourl=sp_asset_relative_url($url);
					$_POST['smeta']['photo'][]=array("url"=>$photourl,"alt"=>"");
				}
			}
            $posts_model=M('Posts');
			$users_model=M('Users');
            $term_relationships_model=M('TermRelationships');
            if($_POST['post']['post_type']==4){
			$_POST['smeta']['thumb'] = $_POST['thumb_video'];
			}else{
			$_POST['smeta']['thumb'] = $_POST['photos_url'][0];
			}
  
            $_POST['post']['post_date']=date("Y-m-d H:i:s",time());
            $_POST['post']['post_modified']=date("Y-m-d H:i:s",time());
            $_POST['post']['post_author']=$_POST['userID'];
			$users=$users_model->where(array("id"=>$_POST['userID']))->find();
			if(empty($_POST['post']['post_authorname'])){
            	$_POST['post']['post_authorname']=$users['user_nicename'];
            }
			$_POST['post']['post_source']=$users['user_nicename'];
			$_POST['post']['post_avatar']=$users['avatar'];
			//$_POST['post']['post_mobile']=$users['mobile'];
			
			if($users['user_type']==2){
				$_POST['post']['post_status']=1;
			}else{
				$_POST['post']['post_status']=1;
			}
			
            $article=I("post.post");
            $article['smeta']=json_encode($_POST['smeta']);
			if($_POST['post']['post_type']==4){
			$article['thumb_video']=$_POST['thumb_video'];
			}else{
			$article['photos_urls']=json_encode($_POST['photos_url']);
			}
            $article['post_content']=safe_html(htmlspecialchars_decode($article['post_content']));
			//echo 123;exit;
            if ($posts_model->create($article)!==false) {
                $result=$posts_model->add();
				//echo 121;exit;
                if ($result) {
                  $status=0;
                    $result=$term_relationships_model->add(array("term_id"=>intval($_POST['term']),"object_id"=>$result,"status"=>$status));
                    if($result){
                        //$this->successJson("文章添加成功！",$article);
				$term_id=$_POST['term'];
				//$this->success("添加成功！");
				$jpush = new JPushClient(C('JPUSH.APP_KEY'), C('JPUSH.MASTER_SECRET'));
                /*      
        		$response = $jpush->push()
            	->setPlatform('all')
            	->addAllAudience()
            	->setNotificationAlert('http://thinkcmf.500-china.com/index.php?g=&m=article&a=index&id=$result&cid=$term_id')
            	->send();
                */      
			$this->successJson("文章添加成功,极光推送已发送！",$article);
                    }else{
                        $posts_model->delete($result);
                        $this->errorJson("文章添加失败！");
                    }
                
                } else {
                    $this->errorJson("文章添加失败！");
                }
            }else{
                $this->error($posts_model->getError());
            }
            
            
        }
    
    }
	
	
    
    // 前台用户文章编辑
    public function edit(){
        $this->check_login();
        $id=I("get.id",0,'intval');
        $terms_model=M('Terms');
        $posts_model=M('Posts');
        
        $term_relationship = M('TermRelationships')->where(array("object_id"=>$id,"status"=>1))->getField("term_id",true);
        $this->_getTermTree();
        $post=$posts_model->where(array('id'=>$id,'post_author'=>sp_get_current_userid()))->find();
        if(!empty($post)){
            $this->assign("post",$post);
            $this->assign("smeta",json_decode($post['smeta'],true));
            $this->display();
        }else{
            $this->error('您编辑的文章不存在！');
        }
        
    }
    
    // 前台用户文章编辑提交
    public function edit_post(){
        if(IS_POST){
            $this->check_login();

            $posts_model=M('Posts');
            $term_relationships_model=M('TermRelationships');
            
            $_POST['smeta']['thumb'] = sp_asset_relative_url($_POST['smeta']['thumb']);
            $_POST['post']['post_modified']=date("Y-m-d H:i:s",time());
            $article=I("post.post");
            $article['smeta']=json_encode($_POST['smeta']);
            $article['post_content']=safe_html(htmlspecialchars_decode($article['post_content']));
            if ($posts_model->field('id,post_author,post_content,post_title,post_modified,smeta')->create($article)!==false) {
                $result=$posts_model->where(array('id'=>$article['id'],'post_author'=>sp_get_current_userid()))->save($article);
                if ($result!==false) {
                    $this->success("文章编辑成功！");
                } else {
                    $this->error("文章编辑失败！");
                }
            }else{
                $this->error($posts_model->getError());
            }
            
        }
    }
    
    // 获取文章分类树结构
    private function _getTermTree($term=array()){
        $result =M('Terms')->order(array("listorder"=>"asc"))->select();
    
        $tree = new \Tree();
        $tree->icon = array('&nbsp;&nbsp;&nbsp;│ ', '&nbsp;&nbsp;&nbsp;├─ ', '&nbsp;&nbsp;&nbsp;└─ ');
        $tree->nbsp = '&nbsp;&nbsp;&nbsp;';
        foreach ($result as $r) {
            $r['str_manage'] = '<a href="' . U("AdminTerm/add", array("parent" => $r['term_id'])) . '">添加子类</a> | <a href="' . U("AdminTerm/edit", array("id" => $r['term_id'])) . '">修改</a> | <a class="js-ajax-delete" href="' . U("AdminTerm/delete", array("id" => $r['term_id'])) . '">删除</a> ';
            $r['visit'] = "<a href='#'>访问</a>";
            $r['taxonomys'] = $this->taxonomys[$r['taxonomy']];
            $r['id']=$r['term_id'];
            $r['parentid']=$r['parent'];
            $r['selected']=in_array($r['term_id'], $term)?"selected":"";
            $r['checked'] =in_array($r['term_id'], $term)?"checked":"";
            $array[] = $r;
        }
    
        $tree->init($array);
        $str="<option value='\$id' \$selected>\$spacer\$name</option>";
        $terms = $tree->get_tree(0, $str);
        $this->assign('terms', $terms);
    }
	
	// 获取首页主页信息
	public function articleDetailJson(){
		$pid=I('pid',2,'intval');
      	$field = 'post_title,post_author,post_date,post_type,post_excerpt,smeta,post_status,post_authorname,post_avatar,photos_urls,post_goods,comment_count';
		$where['post_status'] = array('eq',1);
		$where['id'] = array('eq',$pid);
		$postData=M('Posts')->field($field)->where($where)->find();
		$goods_model= M("Goods");
		$comments_model= M("Comments");
		$goods_field = 'goods_id,goods_name,goods_remark,goods_img,shop_price,good_desc,store_count';
		$comments_field ='id,post_id,uid,full_name,url,content,createtime';
		if($postData){
				if(!empty($postData['smeta'])){
					$postData['photos_urls']=json_decode($postData['photos_urls'], true);
					$postData['smeta']=json_decode($postData['smeta'], true);
					$postData['thumb'] = $postData['smeta']['thumb'];
				}
				if(!empty($postData['post_goods'])){
					$goods_where['goods_id'] = array('in',$postData['post_goods']);
					$goods_array=$goods_model->field($goods_field)->where($goods_where)->select();
					$postData['goods_array']=$goods_array;
				}
				if(!empty($postData['comment_count'])){
					$comments_where['post_id'] = array('eq',$postData['object_id']);
					$comment_array=$comments_model->field($comments_field)->where($comments_where)->select();
					$postData['comment_array']=$comment_array;
				}
		}	
			
		$this->successJson("获取首页主信息成功!",$postData);
	}
	
	// 前台用户提交评论
	public function post_comment_json(){
		if (IS_POST){
			//$post_table=I('post.post_table');
			
			$_POST['post_table']="posts";
			
			$users_data=M("Users")->where(array("id"=>$_POST['uid']))->find();

			$_POST['url']=$users_data['avatar'];
			
			if(C("COMMENT_NEED_CHECK")){
				$_POST['status']=0;//评论审核功能开启
			}else{
				$_POST['status']=1;
			}
			$data=$this->comments_model->create();
			
			if ($data!==false){
				$this->check_last_action_json(intval(C("COMMENT_TIME_INTERVAL")));
				$result=$this->comments_model->add();
				if ($result!==false){
					//评论计数
					$post_table_model=M("Posts");
					$pk=$post_table_model->getPk();
					
					$post_table_model->create(array("comment_count"=>array("exp","comment_count+1")));
					$post_table_model->where(array($pk=>intval($_POST['post_id'])))->save();
					
					$post_table_model->create(array("last_comment"=>time()));
					$post_table_model->where(array($pk=>intval($_POST['post_id'])))->save();
					
					$this->successJson("评论成功！",$result);
				} else {
					$this->errorJson("评论失败！");
				}
			} else {
				$this->errorJson($this->comments_model->getError());
			}
		}
		
	}
}
