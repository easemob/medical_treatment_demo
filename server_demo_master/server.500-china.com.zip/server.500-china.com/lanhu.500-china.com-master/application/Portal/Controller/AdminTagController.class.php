<?php

namespace Portal\Controller;

use Common\Controller\AdminbaseController;

class AdminTagController extends AdminbaseController {
	
	protected $tags_model;
	//protected $taxonomys=array("article"=>"文章","picture"=>"图片");
	
	function _initialize() {
		parent::_initialize();
		$this->tags_model = D("Portal/Tag");
		$this->tags_posts = D("Portal/Tag_posts");
		//$this->assign("taxonomys",$this->taxonomys);
	}
	
	// 后台文章分类列表
    public function index(){
		//$result = $this->tags_model->order(array("listorder"=>"asc"))->select();
		$tag = $this->tags_model->select();
		//$tag_posts = $this->tags_posts->alias('a')->join("__TAG__ as b ON a.tag_id=b.tag_id")->count();
		foreach($tag as $key=>$v){
			$tag_id=$v['tag_id'];
			$tag_posts = $this->tags_posts->where("tag_id=$tag_id")->count();			
			$tag[$key]['num'] = $tag_posts;
		}
		//print_r($tag);die;
		//print_r($result);die;
		/*$tree = new \Tree();
		$tree->icon = array('&nbsp;&nbsp;&nbsp;│ ', '&nbsp;&nbsp;&nbsp;├─ ', '&nbsp;&nbsp;&nbsp;└─ ');
		$tree->nbsp = '&nbsp;&nbsp;&nbsp;';
		foreach ($result as $r) {
			$r['str_manage'] = '<a href="' . U("AdminTerm/add", array("parent" => $r['term_id'])) . '">'.L('ADD_SUB_CATEGORY').'</a> | <a href="' . U("AdminTerm/edit", array("id" => $r['term_id'])) . '">'.L('EDIT').'</a> | <a class="js-ajax-delete" href="' . U("AdminTerm/delete", array("id" => $r['term_id'])) . '">'.L('DELETE').'</a> ';
			$url=U('portal/list/index',array('id'=>$r['term_id']));
			$r['url'] = $url;
			$r['taxonomys'] = $this->taxonomys[$r['taxonomy']];
			$r['id']=$r['term_id'];
			$r['parentid']=$r['parent'];
			$array[] = $r;
		}
		
		$tree->init($array);
		$str = "<tr>
					<td><input name='listorders[\$id]' type='text' size='3' value='\$listorder' class='input input-order'></td>
					<td>\$id</td>
					<td>\$spacer <a href='\$url' target='_blank'>\$name</a></td>
	    			<td>\$taxonomys</td>
					<td>\$str_manage</td>
				</tr>";
		$taxonomys = $tree->get_tree(0, $str);*/
		$this->assign("tag", $tag);
		$this->assign("module_name", strtolower(MODULE_NAME));
		$this->display();
	}
	
	// 文章分类添加
	public function add(){
	 	
	 	$this->display();
	}
	
	// 文章分类添加提交
	public function add_post(){
		if (IS_POST) {
			
			if($this->tags_model->create() !== false){
				/*if(empty(I("post.name"))){
				$this->error("标签名不能为空");
				}
				$name = MD5(trim(I("post.name")));
				$isname = $this->tags_model->where("slug='$name'")->find();
				if(isset($isname)){
					$this->error("已存在同名标签");
				}*/
				
				/*$data['tag_name'] = trim(I("post.name"));
				$data['slug'] = MD5(trim(I("post.name")));
				$data['description']=htmlspecialchars(I("post.description"));
				$data['tag_alias'] = trim(I("post.alias"));
				//echo MODULE_NAME;die;
				$result=$this->tags_model->add($data);*/
				$alias = trim(I("post.tag_alias"));
				$isalias = 'tag/'.$alias;
				/*$resalias = M("Route")->where(array("url" => $isalias))->find();					
				if($resalias){
					$this->error("别名已存在！");
				}*/
				$result=$this->tags_model->add();							
				if($alias !== ''){											
					$module_name = strtolower(MODULE_NAME);
					$route['url'] = 'tag/'.$alias;
					$route['full_url'] = $module_name.'/tag/index?id='.$result;
					$route['status'] = 1;
					M("Route")->add($route);
					sp_get_routes(true);										
				}
				
				if ($result) {
					$this->success("添加成功！");
				} else {
					$this->error("添加失败！");
				}
			}else{
				$this->error($this->tags_model->getError());
			}						
		}
	}
	
	// 文章分类编辑
	public function edit(){
		$id = I("get.id");
		$data=$this->tags_model->where(array("tag_id" => $id))->find();
		
		$this->assign("data",$data);
		$this->display();
	}
	
	// 文章分类编辑提交
	public function edit_post(){
		if (IS_POST) {
			
			if($this->tags_model->create() !== false){
				/*if(empty(I("post.name"))){
				$this->error("标签名不能为空");
				}*/
				/*$name = MD5(trim(I("post.tag_name")));
				$isname = $this->tags_model->where("slug='$name'")->find();
				if(isset($isname)){
					$this->error("已存在同名标签");
				}
				$id = I("post.id");			
				/*$data['tag_name'] = trim(I("post.name"));
				$data['slug'] = MD5(trim(I("post.name")));
				$data['description']=htmlspecialchars(I("post.description"));
				$data['tag_alias'] = trim(I("post.alias"));*/
				//$result = $this->tags_model->where(array("tag_id" => $id))->save($data);
				$alias = trim(I("post.tag_alias"));
				$tag_id = I("post.tag_id");	
				
				$isalias = 'tag/'.$alias;
				$module_name = strtolower(MODULE_NAME);
				$full_url = $module_name.'/tag/index?id='.$tag_id;
								
				$resfull_url = M("Route")->where(array("full_url" => $full_url))->find();	
				/*$resalias = $this->tags_model->where(array("tag_alias" => $alias))->find();	
				if($resalias){
					$this->error("别名已存在！");
				}*/
				
				if($alias == ''){
					M("Route")->where(array("full_url" => $full_url))->delete();
				}
				$result = $this->tags_model->save();
				
				
				if($resfull_url){
					//$alias = 'tag/'.$alias;
					$route['url'] = 'tag/'.$alias;
					
					//$route['full_url'] = $module_name.'/tag/index?id='.$tag_id;
					$route['status'] = 1;
					M("Route")->where("full_url='$full_url'")->save($route);
					sp_get_routes(true);
				}else{
					$route['url'] = 'tag/'.$alias;
					$route['full_url'] = $module_name.'/tag/index?id='.$tag_id;
					$route['status'] = 1;
					M("Route")->add($route);
					sp_get_routes(true);
				}
				
				//$tag_alias = $this->tags_model->where("tag_id='$tag_id'")->find();
																				
				
				
				if ($result !== false) {				   
					$this->success("修改成功！");
				} else {
					$this->error("修改失败！");
				}
			}else{
				$this->error($this->tags_model->getError());
			}
			
					
		}
	}
	
	// 文章分类排序
	public function listorders() {
		$status = parent::_listorders($this->tags_model);
		if ($status) {
			$this->success("排序更新成功！");
		} else {
			$this->error("排序更新失败！");
		}
	}
	
	// 删除文章分类
	public function delete() {
		
		$module_name = strtolower(MODULE_NAME);
		
		
		//echo $full_url;die;
		//print_r($_POST['fullurl']);die;
		
		if(isset($_POST['ids'])){
			$ids=join(",",$_POST['ids']);
			//echo $ids;die;
			$del_tags = $this->tags_posts->where("tag_id in ($ids)")->delete();
			foreach($_POST['ids'] as $v){
				$full_url = $module_name.'/tag/index?id='.$v;
				$del_tags = M('Route')->where("full_url='$full_url'")->delete();
			}
			if ($this->tags_model->where("tag_id in ($ids)")->delete()!==false && $del_tags!==false) {
				$this->success("删除成功！");
			} else {
				$this->error("删除失败！");
			}
		}
		
		if(isset($_GET['id'])){
			$id = I("get.id");
			$full_url = $module_name.'/tag/index?id='.$id;
			$del_tag = $this->tags_posts->where("tag_id=$id")->delete();			
			$del_route = M('Route')->where("full_url='$full_url'")->delete();		
			if ($this->tags_model->delete($id)!==false && $del_tag!==false && $del_route!==false) {
				$this->success("删除成功！");
			} else {
				$this->error("删除失败！");
			}
		}
	}
	
}