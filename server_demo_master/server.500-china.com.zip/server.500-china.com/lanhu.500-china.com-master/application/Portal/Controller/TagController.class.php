<?php

namespace Portal\Controller;

use Common\Controller\HomebaseController;

class TagController extends HomebaseController {
    
    //搜索结果页面
    public function index() {
		$tid =I('get.id');
		$tag = M('Tag');
		$tag_posts = M('Tag_posts');
		$tagname = $tag->where("tag_id=$tid")->find();
		$post_num = $tag_posts->where("tag_id=$tid")->count();
				
		
		$this->assign('tid',$tid);
		$this->assign('tagname',$tagname);
		$this->assign('post_num',$post_num);
		$this -> display(":tag");
    }
    
}
