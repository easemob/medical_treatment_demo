<?php
/*
 *      _______ _     _       _     _____ __  __ ______
 *     |__   __| |   (_)     | |   / ____|  \/  |  ____|
 *        | |  | |__  _ _ __ | | _| |    | \  / | |__
 *        | |  | '_ \| | '_ \| |/ / |    | |\/| |  __|
 *        | |  | | | | | | | |   <| |____| |  | | |
 *        |_|  |_| |_|_|_| |_|_|\_\\_____|_|  |_|_|
 */
/*
 *     _________  ___  ___  ___  ________   ___  __    ________  _____ ______   ________
 *    |\___   ___\\  \|\  \|\  \|\   ___  \|\  \|\  \ |\   ____\|\   _ \  _   \|\  _____\
 *    \|___ \  \_\ \  \\\  \ \  \ \  \\ \  \ \  \/  /|\ \  \___|\ \  \\\__\ \  \ \  \__/
 *         \ \  \ \ \   __  \ \  \ \  \\ \  \ \   ___  \ \  \    \ \  \\|__| \  \ \   __\
 *          \ \  \ \ \  \ \  \ \  \ \  \\ \  \ \  \\ \  \ \  \____\ \  \    \ \  \ \  \_|
 *           \ \__\ \ \__\ \__\ \__\ \__\\ \__\ \__\\ \__\ \_______\ \__\    \ \__\ \__\
 *            \|__|  \|__|\|__|\|__|\|__| \|__|\|__| \|__|\|_______|\|__|     \|__|\|__|
 */
// +----------------------------------------------------------------------
// | ThinkCMF [ WE CAN DO IT MORE SIMPLE ]
// +----------------------------------------------------------------------
// | Copyright (c) 2013-2014 http://www.thinkcmf.com All rights reserved.
// +----------------------------------------------------------------------
// | Author: Dean <zxxjjforever@163.com>
// +----------------------------------------------------------------------
namespace Portal\Controller;

use Common\Controller\HomebaseController; 
/**
 * 首页
 */
class CareRecommendController extends HomebaseController {
	
    //首页 小夏是老猫除外最帅的男人了
	public function index() {
    	$this->display(":shop");
    }
	
	//获取首页推荐信息列表
	public function getPersonalRecommendJson() {
    	$userid=I('userid',0,'intval');
		$care_model=M("CareFriends");
		$post_model=M("Posts");
		$goods_model= M("Goods");
		$comments_model= M("Comments");
		$limit = '0,20';
		$group = 'fuid';
    	$order = "post_date DESC";
		$join = '__POSTS__ as posts on carefriends.fuid = posts.post_author';
		$where['posts.post_status'] = array('eq',1);
		$where['posts.post_type'] = array('eq',1);
		$field = 'posts.id as object_id,post_title,post_author,post_date,post_type,post_excerpt,
		smeta,post_status,post_authorname,post_avatar,photos_urls,post_goods,comment_count,post_hits,post_like';
		$posts=array();
		if(empty($userid)){
		$wheres['post_status'] = array('eq',1);
			$wheres['post_type'] = array('eq',1);
			$wheres['recommended'] = array('eq',1);
			$fields = 'id as object_id,post_title,post_author,post_date,post_type,post_excerpt,
		smeta,post_status,post_authorname,post_avatar,photos_urls,post_goods,comment_count,post_hits,post_like';
			$posts=$post_model->field($fields)->where($wheres)->order($order)->limit($limit)->select();
		}else{
		$posts=$care_model->alias("carefriends")->join($join)->field($field)->where($where)
		->group($group)->order($order)->limit($limit)->select();
		if(!$posts){
		$wheres['post_status'] = array('eq',1);
			$wheres['post_type'] = array('eq',1);
			$wheres['recommended'] = array('eq',1);
			$fields = 'id as object_id,post_title,post_author,post_date,post_type,post_excerpt,
		smeta,post_status,post_authorname,post_avatar,photos_urls,post_goods,comment_count,post_hits,post_like';
			$posts=$post_model->field($fields)->where($wheres)->order($order)->limit($limit)->select();
		}
		}
		foreach ($posts as $key => $value) {
				if(!empty($value['smeta'])){
					if(empty($value['photos_urls'])){
					$posts[$key]['photos_urls']=array();
					}else{
					$posts[$key]['photos_urls']=json_decode($value['photos_urls'], true);
					}
					$posts[$key]['smeta']=json_decode($value['smeta'], true);
					$posts[$key]['thumb'] = $posts[$key]['smeta']['thumb'];
					unset($posts[$key]['smeta']);
				}
				if(!empty($value['post_goods'])){
					$goods_where['goods_id'] = array('in',$value['post_goods']);
					$goods_array=$goods_model->field($goods_field)->where($goods_where)->select();
					$posts[$key]['goods_array']=$goods_array;
				}
				if(!empty($value['comment_count'])){
					$comments_where['post_id'] = array('eq',$value['object_id']);
					$comment_array=$comments_model->field($comments_field)->where($comments_where)->select();
					$posts[$key]['comment_array']=$comment_array;
				}
			}
			$this->successJson("获取首页推荐信息列表成功!",$posts);
		
    }
	
	
	//获取首页社区信息列表
	public function getPersonalCommunityJson() {
		$ships_model=M("PostGroupships");
		$userid=I('userid',0,'intval');
		$group_id=I('group_id',1,'intval');
		$care_model=M("CareFriends");
		$post_model=M("Posts");
		$goods_model= M("Goods");
		$comments_model= M("Comments");
		$limit = '0,20';
    	$order = "post_date DESC";
		$join = '__POSTS__ as posts on groupships.object_id = posts.id';
		$where['posts.post_status'] = array('eq',1);
		$where['posts.post_type'] = array('eq',1);
		$where['groupships.group_id'] = array('eq',1);
		$field = 'posts.id as object_id,post_title,post_author,post_date,post_type,post_excerpt,
		smeta,post_status,post_authorname,post_avatar,photos_urls,post_goods,comment_count,post_hits,post_like';
		$posts=$ships_model->alias("groupships")->join($join)->field($field)->where($where)
		->order($order)->limit($limit)->select();
		if($posts){
		foreach ($posts as $key => $value) {
				if(!empty($value['smeta'])){
					if(empty($value['photos_urls'])){
					$posts[$key]['photos_urls']=array();
					}else{
					$posts[$key]['photos_urls']=json_decode($value['photos_urls'], true);
					}
					$posts[$key]['smeta']=json_decode($value['smeta'], true);
					$posts[$key]['thumb'] = $posts[$key]['smeta']['thumb'];
					unset($posts[$key]['smeta']);
				}
				if(!empty($value['post_goods'])){
					$goods_where['goods_id'] = array('in',$value['post_goods']);
					$goods_array=$goods_model->field($goods_field)->where($goods_where)->select();
					$posts[$key]['goods_array']=$goods_array;
				}
				if(!empty($value['comment_count'])){
					$comments_where['post_id'] = array('eq',$value['object_id']);
					$comment_array=$comments_model->field($comments_field)->where($comments_where)->select();
					$posts[$key]['comment_array']=$comment_array;
				}
			}
			$this->successJson("获取首页社区信息列表成功!",$posts);
		}else{
		$this->errorJson("暂无此社区信息!");
		}
	}

}


