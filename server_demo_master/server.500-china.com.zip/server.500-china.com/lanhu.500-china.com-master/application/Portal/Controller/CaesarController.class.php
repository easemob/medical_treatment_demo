<?php
/*
 *      _______ _     _       _     _____ __  __ ______
 *     |__   __| |   (_)     | |   / ____|  \/  |  ____|
 *        | |  | |__  _ _ __ | | _| |    | \  / | |__
 *        | |  | '_ \| | '_ \| |/ / |    | |\/| |  __|
 *        | |  | | | | | | | |   <| |____| |  | | |
 *        |_|  |_| |_|_|_| |_|_|\_\\_____|_|  |_|_|
 */
/*
 *     _________  ___  ___  ___  ________   ___  __    ________  _____ ______   ________
 *    |\___   ___\\  \|\  \|\  \|\   ___  \|\  \|\  \ |\   ____\|\   _ \  _   \|\  _____\
 *    \|___ \  \_\ \  \\\  \ \  \ \  \\ \  \ \  \/  /|\ \  \___|\ \  \\\__\ \  \ \  \__/
 *         \ \  \ \ \   __  \ \  \ \  \\ \  \ \   ___  \ \  \    \ \  \\|__| \  \ \   __\
 *          \ \  \ \ \  \ \  \ \  \ \  \\ \  \ \  \\ \  \ \  \____\ \  \    \ \  \ \  \_|
 *           \ \__\ \ \__\ \__\ \__\ \__\\ \__\ \__\\ \__\ \_______\ \__\    \ \__\ \__\
 *            \|__|  \|__|\|__|\|__|\|__| \|__|\|__| \|__|\|_______|\|__|     \|__|\|__|
 */
// +----------------------------------------------------------------------
// | ThinkCMF [ WE CAN DO IT MORE SIMPLE ]
// +----------------------------------------------------------------------
// | Copyright (c) 2013-2014 http://www.thinkcmf.com All rights reserved.
// +----------------------------------------------------------------------
// | Author: Dean <zxxjjforever@163.com>
// +----------------------------------------------------------------------
namespace Portal\Controller;
Vendor('showapi.Autoloader');
require  __ROOT__."./vendor/autoload.php";
Vendor('JPush.autoload');
//import('Vendor.JPush.autoload');
use JPush\Client as JPushClient;

//use Http\ShowapiRequest as ShowapiRequest;

use Think\Controller;

// 引入鉴权类
use Qiniu\Auth;
// 引入上传类
use Qiniu\Storage\UploadManager;

use Common\Controller\HomebaseController; 
header("Content-type:text/html;charset=utf-8");
/**
 * 首页
 */
class CaesarController extends HomebaseController {
	
	
    public function index()
    {
                                          //获取前台提交的手机号
        $url = "http://route.showapi.com/2199-4?showapi_appid=392555&showapi_sign=559f97e16162428cb719542aac13fb9b&keyword=%E8%BF%90%E5%8A%A8";

                                         //阿里云提供的接口app码
        $header = array("Content-Type:application/x-www-form-urlencoded");
        

        $method='GET';                                               //请求方式

        $curl=curl_init();                                           //初始化一个curl句柄,用于获取其它网站内容
        curl_setopt($curl, CURLOPT_CUSTOMREQUEST, $method); //请求方式
        curl_setopt($curl, CURLOPT_URL, $url);   //请求url
        //curl_setopt($curl, CURLOPT_HTTPHEADER, $headers); //请求头
		//curl_setopt($curl, CURLOPT_POSTFIELDS, $post_data);
        curl_setopt($curl, CURLOPT_FAILONERROR, false);  //是否显示HTTP状态码
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);//执行成功返回结果
        curl_setopt($curl, CURLOPT_HEADER, false);    //是否返回请求头信息
        
        $res=curl_exec($curl);//执行查询句柄
        curl_close($curl);    //关闭查询连接
        $resu=json_decode($res,true);//将json数据解码为php数组
		echo $res;exit;
        if($resu['showapi_res_body']['ret_code']==-1){          //返回错误码，查询失败
            return $this->error('没有查询结果，请重新输入','Index/index');
        }else{
            $this->assign('num',$num);           //将查询手机号写入模板
            $this->assign('res',$resu);          //将查询结果php数组写入模板
            return $this->fetch('index');
        }
    }
	//首页 小夏是老猫除外最帅的男人了
	public function showtest() {
	$url = "http://route.showapi.com/2199-4";//调用URL,根据情况改变此值
	$METHOD = "POST";//或者是GET,根据情况改变此值
	$showapi_appid="392555";
	$showapi_sign="559f97e16162428cb719542aac13fb9b";
	$text="运动鞋";  //根据情况改变此值
	//exit;
	$req = new ShowapiRequest($url,$showapi_appid,$showapi_sign);
	$response=$req->addTextPara("keyword", $text)->get();
	print_r($response->getContent());
	}

	//首页 小夏是老猫除外最帅的男人了
	public function showapi() {
		$sortArray = array(
		"general",//综合
		"popularity_descending",//最热
		"time_descending"//最新
		);
		if (IS_POST){
		$tid=I('post.tid',12,'intval');
		$keyword=I('post.keyword');
		$page=I('post.page',1,'intval');
		$sort=I('post.sort',0,'intval');
		$terms_model =M('Terms');
		$posts_model=M('Posts');
		$users_model=M('Users');
		$term_relationships_model=M('TermRelationships');
		if(empty($keyword)){
		$keyword=$terms_model->where(array("term_id"=>$tid))->getField('name');
		}
		if(empty($tid)){
			$this->errorJson("请核对分类ID");
		}
		if($page>=50){
			$this->errorJson("采集起始数不能大于50");
		}
	
		$receiverNumber=I('post.receiverNu',2,'intval');
		$url = "http://route.showapi.com/2199-4";//调用URL,根据情况改变此值
		$METHOD = "POST";//或者是GET,根据情况改变此值
		$curl = curl_init();
		$header = array("Content-Type:application/x-www-form-urlencoded");
		$post_data = array("showapi_appid" => "392555","showapi_sign" => "559f97e16162428cb719542aac13fb9b",
		"keyword"=>$keyword,"page"=>$page,"sort"=>$sortArray[$sort]);
  		curl_setopt($curl, CURLOPT_URL, $url);
		curl_setopt($curl, CURLOPT_CUSTOMREQUEST, $METHOD); //请求方式
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
		curl_setopt($curl, CURLOPT_POSTFIELDS, $post_data);
		$data = curl_exec($curl);
		curl_close($curl);
		$jsonData=json_decode($data,true);//将json数据解码为php数组
		$showapi_res_code=$jsonData['showapi_res_code'];
		$showapi_res_error=$jsonData['showapi_res_error'];
		$total_count=0;
		$dateTime=date("Y-m-d H:i:s",time());
		if($showapi_res_code==0){          //返回错误码，查询失败
			$showapi_res_body=$jsonData['showapi_res_body'];
            $retCode=$showapi_res_body['retCode'];
			if($retCode==0){ 
				$result=$showapi_res_body['result'];
				$resultCode=$result['result'];
				if($resultCode==0){ 
					$resultData=$result['data'];
					$total_count=$resultData['total_count'];
					$notes=$resultData['notes'];
					//echo json_encode($notes);exit;
					foreach ($notes as $note){
						
						$noteID = $note['id'];
						
						$isExit=$posts_model->where(array('post_mobile'=>$noteID))->find();
						if($isExit){
						 continue;
						}
						
						$noteUser = $note['user'];
						$userID = $noteUser['userid'];
						$nickname = $noteUser['nickname'];
						$userimages = $noteUser['images'];
						$noteTitle = $note['title'];
						$noteDesc = $note['desc'];
						$image_info = $note['image_info'];
						$noteImage=$image_info['original'];
						$noteType = $note['type'];
						$noteData=array(
	        			'noteId' => $noteID,
						'noteTitle' => $noteTitle,
						'noteDesc' => $noteDesc,
	        			'userID' => $userID,
						'nickName' => $nickname,
						'userImages' => $userimages,
						'noteImage' => $noteImage,
						'noteType' => $noteType,
	    				);
						$userRandID= mt_rand(80,100);
						$_POST['post']['post_title']=urlencode($noteData['noteTitle']);
			$_POST['post']['post_excerpt']=urlencode($noteData['noteDesc']);
			$_POST['post']['post_keywords']=urlencode($noteData['noteTitle']);
			$_POST['post']['post_mobile']=$noteData['noteId'];
			$_POST['post']['post_delivery']=$startNO*10+$num;
			$_POST['post']['post_source']="https://www.xiaohongshu.com/discovery/item/".$noteData['noteId'];
			$_POST['post']['recommended']=$sort;
            $_POST['smeta']['thumb'] = $noteData['noteImage'];
            $_POST['post']['post_date']=$dateTime;
            $_POST['post']['post_modified']=$dateTime;
            $_POST['post']['post_author']=$userRandID;
			$_POST['post']['category_id']=$tid;
			$userData=$users_model->where(array("id"=>$userRandID))->find();
			$_POST['post']['post_authorname']=$userData['user_nicename'];
			$_POST['post']['post_avatar']=$userData['avatar'];
			$rand=mt_rand(0,1);
			$post_goods=array();
			for ($i=0; $i<=$rand; $i++) {
				$good_rand=mt_rand(256,280);
				array_push($post_goods,$good_rand);
			}
			$goods_string=implode(",", $post_goods);
			$_POST['post']['goods_id']=$post_goods[0];
			$_POST['post']['post_goods']=$goods_string;
			$noteData['post_goods']=$goods_string;
			
			$_POST['post']['post_status']=1;
			
			if($noteType=='normal'){
							$imagesArray= array();
							$smetaPhotos= array();
							$imagesList=$note['images_list'];
							foreach ($imagesList as $imageData){
								$imagesUrl=$imageData['original'];
								array_push($imagesArray,$imagesUrl);
								array_push($smetaPhotos,array("url"=>$imagesUrl,"alt"=>""));
							}
							$noteData['imagesList']=$imagesArray;
							$_POST['post']['post_type']=1;
							$_POST['smeta']['photo']=$smetaPhotos;
						}else if($noteType=='video'){
							$noteVideo=$note['video_info'];
							$videoUrl=$noteVideo['url'];
							$noteData['video']=$videoUrl;
							$_POST['post']['post_type']=4;
						}
			$article=I("post.post");
			if($noteType=='normal'){
				$article['photos_urls']=json_encode($noteData['imagesList']);
			}else{
				$article['thumb_video']=$noteData['video'];
			}
			
			$article['smeta']=json_encode($_POST['smeta']);
			if ($posts_model->create($article)!==false) {
			$result=$posts_model->add();
			if ($result) {
            	$term_relationships_model->add(array("term_id"=>intval($tid),"object_id"=>$result,"status"=>1));
				$users_model->save(array("id"=>$userRandID,"user_posts"=>array("exp","user_posts+1")));
				$noteData['status']="success";
				$noteData['post_id']=$result;
			}else{
				$noteData['status']="failed";
			}}else{
				 $noteData['status']=$this->error($posts_model->getError());
			}
			echo json_encode($noteData);
					}
					echo json_encode("添加完成,共添加".$numSize."条数据");exit;
				}
				$this->error("result不为0");
			}
			$this->error("retCode不为0");
        }else{
            $this->error($jsonData['showapi_res_error']);
        }
	}else{
		$this->error("不是安全网络请求");
	}
    }
	
	public function autoCareJsonThree() {
		$ships_model=M("PostGroupships");
		$log_list=array();
		$post_data = array("2541","2542","2543","2544","2545","2546","2547","2548");
		foreach ($post_data as $postid) {
			$ship_data=array("object_id"=>$postid,"group_id"=>1);
			$ships_model->add($ship_data);
			array_push($log_list,$ship_data);
		}
		echo json_encode($log_list);exit;
	}
	
	public function autoCareJsonTwo() {
		$post_data = array("2541","2542","2543","2544","2545","2546","2547","2548");
		$user_model=M("Users");
		$group_model=M("Groups");
		$group_members_model=M("GroupMembers");
		$log_list=array();
		for ($i=80; $i<=100; $i++)
		{
			$user_id=$i;
			$group_id=1;
			$timestamp=time();
			$datetime=date("Y-m-d H:i:s",time());
			$user_data=$user_model->where(array("id"=>$user_id))->find();
			$member_data['groupId']=$group_id;
			$member_data['memberId']=$user_id;
			$member_data['displayName']=$user_data['user_nicename'];
			$member_data['dispalyAvatar']=$user_data['avatar'];
			$member_data['timestamp']=$timestamp;
			$member_data['member_state']=1;
			$member_data['createdAt']=$datetime;
			$member_data['updatedAt']=$datetime;
			$res=$group_members_model->add($member_data);
			$group_model->save(array("group_id"=>$group_id,"memberCount"=>array("exp","memberCount+1")));
			array_push($log_list,$user_data);
		}
		echo json_encode($log_list);exit;
	}
	
	public function autoCareJsonOne() {
		$posts_model=M("Posts");
		$users_model=M("Users");
		$follow_model=M("PostsFollow");
		$post_data = array("2541","2542","2543","2544","2545","2546","2547","2548");
		$log_list=array();
		for ($i=80; $i<=100; $i++)
		{
    		$userid=$i;
			foreach ($post_data as $postid) {
				$result=$follow_model->where(array('user' => $userid,'postid' => $postid))->find();
		if($result){
			$follow_model->where(array("user"=>$userid,"postid"=>$postid))->save(array('is_care' => 1));
			$posts_model->save(array("id"=>$postid,"post_like"=>array("exp","post_like+1")));
			$users_model->save(array("id"=>$userid,"user_likes"=>array("exp","user_likes+1")));
		}else{
			$datetime=time();
			$data=array(
	        'user' => $userid,
	        'postid' => $postid,
	        'follow_time' =>$datetime,
	        'is_care' => 1
	    	);
			$follow_model->add($data);
			array_push($log_list,$data);
			$posts_model->save(array("id"=>$postid,"post_like"=>array("exp","post_like+1")));
			$users_model->save(array("id"=>$userid,"user_likes"=>array("exp","user_likes+1")));
		}
			}
		}
		echo json_encode($log_list);exit;
	}
}


