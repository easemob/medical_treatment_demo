<?php

return array(
		'DEFAULT_THEME' => '',
		
);

