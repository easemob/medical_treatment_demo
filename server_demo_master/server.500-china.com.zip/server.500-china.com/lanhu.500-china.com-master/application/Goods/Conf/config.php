<?php
return array(
	//更改googs、user config
	'ORDER_STATUS' => array(
        0 => '<span style="color:red;">待确认</span>',
        1 => '已确认',
        2 => '订单完成',
        3 => '<span style="color:red;">退货</span>',                
        4 => '<span style="color:red;">无效</span>',
    ),
    'SHIPPING_STATUS' => array(
        0 => '<span style="color:red;">未发货</span>',
        1 => '已发货',        
        2 => '已收货',        
    ),
    'PAY_STATUS' => array(
        0 => '<span style="color:red;">未支付</span>',
        1 => '已支付',
		3 => '货到付款',
    ),
	
	//不能接入是否宝，暂不做
	/*'payment' => array(
        'tenpay' => array(
            // 加密key，开通财付通账户后给予
            'key' => 'e82573dc7e6136ba414f2e2affbe39fa',
            // 合作者ID，财付通有该配置，开通财付通账户后给予
            'partner' => '1900000113'
        ),
        'alipay' => array(
            // 收款账号邮箱
            'email' => 'zxc40962@163.com',
            // 加密key，开通支付宝账户后给予
            'key' => 'i1djj0eyvm5bdbmhj1rp3xjp6q0kzhli',
            // 合作者ID，支付宝有该配置，开通易宝账户后给予
            'partner' => '2088602009873030'
        ),
        'palpay' => array(
            'business' => 'zyj@qq.com'
        ),
        'yeepay' => array(
            'key' => '69cl522AV6q613Ii4W6u8K6XuW8vM1N6bFgyv769220IuYe9u37N4y7rI4Pl',
            'partner' => '10001126856'
        )
    )*/
);