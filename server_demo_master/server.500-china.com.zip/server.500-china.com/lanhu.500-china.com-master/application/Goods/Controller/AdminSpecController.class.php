<?php

namespace Goods\Controller;

use Common\Controller\AdminbaseController;

class AdminSpecController extends AdminbaseController {
	
	protected $spec_model;
		
	function _initialize() {
		parent::_initialize();
		$this->spec_model = D("Goods/Spec");
		$this->goods_type = D("Goods/GoodsType");
		
	}
	
	// 后台供求分类列表
    public function index(){		
		$typelist = $this->goods_type->select();
		$this->assign('typelist',$typelist);
		
		$this->display();
	}
	
	// 后台供求规格列表
	public function ajaxSpecList(){
		
		$keyword=trim(I('keyword'));
        if($keyword)
        {
			 $where['spec_name']=array('like',"%$keyword%");			 	 
        }
		$type_id = I('id');
		if($type_id)
		{
			$where['type_id']=$type_id;
		}
				
		$count=$this->spec_model->where($where)->count();		
		$page = $this->ajaxpage($count,10);			
		$this->spec_model->field('a.*,b.name');
		$this->spec_model
		->alias('a')
		->join('__GOODS_TYPE__ b ON a.type_id = b.id')
		->where($where)
		->limit($page->firstRow , $page->listRows)		
		->order('a.id desc');	
		
		$speclist = $this->spec_model->select();
		foreach($speclist as $key=>$v){						
			$speclist[$key]['items'] = $this->specItem($v['id']);			
		}

		$this->assign('speclist',$speclist);		
		$this->assign('page',$page->show('Admin'));
		$this->display();
	}
	
	//获取规格
	public function specItem($id){              
        $item = M('SpecItem')->where(array("spec_id"=>$id))->order('id')->select();
		$arr2 = array();
		foreach($item as $key => $val){
			$arr2[$val['id']] = $val['item'];
		}		
		$items = implode(',',$arr2);       
        return $items;
	}
	
	//添加
	public function add(){
		$typelist = $this->goods_type->select();
		$this->assign('typelist',$typelist);
		$this->display();
	}
	
	public function add_post(){
		if(IS_POST){			
			if($this->spec_model->create() !== false){				
				$result=$this->spec_model->add();
				$item = explode(PHP_EOL,I('post.item'));
				foreach ($item as $key => $val)  // 去除空格
				{
					$val = str_replace('_', '', $val); // 替换特殊字符
					$val = str_replace('@', '', $val); // 替换特殊字符
					
					$val = trim($val);
					if(empty($val)) 
						unset($item[$key]);
					else                     
						$item[$key] = $val;
				}
				foreach($item as $key => $val){
					$dataList[] = array('spec_id'=>$result,'item'=>$val);
				}
				$result2 = M('SpecItem')->addAll($dataList);
				if ($result && $result2) {
					$this->success("添加成功！");
				} else {
					$this->error("添加失败！");
				}
			}else{
				$this->error($this->spec_model->getError());
			}						
		}
	}
	
	//编辑
	public function edit(){		
		$id = I("get.id",0,'intval');
		$data = $this->spec_model->where(array("id"=>$id))->find();
		$typelist = $this->goods_type->select();
		
		$item = M('SpecItem')->where(array("spec_id"=>$id))->order('id')->select();
		$arr2 = array();
		foreach($item as $key => $val){
			$arr2[$val['id']] = $val['item'];
		}		
		$items = implode(PHP_EOL,$arr2);
						
		$this->assign('typelist',$typelist);
		$this->assign('data',$data);
		$this->assign('items',$items);
		$this->display();
	}
	
	public function edit_post(){
		if(IS_POST){
			if($this->spec_model->create() !== false){				
				
				$item = explode(PHP_EOL,I('post.item'));
				foreach ($item as $key => $val)  // 去除空格
				{
					$val = str_replace('_', '', $val); // 替换特殊字符
					$val = str_replace('@', '', $val); // 替换特殊字符
					
					$val = trim($val);
					if(empty($val)) 
						unset($item[$key]);
					else                     
						$item[$key] = $val;
				}
				$result=$this->spec_model->save();
												
				$db_items = M('SpecItem')->where(array("spec_id" => $_POST['id']))->getField('id,item');
				
				foreach($item as $key => $val){				
					 if(!in_array($val, $db_items)){//post的规格是否存在数据库
						 $dataList[] = array('spec_id'=>$_POST['id'],'item'=>$val);//不存在则添加
					 } 
				}
				
				$result2 = M('SpecItem')->addAll($dataList);
				foreach($db_items as $k=>$v){
					if(!in_array($v,$item)){//数据库是否存在post的规格
						M('SpecItem')->where(array("id"=>$k))->delete();//不存在则删除
					}
				}				
				
				if ($result!==false) {
					$this->success("保存成功！");
				} else {
					$this->error("保存失败！");
				}
			}else{
				$this->error($this->spec_model->getError());
			}
		}
	}
		
	
	//删除
	public function delete(){
		$id = $_GET['id'];
		$result = $this->spec_model->where(array("id" => $id))->delete();
		M('SpecItem')->where(array("spec_id" => $id))->delete();
		if($result!==false){
			$this->success('删除成功');
		}else{
			$this->error('删除失败');
		}
	}
	
	public function delete_all(){
		if(isset($_POST['ids'])){
			$ids = I('post.ids/a');
			M('SpecItem')->where(array("spec_id" => array('in',$ids)))->delete();
			if ($this->spec_model->where(array('id'=>array('in',$ids)))->delete()!==false) {
				$this->success("删除成功！");
			} else {
				$this->error("删除失败！");
			}
		}
	}
	
	/**
     * ajax 修改指定表数据字段  一般修改状态 比如 是否推荐 是否开启 等 图标切换的
     * table,id_name,id_value,field,value
     */
    public function changeTableVal(){  	
            $table = I('table'); // 表名
            $id_name = I('id_name'); // 表主键id名
            $id_value = I('id_value'); // 表主键id值
            $field  = I('field'); // 修改哪个字段
            $value  = I('value'); // 修改字段值                        
            M($table)->where("$id_name = $id_value")->save(array($field=>$value)); // 根据条件保存修改的数据
			M('SpecItem')->where(array("spec_id" => $id_value))->save(array("item_order"=>$value));//修改规格排序
    }
	
}