<?php

namespace Goods\Controller;
use Common\Controller\HomebaseController;

class ListController extends HomebaseController {

	// 前台商品列表
	public function index() {
	    $id=I('get.id',0,'intval');
		$category=sp_get_term($id);

		$all_catid = sp_get_all_catid($id); //获取所有子类
								
		if(empty($category)){
		    header('HTTP/1.1 404 Not Found');
		    header('Status:404 Not Found');
		    if(sp_template_file_exists(MODULE_NAME."/404")){
		        $this->display(":404");
		    }
		    return;
		}
		
		$crumbs = sp_get_breadcrumb($id);
		
		$sort = $_GET['order'] == 'desc' ? 'asc' : 'desc';
		
		if($sort == 'desc' && isset($_GET['order'])){
			$sort_icon = '<i class="fa fa-long-arrow-up"></i>';
		}else if($sort == 'asc' && isset($_GET['order'])){
			$sort_icon = '<i class="fa fa-long-arrow-down"></i>';
		}
		
		if(isset($_GET['sort']) && isset($_GET['order'])){			
			$order = "{$_GET['sort']} {$_GET['order']},on_time DESC";
		}
		
		if(empty($all_catid)){
			$where=array("cat_id"=>$id,"is_on_sale"=>1,"is_delete"=>"neq 3");
		}else{
			$where=array("cat_id"=>array('in',implode(',',$all_catid)),"is_on_sale"=>1,"is_delete"=>"neq 3");
		}
		
		$count = M('Goods')->where($where)->count();
		$page = $this->page($count, 12);
		$list = M('Goods')
		->where($where)
		->limit($page->firstRow , $page->listRows)
		->order($order)
		->select();
		
		
		$tplname=$category["list_tpl"];
    	$tplname=sp_get_apphome_tpl($tplname, "list");
		
    	
    	$this->assign('crumbs', $crumbs);    	
    	$this->assign('category', $category['name']);
		$this->assign('list', $list);
		$this->assign('page', $page->show('Home'));
		$this->assign('cat_id', $id);
		$this->assign('sort', $sort);
		$this->assign('sort_icon', $sort_icon);
    	$this->display(":$tplname");
	}
	
	
	// 用于后台导航编辑添加
	public function nav_index(){
		$navcatname="商品分类";
        $category_obj= M("Goods_category");

        $where=array();
        $where['is_show'] = array('eq',1);
        $categorys=$category_obj->field('id,name,parent_id')->where($where)->order('id')->select();
		$datas=$categorys;
		$navrule = array(
		    "id"=>'id',
            "action" => "Goods/List/index",
            "param" => array(
                "id" => "id"
            ),
            "label" => "name",
		    "parentid"=>'parent_id'
        );
		return sp_get_nav4admin($navcatname,$datas,$navrule) ;
	}
	
	// 获取推荐商品
	public function goods_hot_json(){
		$goods_model= M("Goods");
		$goods_field = 'goods_id,cat_id,goods_name,goods_remark,goods_img,shop_price,good_desc,store_count';
		$recommed_array=$goods_model->field($goods_field)->where(array("is_hot"=>1))->limit('0,6')->select();
		$this->successJson("获取推荐商品成功！", $recommed_array);
	}
	
	// 获取推荐商品
	public function goods_recommend_json(){
		$goods_model= M("Goods");
		$goods_field = 'goods_id,cat_id,goods_type,goods_name,goods_remark,goods_img,shop_price,good_desc,store_count';
		$recommed_array=$goods_model->field($goods_field)->where(array("is_recommend"=>1))->limit('0,20')->select();
		$this->successJson("获取推荐商品成功！", $recommed_array);
	}
	
	// 获取品牌推荐商品
	public function goods_recommend_type(){
		$goods_model= M("Goods");
		$goods_type= I("goods_type",1,'intval');
		$goods_field = 'goods_id,cat_id,goods_type,goods_name,goods_remark,goods_img,shop_price,good_desc,store_count';
		$recommed_array=$goods_model->field($goods_field)->where(array("goods_type"=>$goods_type))->limit('0,20')->select();
		$this->successJson("获取推荐商品成功！", $recommed_array);
	}
	
	// 获取关联商品的文章
	public function goods_articles_json(){
		$userid=I('userid',0,'intval');
		$goods_id= I("goods_id",1,'intval');
    	$order = "post_date DESC";
		$where[] = "CONCAT (',',post_goods,',') REGEXP '(,".$goods_id.",)'";
		$where['posts.post_status'] = array('eq',1);
		$where['posts.post_type'] = array('eq',1);
		$limit = '0,9';
		$field = 'tid,object_id,term_id,post_title,post_author,post_date,post_type,post_excerpt,smeta,post_status,post_authorname,post_avatar,photos_urls,post_goods,comment_count,post_hits,post_like,thumb_video';
		$join = '__POSTS__ as posts on term_relationships.object_id = posts.id';
    	$order = "post_date DESC";
    	$term_relationships_model= M("TermRelationships");
		$posts=$term_relationships_model
    	    ->alias("term_relationships")
    	    ->join($join)
    	    ->field($field)
    	    ->where($where)
    	    ->order($order)
    	    ->limit($limit)
    	    ->select();
		//echo M()->getLastSql();exit;
		$goods_model= M("Goods");
		$comments_model= M("Comments");
		$follow_model = M("PostsFollow");
		$care_model = M("CareFriends");
		$goods_field = 'goods_id,goods_type,goods_name,goods_remark,goods_img,shop_price,good_desc,store_count';
		$comments_field ='id,post_id,uid,full_name,url,content,createtime';
		$likes_field ='user,user_login,user_nicename,avatar';
		$like_join = '__USERS__ as users on users.id = posts_follow.id';
		if($posts){
        	foreach ($posts as $key => $value) {
				if(!empty($value['smeta'])){
					if(empty($value['photos_urls'])){
					$posts[$key]['photos_urls']=array();
					}else{
					$posts[$key]['photos_urls']=json_decode($value['photos_urls'], true);
					}
					$posts[$key]['smeta']=json_decode($value['smeta'], true);
					$posts[$key]['thumb'] = $posts[$key]['smeta']['thumb'];
					unset($posts[$key]['smeta']);
				}
				if(!empty($value['post_goods'])){
					$goods_where['goods_id'] = array('in',$value['post_goods']);
					$goods_array=$goods_model->field($goods_field)->where($goods_where)->select();
					$posts[$key]['goods_array']=$goods_array;
				}
				if(!empty($value['comment_count'])){
					$comments_where['post_id'] = array('eq',$value['object_id']);
					$comment_array=$comments_model->field($comments_field)->where($comments_where)->select();
					$posts[$key]['comment_array']=$comment_array;
				}
				if(!empty($value['post_like'])){
					$like_where['postid'] = array('eq',$value['object_id']);
					$like_where['is_care'] = array('eq',1);
					$like_array=$follow_model->alias("posts_follow")->join($like_join)
					->field($likes_field)->where($like_where)->select();
					$posts[$key]['like_array']=$like_array;
				}
				if(!empty($userid)){
			$care_result=$care_model->where(array('uid'=>$userid,'fuid' =>$value['post_author'],'is_care' => 1))->find();
			$follow_result=$follow_model->where(array('user'=>$userid,'postid'=>$value['object_id'],'is_care'=> 1))->find();
			$posts[$key]['author_follow']=$care_result?true:false;
			$posts[$key]['post_follow']=$follow_result?true:false;		
				}
			}
			$this->successJson("获取关联商品的文章成功!",$posts);
		}else{
			$this->errorJson("暂无此商品关联文章!");
		}	
			
		
		
	}
	
	// 获取分类商品
	public function cate_goods_json(){
		$cat_id= I("cat_id",0,'intval');
		$goods_model= M("Goods");
		$goods_field = 'goods_id,goods_name,goods_remark,goods_img,shop_price,good_desc,store_count';
		$goods_array=$goods_model->field($goods_field)->where(array("cat_id"=>$cat_id))->limit('0,20')->select();
		$this->successJson("获取分类商品成功！", $goods_array);
	}
	
	// 获取品牌商品
	public function type_goods_json(){
		$goods_type= I("goods_type",0,'intval');
		$goods_model= M("Goods");
		$goods_field = 'goods_id,goods_name,goods_remark,goods_img,shop_price,good_desc,store_count';
		$goods_array=$goods_model->field($goods_field)->where(array("goods_type"=>$goods_type))->limit('0,20')->select();
		$this->successJson("获取品牌商品成功！", $goods_array);
	}
	
	// 用于后台导航编辑添加
	public function nav_index_json(){
		$parentid= I("get.parent",0,'intval');
        $category_obj= M("GoodsCategory");
		$where=array();
        $where['parent_id'] = array('eq',$parentid);
        $result = $category_obj->field('id,name')->where($where)->order(array("listorder"=>"asc"))->select();
		foreach ($result as $key=>$item){
		$item_where['parent_id'] = array('eq',$item['id']);
		$children = $category_obj->field('id,name')->where($item_where)->order(array("listorder"=>"asc"))->select();
		$result[$key]['children']=$children;
		}
		$this->successJson("获取商品分类列表成功！", $result);
	}
	
	// 获取分类下的品牌
	public function navTypeList(){
        $category_m= M("GoodsCategory");
        $where['level'] = array('eq',1);
		$where['is_show'] = array('eq',1);
        $category_list = $category_m->field('id as cid,name,rel_types')->where($where)->order(array("cate_hot"=>"desc"))->select();
		foreach ($category_list as $key=>$item){
			if(!empty($item['rel_types'])){
				$where_type['id'] = array('in',$item['rel_types']);
				$cate_types = M("GoodsType")->field('id as tid,name,type_img')->where($where_type)->select();
				$category_list[$key]['cate_types']=$cate_types;
			}
			unset($category_list[$key]['rel_types']);	
		}
		$cate_types = M("GoodsType")->field('id as tid,name,type_img')->where(array("is_recommend"=>1))->select();
		$category_item=array(
		"cid"=>"0",
		"name"=>'推荐',
		"cate_types"=>$cate_types,
		);
		array_unshift($category_list,$category_item);
		$this->successJson("获取分类下的品牌列表成功！", $category_list);
	}
	
	// 获取品牌下的商品
	public function typeGoodsList(){
		$type_id= I("type_id",0,'intval');
		$where['goods_type'] = array('eq',$type_id);
        $where['is_on_sale'] = array('eq',1);
		$where['is_delete'] = array('eq',0);
		$goods_field = 'goods_id,cat_id,goods_name,goods_remark,goods_img,goods_type,photo,shop_price,good_desc,store_count';
		$order['is_recommend'] =  "DESC";
		$order['is_new'] =  "DESC";
		$order['is_hot'] =  "DESC";
        $goods_list = M("Goods")->field($goods_field)->where($where)->order($order)->select();
		$this->successJson("获取品牌下的商品列表成功！", $goods_list);
	}
}
