<?php

namespace Goods\Controller;
use Common\Controller\HomebaseController;

class SearchController extends HomebaseController {

	// 搜索商品
	public function index() {
	    $keyword = I('request.keyword/s','');		
		if (empty($keyword)) {
			$this -> error("关键词不能为空！请重新输入！");
		}
		$where=array("is_on_sale"=>1,"is_delete"=>"neq 3","goods_name"=>array('like',"%$keyword%"));
		$count = M('Goods')->where($where)->count();
		$page = $this->page($count, 12);
		$list = M('Goods')
		->where($where)
		->limit($page->firstRow , $page->listRows)
		->select();
		
		$this->assign('list', $list);
		$this->assign('keyword', $keyword);
		$this->assign('page', $page->show('Home'));
    	$this->display(":search");
	}
	
	// 搜索商品Api
	public function indexJson() {
		$where['is_delete'] = array('neq',3);
		$goods_field = 'goods_id,goods_name,goods_remark,goods_img,shop_price,good_desc,store_count';
		$keyword=trim(I('keyword'));
		if (empty($keyword)) {
			$this -> errorJson("关键词不能为空！请重新输入！");
		}else{
			$where['goods_name']=array('like',"%$keyword%");	
		}
		$goodslist=M('Goods')->field($goods_field)->where($where)->limit('0,20')->order('last_update DESC')->select();
		if(empty($goodslist)){
			$this->errorJson("获取关联商品失败!");
		}else{
			$this->successJson("获取关联商品成功!",$goodslist);
		}
	}
			
}
