<?php


// +----------------------------------------------------------------------
// | ThinkCMF [ WE CAN DO IT MORE SIMPLE ]
// +----------------------------------------------------------------------
// | Copyright (c) 2013-2014 http://www.thinkcmf.com All rights reserved.
// +----------------------------------------------------------------------
// | Author: Dean <zxxjjforever@163.com>
// +----------------------------------------------------------------------
namespace Goods\Controller;
Vendor('html-parser.ParserDom');
use HtmlParser\ParserDom;
use Common\Controller\HomebaseController;
header("Content-type:text/html;charset=utf-8");


class CrawlingController extends HomebaseController {

	function _initialize() {
		parent::_initialize();
	}
	
	// 前台文章列表
	public function test() {
	$keyword=urlencode('写真');
		$url = 'https://www.xiaohongshu.com/mobile/tags/2305844656214359547?name='.$keyword;
		$curl = curl_init();
		$header = array("Connection: Keep-Alive","Accept: text/html, application/xhtml+xml, */*", "Pragma: no-cache", "Accept-Language: zh-Hans-CN,zh-Hans;q=0.8,en-US;q=0.5,en;q=0.3","User-Agent: Mozilla/5.0 (compatible; MSIE 10.0; Windows NT 6.2; WOW64; Trident/6.0)");
  		curl_setopt($curl, CURLOPT_URL, $url);
  		curl_setopt($curl, CURLOPT_HEADER, 1);
  		curl_setopt($curl, CURLOPT_HTTPHEADER, $header);
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
		curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);//这个是重点。s
		curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, FALSE);
		$data = curl_exec($curl);
		curl_close($curl);
		import("phpQuery");
		\phpQuery::newDocumentHTML($data);
		$pq=pq();
		$imgs=$pq->find("img");
		$note_src;
		if($imgs->length()){
			foreach ($imgs as $img){
				$img=pq($img);
				$note_src=$img->attr("src");
				break;
			}
		}
		
		\phpQuery::$documents=null;
		
		$this->successJson("获取文章列表成功！", $noteList);
	}
	
	// 前台文章列表
	public function index() {
		$url =$_SERVER['DOCUMENT_ROOT'] . '/test.html';
		$sHtml = file_get_contents($url);
		//echo $url;exit;
		$oDom = new ParserDom($sHtml);
		$noteList=array();
		$note_array = $oDom->find('div.note-info');
		//echo json_encode($note_array);exit;
		foreach ($note_array as $note){
			$innerHtml=$note->innerHtml();
			$note_data=sp_getcaesar_data($innerHtml);
			array_push($noteList,$note_data);
		}
		$this->successJson("获取文章列表成功！", $noteList);
	}
	
	public function caesar_article()
    {
		$keyword=urlencode('篮球鞋');
		$url = 'https://www.xiaohongshu.com/mobile/tags/2305845148440532639?name='.$keyword;
		$curl = curl_init();
		$header = array("Connection: Keep-Alive","Accept: text/html, application/xhtml+xml, */*", "Pragma: no-cache", "Accept-Language: zh-Hans-CN,zh-Hans;q=0.8,en-US;q=0.5,en;q=0.3","User-Agent: Mozilla/5.0 (compatible; MSIE 10.0; Windows NT 6.2; WOW64; Trident/6.0)");
  		curl_setopt($curl, CURLOPT_URL, $url);
  		curl_setopt($curl, CURLOPT_HEADER, 1);
  		curl_setopt($curl, CURLOPT_HTTPHEADER, $header);
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
		curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);//这个是重点。s
		curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, FALSE);
		$data = curl_exec($curl);
		curl_close($curl);
		//echo $data;exit;
		$html_dom = new ParserDom($data);
		$noteList=array();
		$posts_model=M('Posts');
		$users_model=M('Users');
		$term_relationships_model=M('TermRelationships');
		$note_array = $html_dom->find('div.note-info');
		//echo json_encode($note_array);exit;
		foreach ($note_array as $note){
			$_POST['term']=mt_rand(12,22);
			$_POST['userID']= mt_rand(1,1200);
			//echo $note->innerHtml();exit;
			$innerHtml=$note->innerHtml();
			$note_data=sp_getcaesar_data($innerHtml);
			$_POST['post']['post_title']=$note_data['note_text'];
			$_POST['post']['post_excerpt']=$note_data['note_text'];
			$_POST['post']['post_keywords']=$note_data['note_text'];
			$_POST['post']['post_source']="https://www.xiaohongshu.com".$note_data['note_href'];
			$_POST['smeta']['photo']=array("url"=>$note_data['note_src'],"alt"=>"");
            $_POST['smeta']['thumb'] = $note_data['note_src'];
			$_POST['post']['post_type']==1;
            $_POST['post']['post_date']=date("Y-m-d H:i:s",time());
            $_POST['post']['post_modified']=date("Y-m-d H:i:s",time());
            $_POST['post']['post_author']=$_POST['userID'];
			$users=$users_model->where(array("id"=>$_POST['userID']))->find();
			if(empty($_POST['post']['post_authorname'])){
            	$_POST['post']['post_authorname']=$users['user_nicename'];
            }
			$rand=mt_rand(2,5);
			$post_goods=array();
			for ($i=0; $i<=$rand; $i++) {
				$good_rand=mt_rand(100,999);
				array_push($post_goods,$good_rand);
			}
			$goods_string=implode(",", $post_goods);
			$_POST['post']['goods_id']=$post_goods[0];
			$_POST['post']['post_goods']=$goods_string;
			$note_data['post_goods']=$goods_string;
			$_POST['post']['post_avatar']=$users['avatar'];
			$_POST['post']['post_status']=1;
			$article=I("post.post");
            $article['smeta']=json_encode($_POST['smeta']);
			$article['photos_urls']=json_encode(array($note_data['note_src']));
			if ($posts_model->create($article)!==false) {
			$result=$posts_model->add();
			if ($result) {
            	$term_relationships_model->add(array("term_id"=>intval($_POST['term']),"object_id"=>$result,"status"=>1));
				$note_data['status']="success";
			}else{
				$note_data['status']="failed";
			}}else{
				 $note_data['status']=$this->error($posts_model->getError());
			}
			array_push($noteList,$note_data);
		}
		$this->successJson("获取文章列表成功！", $noteList);
	}
	
	public function caesar_test()
    {	
		$cat_id= I("cat_id");
		$keyword= I("keyword");
		$goods_type= I("goods_type");
		$owner= I("owner",'g');
		if(empty($cat_id)){
			$this->errorJson("缺少分类！");
		}
		if(empty($keyword)){
			$this->errorJson("缺少关键字！");
		}else{
			if (preg_match("/[\x7f-\xff]/", $keyword)) {
			$keyword=urlencode($keyword);
			}
		}
		if(empty($goods_type)){
			$this->errorJson("缺少品牌！");
		}
		$pageIndex= I("pageIndex",1,'intval');
		$url = 'http://api.web.21ds.cn/jingdong/getJdUnionItems?apkey=bff5aeb4-a16a-b3d7-98a5-4336097525f8&cid3=9756&keyword='.$keyword.'&owner='.$owner.'&pageIndex='.$pageIndex;
		$curl = curl_init();
		curl_setopt($curl, CURLOPT_URL, $url);
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
		$data = curl_exec($curl);
		curl_close($curl);
		$jsonData=json_decode($data, true);
		$listData=$jsonData['data']['list'];
		$totalCount=$jsonData['data']['totalCount'];
		$caesarList=array();
		$goods_model=M("Goods");
		foreach($listData as $goodsdata){
			$skuName=$goodsdata['skuName'];
			$brandName=$goodsdata['brandName'];
			$priceInfo=$goodsdata['priceInfo'];
			$price=$priceInfo['price'];
			$imageInfo=$goodsdata['imageInfo'];
			$imageList=$imageInfo['imageList'];
			$inOrderCount30Days=$goodsdata['inOrderCount30Days'];
			$photos=array();
			foreach($imageList as $imagelink){
				$imageurl=$imagelink['url'];
				array_push($photos,$imageurl);
			}
			$data=array(
			'goods_name' => $skuName,
	        'goods_remark' => $skuName,
	        'goods_img' => $photos[0],
	        'shop_price' =>$price,
			'market_price' =>$price,
			'keywords' =>$brandName,
			'store_count' =>$inOrderCount30Days,
			'is_on_sale' =>1,
			'goods_type' =>$goods_type,
			'cat_id' =>$cat_id,
			'weight' =>100,
			'give_integral' =>$price,
			'photo' =>json_encode($imageList)
	    	);
			$goods_model->add($data);
			array_push($caesarList,$data);
		}
		if(count($caesarList)<20||$pageIndex>8){
			$caesarList['url']=$url;
			$this->successJson("添加商品成功！", $caesarList);
		}else{
			if (preg_match("/[\x7f-\xff]/", $keyword)) {
			$keyword=urldecode($keyword);
			}
			$this->success('添加商品成功',U('Goods/Crawling/caesar_test',array('cat_id'=>$cat_id,'keyword'=>$keyword,'goods_type'=>$goods_type,'owner'=>$owner,'pageIndex'=>($pageIndex+1))));
		}
	}

}
