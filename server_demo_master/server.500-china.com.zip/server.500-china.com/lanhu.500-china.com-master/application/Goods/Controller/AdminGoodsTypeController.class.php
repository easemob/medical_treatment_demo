<?php

namespace Goods\Controller;

use Common\Controller\AdminbaseController;

class AdminGoodsTypeController extends AdminbaseController {
	
	protected $type_model;
		
	function _initialize() {
		parent::_initialize();
		$this->type_model = D("Goods/GoodsType");
		
	}
	
	// 后台供求分类列表
    public function index(){
		$type_list = $this->type_model->select();
		
		$this->assign('type_list',$type_list);
		$this->display();
	}
	
	public function add(){
		$this->display();
	}
	
	public function add_post(){
		if (IS_POST) {
			
			if($this->type_model->create() !== false){				
				$result=$this->type_model->add();															
				if ($result) {
					$this->success("添加成功！");
				} else {
					$this->error("添加失败！");
				}
			}else{
				$this->error($this->type_model->getError());
			}						
		}
	}
	
	public function edit(){
		$id = I("get.id");
		$data=$this->type_model->where(array("id" => $id))->find();
		$this->assign("data",$data);
		$this->display();
	}
	
	public function edit_post(){
		if (IS_POST) {
			
			if($this->type_model->create() !== false){				
				$result=$this->type_model->save();															
				if ($result) {
					$this->success("保存成功！");
				} else {
					$this->error("保存失败！");
				}
			}else{
				$this->error($this->type_model->getError());
			}						
		}
	}
	
	public function delete(){
		$id = I("get.id");
		$result=$this->type_model->where(array("id" => $id))->delete();
		$result2=M('Spec')->where(array("type_id" => $id))->delete();
		
		if($result !== false){
			$this->success("删除成功！");
		}else{
			$this->error("删除失败！");
		}		
	}
	
}