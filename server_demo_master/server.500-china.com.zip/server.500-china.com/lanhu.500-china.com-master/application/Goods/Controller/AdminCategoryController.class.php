<?php

namespace Goods\Controller;

use Common\Controller\AdminbaseController;

class AdminCategoryController extends AdminbaseController {
	
	protected $category_model;
		
	function _initialize() {
		parent::_initialize();
		$this->category_model = D("Goods/GoodsCategory");
		$this->assign("taxonomys",$this->taxonomys);
	}
	
	// 后台商品分类列表
    public function index(){
		$result = $this->category_model->order(array("listorder"=>"asc"))->select();
		
		$tree = new \Tree();
		$tree->icon = array('&nbsp;&nbsp;&nbsp;│ ', '&nbsp;&nbsp;&nbsp;├─ ', '&nbsp;&nbsp;&nbsp;└─ ');
		$tree->nbsp = '&nbsp;&nbsp;&nbsp;';
		foreach ($result as $r) {
			$r['str_manage'] = '<a href="' . U("AdminCategory/add", array("parent" => $r['id'])) . '">'.L('ADD_SUB_CATEGORY').'</a> | <a href="' . U("AdminCategory/edit", array("id" => $r['id'])) . '">'.L('EDIT').'</a> | <a class="js-ajax-delete" href="' . U("AdminCategory/delete", array("id" => $r['id'])) . '">'.L('DELETE').'</a> ';
			$url=U('Goods/list/index',array('id'=>$r['id']));//前台修改
			$r['url'] = $url;
			$r['taxonomys'] = $this->taxonomys[$r['taxonomy']];
			$r['id']=$r['id'];
			$r['parentid']=$r['parent_id'];
			$r['is_show'] = $r['is_show']==1 ? 'fa-check' : 'fa-close';
			$r['is_hot'] = $r['is_hot']==1 ? 'fa-check' : 'fa-close';
			$array[] = $r;
		}
		
		
		$tree->init($array);
		
		$str = "<tr>
					<td><input name='listorders[\$id]' type='text' size='3' value='\$listorder' class='input input-order' onchange=updateSort('goods_category','id','\$id','listorder',this)></td>
					<td>\$id</td>
					<td>\$spacer <a href='\$url' target='_blank'>\$name</a></td>
	    			<td style='text-align:center;'><i class='fa \$is_hot'' onclick=changeTableVal('goods_category','id','\$id','is_hot',this) ></i></td>
	    			<td style='text-align:center;'><i class='fa \$is_show'' onclick=changeTableVal('goods_category','id','\$id','is_show',this) ></i></td>
					<td>\$str_manage</td>
				</tr>";
		$taxonomys = $tree->get_tree(0, $str);
		$this->assign("taxonomys", $taxonomys);
		$this->display();
	}
	
	// 商品分类添加
	public function add(){
	 	$parentid = I("get.parent",0,'intval');
	 	$tree = new \Tree();
	 	$tree->icon = array('&nbsp;&nbsp;&nbsp;│ ', '&nbsp;&nbsp;&nbsp;├─ ', '&nbsp;&nbsp;&nbsp;└─ ');
	 	$tree->nbsp = '&nbsp;&nbsp;&nbsp;';
	 	$category = $this->category_model->order(array("parent_id_path"=>"asc"))->select();
	 	
	 	$new_category=array();
	 	foreach ($category as $r) {
	 		$r['id']=$r['id'];
	 		$r['parentid']=$r['parent_id'];
	 		$r['selected']= (!empty($parentid) && $r['id']==$parentid)? "selected":"";
	 		$new_category[] = $r;
	 	}
	 	$tree->init($new_category);
	 	$tree_tpl="<option value='\$id' \$selected>\$spacer\$name</option>";
	 	$tree=$tree->get_tree(0,$tree_tpl);
	 	$goods_types=M("GoodsType")->select();
		$this->assign("goods_types",$goods_types);
	 	$this->assign("category_tree",$tree);
	 	$this->assign("parent",$parentid);
	 	$this->display();
	}
	
	// 商品分类添加提交
	public function add_post(){
		if (IS_POST) {
			if(!empty($_POST['type_id'])){
				$type_ids=$_POST['type_id'];
				$_POST['rel_types']	=implode(",",$type_ids);
			}
			if(empty($_POST['parent_id'])){
				$_POST['level']=0;
			}else{
				$parent_level=M("GoodsCategory")->where(array("id"=>$_POST['parent_id']))->getField('level');
				$_POST['level']=$parent_level+1;
			}
			if ($this->category_model->create()!==false) {
				if ($this->category_model->add()!==false) {
				    
					$this->success("添加成功！",U("AdminCategory/index"));
				} else {
					$this->error("添加失败！");
				}
			} else {
				$this->error($this->category_model->getError());
			}
		}
	}
	
	// 商品分类编辑
	public function edit(){
		$id = I("get.id",0,'intval');
		$data=$this->category_model->where(array("id" => $id))->find();
		$tree = new \Tree();
		$tree->icon = array('&nbsp;&nbsp;&nbsp;│ ', '&nbsp;&nbsp;&nbsp;├─ ', '&nbsp;&nbsp;&nbsp;└─ ');
		$tree->nbsp = '&nbsp;&nbsp;&nbsp;';
		$terms = $this->category_model->where(array("id" => array("NEQ",$id), "parent_id_path"=>array("notlike","%-$id-%")))->order(array("parent_id_path"=>"asc"))->select();
		
		$new_category=array();
		foreach ($terms as $r) {
			$r['id']=$r['id'];
			$r['parentid']=$r['parent_id'];
			$r['selected']=$data['parent_id']==$r['id']?"selected":"";
			$new_category[] = $r;
		}
		
		$tree->init($new_category);
		$tree_tpl="<option value='\$id' \$selected>\$spacer\$name</option>";
		$tree=$tree->get_tree(0,$tree_tpl);
		$type_ids=explode(',', $data['rel_types']);
		$where_type['id'] = array('in',$type_ids);
		$rel_types=M("GoodsType")->where($where_type)->getField("id",true);
		$goods_types=M("GoodsType")->select();
		$this->assign("rel_types",$rel_types);
		$this->assign("goods_types",$goods_types);
		$this->assign("category_tree",$tree);
		$this->assign("data",$data);
		$this->display();
	}
	
	// 商品分类编辑提交
	public function edit_post(){
		if (IS_POST) {
			if(!empty($_POST['type_id'])){
				$type_ids=$_POST['type_id'];
				$_POST['rel_types']	=implode(",",$type_ids);
			}
			if ($this->category_model->create()!==false) {
				if ($this->category_model->save()!==false) {
				  
					$this->success("修改成功！");
				} else {
					$this->error("修改失败！");
				}
			} else {
				$this->error($this->category_model->getError());
			}
		}
	}
	
	// 商品分类排序
	public function listorders() {
		$status = parent::_listorders($this->category_model);
		if ($status) {
			$this->success("排序更新成功！");
		} else {
			$this->error("排序更新失败！");
		}
	}
	
	// 删除商品分类
	public function delete() {
		$id = I("get.id",0,'intval');
		$count = $this->category_model->where(array("parent_id" => $id))->count();
		
		if ($count > 0) {
			$this->error("该菜单下还有子类，无法删除！");
		}
		
		if ($this->category_model->delete($id)!==false) {
			$this->success("删除成功！");
		} else {
			$this->error("删除失败！");
		}
	}
	
	/**
     * ajax 修改指定表数据字段  一般修改状态 比如 是否推荐 是否开启 等 图标切换的
     * table,id_name,id_value,field,value
     */
    public function changeTableVal(){  	
            $table = I('table'); // 表名
            $id_name = I('id_name'); // 表主键id名
            $id_value = I('id_value'); // 表主键id值
            $field  = I('field'); // 修改哪个字段
            $value  = I('value'); // 修改字段值                        
            M($table)->where("$id_name = $id_value")->save(array($field=>$value)); // 根据条件保存修改的数据
    }
	
}