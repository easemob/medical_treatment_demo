<?php

namespace Goods\Controller;
use Common\Controller\HomebaseController;

class ArticleController extends HomebaseController {
	
	function _initialize() {
		parent::_initialize();
		
	}
	
	// 获取商品详情
	public function getGoodsForID() {
		$userid=I('userid',0,'intval');
		$goods_id=I('goods_id',30,'intval');
		$timestamp=time();
		$datetime=date("Y-m-d H:i:s",time());
		$goods = M('Goods')->where(array("goods_id"=>$goods_id))->find();
		if($goods){
			if(!empty($goods['photo'])){
				$photos=json_decode($goods['photo'], true);
				$good_photos=array();
				foreach($photos as $photo){
            		array_push($good_photos,$photo['url']);
            	}
				unset($goods['goods_content']);
				$goods['goods_photos']=$good_photos;
			}
			if(!empty($userid)){
			$gbs_model= M("GoodsBrowse");
			$result=$gbs_model->where(array('userid' => $userid,'goods_id' => $goods_id))->find();
			if($result){
			$gbs_model->where(array('bid' => $result['bid']))->save(array("browse_time"=>$timestamp,"browse_count"=>array("exp","browse_count+1"),"browse_date"=>$datetime));
		}else{
			$data=array(
	        'userid' => $userid,
	        'goods_id' => $goods_id,
	        'browse_time' => $timestamp,
			'browse_date' => $datetime
	    	);
			$gbs_model->add($data);
		}
			}
			$this->successJson("获取商品详情成功！", $goods);
		}else{
			$this->errorJson("获取商品详情失败！");
		}
	}
	
	// 前台商品列表
	public function index() {
	    //$id=I('get.id',0,'intval');//分类id,不用get
	    $goods_id=I('get.g_id',0,'intval');
		
		$goods = M('Goods')->where(array("goods_id"=>$goods_id))->find();
		$id = $goods['cat_id'];
		$photo = json_decode($goods['photo'],true);
		
		if(empty($goods)){
		    header('HTTP/1.1 404 Not Found');
		    header('Status:404 Not Found');
		    if(sp_template_file_exists(MODULE_NAME."/404")){
		        $this->display(":404");
		    }
		    return;
		}
		if($goods['is_on_sale'] == 0){
			$this->error('该商品已经下架',U('Index/index'));
		}
		
		$GoodsLogic = new \Goods\Logic\GoodsLogic();
		$sku = $GoodsLogic->getSpecList($goods_id);//获取规格
		//print_r($sku);die;		
		
		M('Goods')->where("goods_id=$goods_id")->save(array('click_count'=>$goods['click_count']+1 )); //统计点击数
		
		$crumbs = sp_get_breadcrumb($id,1);//面包屑
		
		$sku_goods_price  = M('GoodsSku')->where("goods_id = $goods_id")->getField("item_path,price,store_count"); // 规格 对应 价格 库存表
		//print_r(json_encode($sku_goods_price));die;
		//侧边栏产品
		$side_goods = M('Goods')->order("rand()")->limit(5)->select();
		
		$all_count = M('GoodsComment')->where(array("goods_id"=>$goods_id))->count(); //获取全部评论数量
		$pic_count = M('GoodsComment')->where(array("goods_id"=>$goods_id,"img"=>array('neq','')))->count();//获取图片评论数量
		
										    	
		$this->assign('crumbs', $crumbs);
		$this->assign('goods', $goods);
		$this->assign('photo', $photo);
		$this->assign('first_photo', $photo[0]);
		$this->assign('sku', $sku);
		$this->assign('sku_goods_price', json_encode($sku_goods_price));
		$this->assign('side_goods',$side_goods);
		$this->assign('all_count',$all_count);
		$this->assign('pic_count',$pic_count);
    	
		$tplname=$term["one_tpl"];
    	$tplname=empty($smeta['template'])?$tplname:$smeta['template'];
    	$tplname=sp_get_apphome_tpl($tplname, "article");
    	$this->display(":$tplname");
	}
	
	
	// 用于后台导航编辑添加
	public function nav_index(){
		$navcatname="商品分类";
        $category_obj= M("Goods_category");

        $where=array();
        $where['is_show'] = array('eq',1);
        $categorys=$category_obj->field('id,name,parent_id')->where($where)->order('id')->select();
		$datas=$categorys;
		$navrule = array(
		    "id"=>'id',
            "action" => "Goods/List/index",
            "param" => array(
                "id" => "id"
            ),
            "label" => "name",
		    "parentid"=>'parent_id'
        );
		return sp_get_nav4admin($navcatname,$datas,$navrule) ;
	}
	
	//ajax获取评论列表
	public function commentList(){
		$goods_id = I('goods_id',0);
		$type = I('commentType',0);
		$where['goods_id'] = $goods_id;
		
		if($type == 1){
			$where['img'] = array('neq',''); //是否有图片
		}
		$count = M('GoodsComment')->where($where)->count();
		$page = $this->ajaxpage($count,10);
		
		$comment_list = M('GoodsComment')->where($where)->limit($page->firstRow , $page->listRows)->select();
		

		$this->assign('comment_list',$comment_list);
		$this->assign('page',$page->show('Home'));
		$this->assign('type',$type);		
		$this->display(":commentList"); 
	}
}
