<?php

namespace Goods\Controller;

use Common\Controller\AdminbaseController;

class AdminOrderController extends AdminbaseController {
	
	public  $order_status;
    public  $pay_status;
    public  $shipping_status;
	
	function _initialize() {
		parent::_initialize();
		$this->order_model = M("GoodsOrder");
		$this->GoodsOrderLogic = new \Goods\Logic\GoodsOrderLogic();
		
		$this->order_status = C('ORDER_STATUS');
        $this->pay_status = C('PAY_STATUS');
        $this->shipping_status = C('SHIPPING_STATUS');
        // 订单 支付 发货状态
        $this->assign('order_status',$this->order_status);
        $this->assign('pay_status',$this->pay_status);
        $this->assign('shipping_status',$this->shipping_status);
	}
	
	// 订单列表
    public function index(){
						
		$this->display();
	}
	
	//ajax获取订单列表
	public function ajaxorderlist(){
		$where['is_del'] = 0;
		$keyword_sn=trim(I('keyword_sn'));
		$keyword_name=trim(I('keyword_name'));
        if($keyword_sn)
        {
			 $where['order_sn']=array('like',"%$keyword_sn%");	//搜索订单编号		 	 
        }
		if($keyword_name)
        {
			 $where['consignee']=array('like',"%$keyword_name%");	//搜索收货人		 	 
        }
		$order_status = I('order_status');		
		if($order_status !== ''){
			$where['order_status'] = $order_status;
		}
		$pay_status = I('pay_status');
		if($pay_status !== ''){
			$where['pay_status'] = $pay_status;
		}
		$shipping_status = I('shipping_status');
		if($shipping_status !== ''){
			$where['shipping_status'] = $shipping_status;
		}
		
		$order_str = "{$_POST['orderby1']} {$_POST['orderby2']}";
		$count = $this->order_model->where($where)->count();		
		$page = $this->ajaxpage($count,10);//ajax分页
		
		$order_list = $this->order_model->where($where)->limit($page->firstRow , $page->listRows)->order($order_str)->select();
		
		$this->assign('order_list',$order_list);
		$this->assign('page',$page->show('Admin'));
		$this->display();
	}
	
	//订单详细
	public function detail($order_id){
		$order = $this->GoodsOrderLogic->orderInfo($order_id); //获取订单详细 goods_order
		$goods_order = $this->GoodsOrderLogic->getGoodsOrder($order_id); //获取订单供求信息 order_sub
		$order_btn = $this->GoodsOrderLogic->getOrderBtn($order); //获取按钮
		$action_log = M('GoodsOrderLog')->where(array('order_id'=>$order_id))->order('log_time desc')->select();
		//print_r($goods_order);die;
		//暂无运费
		//print_r(get_current_admin_id());die;
		
		
		$this->assign('order',$order);
		$this->assign('goods_order',$goods_order);
		$this->assign('order_btn',$order_btn);
		$this->assign('action_log',$action_log);
		$this->display();
	}
	
	//修改发货地址
	public function editaddress($order_id){
		$address_mobel = M('address');
		$order = $this->GoodsOrderLogic->orderInfo($order_id);
		$this->editable($order);
		
		//编辑收货人信息
		if(IS_POST){
			$model = D('GoodsOrder');
			if($model->create() !== false){
				$result = $model->save();
				if($result !== false){
					$this->success('保存成功',U('AdminOrder/detail',array("order_id"=>$order_id)));
				}else{
					$this->error('保存失败');
				}
			}else{
				$this->error($model->getError());
			}			
		}		
		
		//获取地址
		$province = $address_mobel->where(array('level'=> 1))->select();
		$city = $address_mobel->where(array('parent_id'=>$order['province'],'level'=> 2))->select();
		$district = $address_mobel->where(array('parent_id'=>$order['city']))->select();
		
		if($order['twon']){
        	$twon = M('address')->where(array('parent_id'=>$order['district'],'level'=>4))->select();
        	$this->assign('twon',$twon);
        }
		//print_r($province);die;
		
		$this->assign('order',$order);
		$this->assign('province',$province);
		$this->assign('city',$city);
		$this->assign('district',$district);
		$this->display();
	}
	
	//修改价格信息
	public function editprice($order_id){
		$order = $this->GoodsOrderLogic->orderInfo($order_id);
		$this->editable($order);
		
		if(IS_POST){
			$data = I('post.');			
			$result = M('GoodsOrder')->save($data);
			if($result !== false){
				$this->success('保存成功',U('AdminOrder/detail',array("order_id"=>$order_id)));
			}else{
				$this->error('保存失败');
			}
		}
		
		$this->assign('order',$order);
		$this->display();
	}
	
	//已发货不能编辑
	private function editable($order){
        if($order['shipping_status'] != 0){
            $this->error('已发货订单不允许编辑');
            exit;
        }
        return;
    }
	
	//执行操作按钮
	public function orderOperate($order_id){
		if(isset($_GET["type"])){
			$type = $_GET["type"];
			$note = trim(I('note'));
			switch($type){
				case 'confirm':
					$updata['order_status'] = 1;
					$note = empty($note) ? '您的订单已确认' : $note;
					break;
				case 'cancel':
					$updata['order_status'] = 0;
					$note = empty($note) ? '取消确认' : $note;
					break;
				case 'pay':
					$updata['pay_status'] = 1;
					$updata['pay_time'] = time();
					$note = empty($note) ? '付款' : $note;
					break;
				case 'nopay':
					if(empty($note)){
						$this->error('请填写操作备注');
					}
					$updata['pay_time'] = null;
					$updata['pay_status'] = 0;
					$note = empty($note) ? '取消付款' : $note;
					break;
				case 'invalid':
					if(empty($note)){
						$this->error('请填写操作备注');
					}
					$updata['order_status'] = 4;
					break;
				case 'receive':
					$updata['shipping_status'] = 2;
					$note = empty($note) ? '订单已签收' : $note;
					break;
				default:
					return true;
			}			
			$result = M('GoodsOrder')->where("order_id = {$order_id}")->save($updata);
			$log = $this->GoodsOrderLogic->orderLog($order_id,$type,$note);
			if($result && $log){
				$this->success('操作成功',U('AdminOrder/detail',array("order_id"=>$order_id)));
			}else{
				$this->error('操作失败');
			}
		}
	}
	
	//发货
	public function ship_info($order_id){
		$order = $this->GoodsOrderLogic->orderInfo($order_id); //获取订单详细 goods_order
		$goods_order = $this->GoodsOrderLogic->getGoodsOrder($order_id); //获取订单供求信息 order_sub
		$type = $_GET["type"];
		if(isset($type) && $type == 'confirm_ship'){
			$note = trim(I('note'));
			$shipping_name = I('shipping_name');
			$delivery_no = I('delivery_no');
			if(empty($shipping_name)){
				$this->error('请填写配送物流');
			}
			if(empty($delivery_no)){
				$this->error('请填写快递单号');
			}
			$note = empty($note) ? '您的订单正在配送' : $note;
			$data['shipping_status'] = 1;
			$data['shipping_name'] = $shipping_name;
			$data['delivery_no'] = $delivery_no;
			$data['shipping_time'] = time();
			//确定发货			
			$result = M('GoodsOrder')->where("order_id = {$order_id}")->save($data);
			$result2 = M('GoodsOrderSub')->where("order_id = {$order_id}")->save(array("is_send"=>1));
			$log = $this->GoodsOrderLogic->orderLog($order_id,$type,$note);
			if($log && $result && $result2){
				$this->success('操作成功',U('AdminOrder/detail',array("order_id"=>$order_id)));
			}else{
				$this->error('操作失败');
			}
		}
		
		$this->assign('order',$order);
		$this->assign('goods_order',$goods_order);
		$this->display();
	}
	
	//发货单列表
	public function ship_list(){
		
		$this->display();
	}
	
	//ajax获取发货单列表
	public function ajax_ship_list(){
		$where['is_del'] = 0;
		$where['shipping_status'] = array('neq',0);
		
		$keyword_sn=trim(I('keyword_sn'));
		$keyword_name=trim(I('keyword_name'));
        if($keyword_sn)
        {
			 $where['order_sn']=array('like',"%$keyword_sn%");	//搜索订单编号		 	 
        }
		if($keyword_name)
        {
			 $where['consignee']=array('like',"%$keyword_name%");	//搜索收货人		 	 
        }
		
		
		$order_str = "{$_POST['orderby1']} {$_POST['orderby2']}";
		$count = $this->order_model->where($where)->count();		
		$page = $this->ajaxpage($count,10);//ajax分页
		
		$order_list = $this->order_model->where($where)->limit($page->firstRow , $page->listRows)->order($order_str)->select();
		
		$this->assign('order_list',$order_list);
		$this->assign('page',$page->show('Admin'));
		$this->display();
	}
	
	//查看发货单
	public function ship_detail($order_id){
		$order = $this->GoodsOrderLogic->orderInfo($order_id); //获取订单详细 goods_order
		$goods_order = $this->GoodsOrderLogic->getGoodsOrder($order_id); //获取订单供求信息 order_sub
		$action_log = M('GoodsOrderLog')->where(array('order_id'=>$order_id))->order('log_time desc')->select();
		$order_btn = $this->GoodsOrderLogic->getOrderBtn($order); //获取按钮
		
		$this->assign('order',$order);
		$this->assign('goods_order',$goods_order);
		$this->assign('action_log',$action_log);
		$this->assign('order_btn',$order_btn);
		$this->display();
	}
	
	//删除订单 is_del=3
	public function delete(){
		$id = $_GET['id'];
		$order = $this->order_model->where(array("order_id" => $id))->find();
		if($order['order_status'] !== 4){
			$this->error('该订单正常，不能删除');
		}
		$result = $this->order_model->where("order_id = $id")->save(array('is_del'=>3));
		if($result){
			$this->success('删除成功');
		}else{
			$this->error('删除失败');
		}
	}
	
	//批量删除选中订单 is_del=3
	public function delete_all(){
		if(isset($_POST['ids'])){
			$ids = I('post.ids/a');
			
			if ($this->order_model->where(array('order_id'=>array('in',$ids),'order_status'=>4))->save(array('is_del'=>3))) {
				$this->success("删除成功！");
			} else {
				$this->error("删除失败！");
			}
		}
	}
	
}