<?php

namespace Goods\Controller;
use Common\Controller\HomebaseController; 
/**
 * 首页
 */
class IndexController extends HomebaseController {
	
    //首页 
	public function index() {
    	$this->display(":index");
    }
	
	//新增用户商品心愿单(新增商品足迹和心愿单)
    public function save_personal_collection() {
		$userid=I('userid',1);
		$goods_id=I('goods_id',1);
		$gcs_model= M("GoodsCollection");
		$result=$gcs_model->where(array('userid' => $userid,'goods_id' => $goods_id))->find();
		if($result){
			$this->errorJson("您已经收藏该商品！");
		}else{
			$data=array(
	        'userid' => $userid,
	        'goods_id' => $goods_id,
	        'collection_time' => time()
	    	);
			$gcs_model->add($data);
			$this->successJson("收藏成功！");
		}
	}
	
	//获取某一用户的心愿记录
    public function personal_collection_list() {
		$userid=I('userid',1);
		$gcs_model= M("GoodsCollection");
		$field = 'g.goods_id,g.goods_name,g.goods_remark,g.goods_img,g.shop_price,g.good_desc,g.store_count';
		$join = '__GOODS__ as g on g.goods_id = c.goods_id';
		$order = "c.collection_time DESC";
		$collection_list=$gcs_model->alias("c")->join($join)->field($field)
		->where(array('userid' => $userid))->order($order)->select();
		if($collection_list){
			$this->successJson("获取心愿单成功！",$collection_list);
		}else{
			$this->errorJson("此用户暂无心愿单");
		}
	}
	
	//记录用户浏览历史(新增商品足迹和心愿单)
    public function save_personal_browse() {
		$userid=I('userid',1);
		$goods_id=I('goods_id',1);
		$gbs_model= M("GoodsBrowse");
		$timestamp=time();
		$datetime=date("Y-m-d H:i:s",time());
		$result=$gbs_model->where(array('userid' => $userid,'goods_id' => $goods_id))->find();
		if($result){
			$gbs_model->where(array('bid' => $result['bid']))->save(array("browse_time"=>$timestamp,"browse_date"=>$datetime,"browse_count"=>array("exp","browse_count+1")));
			$this->successJson("记录成功！");
		}else{
			$data=array(
	        'userid' => $userid,
	        'goods_id' => $goods_id,
	        'browse_time' => $timestamp,
			'browse_date' => $datetime
	    	);
			$gbs_model->add($data);
			$this->successJson("记录成功！");
		}
	}
	
	//获取某一用户的浏览记录
    public function personal_browse_list() {
		$userid=I('userid',1);
		$gbs_model= M("GoodsBrowse");
		$field = 'g.goods_id,g.cat_id,g.goods_name,g.goods_remark,g.goods_img,g.shop_price,g.good_desc,g.store_count';
		$join = '__GOODS__ as g on g.goods_id = b.goods_id';
		$group = 'convert(post_date,DATE)';
		$order = "b.browse_time DESC";
		$browse_list=$gbs_model->alias("b")->join($join)->field($field)
		->where(array('userid' => $userid))->order($order)->select();
		if($browse_list){
			$this->successJson("获取浏览记录成功！",$browse_list);
		}else{
			$this->errorJson("此用户暂无浏览记录");
		}
	}
	
	//获取用户的足迹时间线
    public function personal_browse_sections() {
		$userid=I('userid',1);
		$gbs_model= M("GoodsBrowse");
		$where =array('userid' => $userid);
		$limit = '0,20';
		$time_order = "browse_date DESC";
		$time_group = 'convert(browse_date,DATE)';
		$time_field = 'convert(browse_date,DATE) as section_date';
		$time_list=$gbs_model->field($time_field)->where($where)->group($time_group)
		->order($time_order)->limit($limit)->select();
		//echo M()->getLastSql();exit;
		if($time_list){
			foreach ($time_list as $key => $value) {
			$section_order = "b.browse_time DESC";
			$section_join = '__GOODS__ as g on g.goods_id = b.goods_id';
			$section_where['b.browse_date'] = array('like',$value['section_date']."%");
			$section_where['b.userid'] = array('eq',$userid);
			$section_field = 'g.goods_id,g.cat_id,g.goods_name,g.goods_remark,
			g.goods_img,g.shop_price,g.good_desc,g.store_count';
			
			$section_list=$gbs_model->alias("b")->join($section_join)->field($section_field)
			->where($section_where)->order($section_order)->select();
			//echo M()->getLastSql();exit;
			if(!empty($section_list)){
				$time_list[$key]['section_list'] =$section_list;
			}
		}
		$this->successJson("获取浏览记录成功！",$time_list);
			
		}else{
			$this->errorJson("暂无此用户浏览记录");
		}
	}

	
	//商品分类列表 
	public function category_json() {
		$category_model = D("Goods/GoodsCategory");
    	$result = $category_model->order(array("listorder"=>"asc"))->select();
		$this->successJson("获取商品分类列表成功！", $result);
    }
	
	// 用于后台导航编辑添加
	public function nav_index_json(){
		$parentid= I("get.parent",0,'intval');
        $category_obj= M("Goods_category");
		$where=array();
        $where['parent_id'] = array('eq',$parentid);
        $result = $category_obj->field('id,name,parent_id')->where($where)->order(array("listorder"=>"asc"))->select();
		foreach ($result as $key=>$item){
		$item_where['parent_id'] = array('eq',$item['id']);
		$children = $category_obj->field('id,name,parent_id')->where($item_where)->order(array("listorder"=>"asc"))->select();
		$result[$key]['children']=$children;
		}
		$this->successJson("获取商品分类列表成功！", $result);
	}
	
	public function add_post_json(){
		if(IS_POST){
				$goods_model = D("Goods/Goods");									
				if(!empty($_POST['photos_url'])){
				foreach ($_POST['photos_url'] as $key=>$url){
					$photourl=sp_asset_relative_url($url);
					$img['photo'][]=array("url"=>$photourl,"alt"=>"alert.png");
					}
				}
								
				$data = I("post.post");
				if($data['goods_name'] == ''){
					$this->errorJson("商品名称不能为空！");
				}
				if($data['cat_id'] == '' || $data['cat_id'] == 0){
					$this->errorJson("请选择分类！");
				}
				$data['photo'] = json_encode($img['photo']);
				$data['goods_content'] = htmlspecialchars_decode($data['goods_content']);
				$data['last_update'] = time();
				$data['on_time'] = $data['is_on_sale'] == 1 ? time() : '';
				$result=$goods_model->add($data);
								
				$goods_model->addGoodsSku($result);//添加规格
				$goods_model->addSpecImg($result);//添加规格图片
								
				if ($result) {
					$this->successJson("添加成功！");
				} else {
					$this->errorJson("添加失败！");
				}			
		}
	}

}


