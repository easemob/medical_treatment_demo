<?php
namespace Goods\Model;

use Common\Model\CommonModel;

class GoodsOrderModel extends CommonModel {
	protected $_validate = array(
		//array(验证字段,验证规则,错误提示,验证条件,附加规则,验证时间)
		array('consignee', 'require', '收货人姓名不能为空！', 1, 'regex', 3),		
		array('mobile', 'require', '联系电话不能为空！', 1, 'regex', 3),
		array('province', 'require', '省不能为空', 1, 'regex', 3),
		array('city', 'require', '市不能为空！', 1, 'regex', 3),
		array('district', 'require', '区/镇不能为空！', 1, 'regex', 3),
		array('address', 'require', '详细地址不能为空！', 1, 'regex', 3),
	);
			
	protected function _before_write(&$data) {
		parent::_before_write($data);
	}
}
