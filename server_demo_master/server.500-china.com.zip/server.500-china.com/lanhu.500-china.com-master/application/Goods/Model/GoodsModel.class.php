<?php
namespace Goods\Model;

use Common\Model\CommonModel;

class GoodsModel extends CommonModel {
	
	//自动验证
	protected $_validate = array(
		//array(验证字段,验证规则,错误提示,验证条件,附加规则,验证时间)
		//array('goods_name', 'require', '商品名称不能为空', 1, 'regex', 3),
		//array('cat_id', 'require', '请选择分类', 1, 'regex', 3),
	);
	
	protected $_auto = array (
		
		array('last_update', 'time', 3, 'function' ),
		array('goods_content', 'htmlspecialchars_decode', 3, 'function' ),
		//array('description', 'htmlspecialchars',3, 'function' ), 
	);
	
	//添加编辑规格
	public function addGoodsSku($goods_id){
		$item = I('post.item');
		M('GoodsSku')->where(array('goods_id'=>$goods_id))->delete();
		foreach($item as $key => $val){
			$dataList[] = array('goods_id'=>$goods_id,'item_path'=>$key,'price'=>$val['price'],'store_count'=>$val['store_count']);
		}
		M('GoodsSku')->addAll($dataList);
	}
	
	//添加编辑规格图片
	public function addSpecImg($goods_id){
		M('SpecImg')->where("goods_id = $goods_id")->delete();
		foreach($_POST['spec_img'] as $key=>$v){
			M('SpecImg')->add(array('goods_id'=>$goods_id ,'spec_item_id'=>$key,'img'=>$v));
		}
	}
	
	protected function _before_write(&$data) {
		parent::_before_write($data);
	}
	

}