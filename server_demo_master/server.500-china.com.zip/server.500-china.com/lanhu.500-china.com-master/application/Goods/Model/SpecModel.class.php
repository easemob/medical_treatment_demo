<?php
namespace Goods\Model;

use Common\Model\CommonModel;

class SpecModel extends CommonModel {
	protected $_validate = array(
		//array(验证字段,验证规则,错误提示,验证条件,附加规则,验证时间)
		array('spec_name', 'require', '规格名称不能为空！', 1, 'regex', 3),		
		array('type_id', 'require', '规格类型不能为空！', 1, 'regex', 3),
	);
	
	protected $_auto = array (
		array('spec_name', 'trim', 3, 'function' ),		
	);
	
	
	protected function _before_write(&$data) {
		parent::_before_write($data);
	}
}
