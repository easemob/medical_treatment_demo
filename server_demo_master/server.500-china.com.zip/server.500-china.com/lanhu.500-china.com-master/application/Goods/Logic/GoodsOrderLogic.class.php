<?php

namespace Goods\Logic;

use Think\Model\RelationModel;

class GoodsOrderLogic extends RelationModel
{
	//获取基本信息
	public function orderInfo($order_id){
		$order = M('GoodsOrder')->field('a.*,b.user_login')->alias("a")->join('__USERS__ b ON a.user_id = b.id')->where("order_id = {$order_id}")->find();
		$order['detail_address'] = $this->getAddressName($order['province'],$order['city'],$order['district']);
		$order['detail_address'] = $order['detail_address'].$order['address'];
		return $order;
	}
	
	//获取订单商品信息
	public function getGoodsOrder($order_id){
		$goods_order = M('GoodsOrderSub')->field(array("a.*","b.*","(a.goods_num * a.member_goods_price)"=>"goods_total"))
		->alias('a')		
		->join('__GOODS__ b ON a.goods_id = b.goods_id')
		->where("order_id = {$order_id}")
		->select();
		return $goods_order;
	}
	
	//获取当前可操作按钮
	public function getOrderBtn($order){
		$os = $order['order_status']; //订单状态 1确定 2订单完成 3退货 4无效 
		$sh = $order['shipping_status']; //发货状态 1已发货 2已收货
		$pay = $order['pay_status']; //支付状态 1已支付
		
		if($os == 0 && $sh == 0 && $pay == 0){
			$btn['confirm'] = '确定';
			$btn['pay'] = '付款';
			$btn['invalid'] = '无效';
		}elseif($os == 0 && $sh == 0 && $pay == 1){
			$btn['confirm'] = '确定';
			$btn['nopay'] = '未付款';
			$btn['invalid'] = '无效';
		}elseif($os == 1 && $sh == 0 && $pay == 1){
			$btn['ship'] = '发货';
			$btn['cancel'] = '取消';
			$btn['nopay'] = '未付款';
			$btn['invalid'] = '无效';
		}elseif($os == 1 && $sh == 0 && $pay == 0){
			$btn['ship'] = '发货';
			$btn['pay'] = '付款';
			$btn['cancel'] = '取消';			
			$btn['invalid'] = '无效';
		}elseif($os == 0 && $sh == 0 && $pay == 3){
			$btn['confirm'] = '确定';
			$btn['invalid'] = '无效';
		}elseif($os == 1 && $sh == 0 && $pay == 3){
			$btn['ship'] = '发货';
			$btn['cancel'] = '取消';
			$btn['invalid'] = '无效';
		}elseif($os == 1 && $sh == 1){
			$btn['receive'] = '已收货';
		}elseif($os == 1 && $sh == 2){
			$btn['return'] = '退货';
		}
		
		if($os == 4){
			$btn['void'] = '订单作废';
		}
		
		return $btn;
	}
	
	/**
	 * 订单操作记录
	 * $order_id 订单id
	 * $action 操作描述
	 * $note 操作备注
	 */
	public function orderLog($order_id,$action,$note=''){
		$admin_id = get_current_admin_id();
		$user = M('Users')->where("id = {$admin_id}")->find();
		$order = M('GoodsOrder')->where(array('order_id'=>$order_id))->find();
		$data['order_id'] = $order_id;
        $data['action_user'] = $user['user_login'];
        $data['action_note'] = $note;
        $data['order_status'] = $order['order_status'];
        $data['pay_status'] = $order['pay_status'];
        $data['shipping_status'] = $order['shipping_status'];
        $data['log_time'] = time();
        $data['status_desc'] = $action;        
        return M('GoodsOrderLog')->add($data);//订单操作记录
	}
	
	/**
     * 获取地区名字
     * @param int $p
     * @param int $c
     * @param int $d
     * @return string
     */
    public function getAddressName($p=0,$c=0,$d=0){
        $p = M('Address')->where(array('id'=>$p))->field('name')->find();
        $c = M('Address')->where(array('id'=>$c))->field('name')->find();
        $d = M('Address')->where(array('id'=>$d))->field('name')->find();
        return $p['name'].''.$c['name'].''.$d['name'].'';
    }
}