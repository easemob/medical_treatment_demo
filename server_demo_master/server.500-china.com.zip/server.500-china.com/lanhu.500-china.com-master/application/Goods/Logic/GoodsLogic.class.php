<?php

namespace Goods\Logic;

use Think\Model\RelationModel;

class GoodsLogic extends RelationModel
{
	public function getSpecInput($goods_id, $spec_arr)
    {
             
        // 排序
        foreach ($spec_arr as $k => $v)
        {
            $spec_arr_sort[$k] = count($v);
        }
        //asort($spec_arr_sort);        
        foreach ($spec_arr_sort as $key =>$val)
        {
            $spec_arr2[$key] = $spec_arr[$key];
        }
     
        
         $clo_name = array_keys($spec_arr2);         
         $spec_arr2 = combineDika($spec_arr2); //  获取 规格的 笛卡尔积                 
                     
         $spec = M('Spec')->getField('id,spec_name'); // 规格表
		 
         $specItem = M('SpecItem')->getField('id,item,spec_id');//规格项
         $goods_sku = M('GoodsSku')->where('goods_id = '.$goods_id)->getField('item_path,price,store_count');//规格项
                       
       $str = "<table class='table table-bordered' id='spec_input_tab'>";
       $str .="<tr>";       
       // 显示第一行的数据
       foreach ($clo_name as $k => $v) 
       {
           $str .=" <td><b>{$spec[$v]}</b></td>";
       }    
        $str .="<td width=120><b>价格</b></td>
               <td width=120><b>库存</b></td>              
             </tr>";
       // 显示第二行开始 
       foreach ($spec_arr2 as $k => $v) 
       {
            $str .="<tr>";
            $item_key_name = array();
            foreach($v as $k2 => $v2)
            {
                $str .="<td>{$specItem[$v2][item]}</td>";
                $item_key_name[$v2] = $spec[$specItem[$v2]['spec_id']].':'.$specItem[$v2]['item'];
            }   
            ksort($item_key_name);            
            $item_key = implode('-', array_keys($item_key_name));
            $item_name = implode(' ', $item_key_name);
            
			$goods_sku[$item_key]['price'] ? false : $goods_sku[$item_key]['price'] = 0; // 价格默认为0
			$goods_sku[$item_key]['store_count'] ? false : $goods_sku[$item_key]['store_count'] = 0; //库存默认为0
            $str .="<td><input name='item[$item_key][price]' value='{$goods_sku[$item_key]['price']}' onkeyup='this.value=this.value.replace(/[^\d.]/g,\"\")' onpaste='this.value=this.value.replace(/[^\d.]/g,\"\")' /></td>";
            $str .="<td><input name='item[$item_key][store_count]' value='{$goods_sku[$item_key]['store_count']}' onkeyup='this.value=this.value.replace(/[^\d.]/g,\"\")' onpaste='this.value=this.value.replace(/[^\d.]/g,\"\")'/></td>";            
            $str .="</tr>";           
       }
        $str .= "</table>";
       return $str;   
    }
	
	public function getSpecList($goods_id){
		//详细页获取规格
		//规格
		$sku = M('GoodsSku')->where(array("goods_id"=>$goods_id))->getField("GROUP_CONCAT(`item_path` SEPARATOR '-') AS items_id");
		$sku = array_unique(explode('-', $sku));
		
		$spec_item = M('SpecItem')->order(array("item_order ASC"))->select();
		$spec_img = M('SpecImg')->where(array("goods_id"=>$goods_id))->select();
		
		$arr = array();
		foreach($spec_item as $v){
			if(in_array($v['id'],$sku)){
				$arr[getSpecName($goods_id,$v['spec_id'])][] = array("item_id"=>$v['id'],"item"=>$v['item'],"img"=>getItemImg($goods_id,$v['id'])); 
					
			}
		}
		return $arr;
	}
}