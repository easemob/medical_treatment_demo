<?php
namespace Demo\Controller;
use Common\Controller\HomebaseController;

class IndexController extends HomebaseController{
	
	function index(){
		echo "hello";
	}
  
  function proAddress(){
		$pro_list=M("Area")->field('id as area_code,area_name')->where("area_parent_id = 0")->select();
		$this->successJson("获取地址列表成功!",$pro_list);
	}
  
  function cityAddress(){
		$areaCode=I('get.areaCode','0');
    	$where['area_parent_id']= array('eq',$areaCode);
		$city_list=M("Area")->field('id as area_code,area_name')->where($where)->select();
		$this->successJson("获取地址列表成功!",$city_list);
	}
  
  
}