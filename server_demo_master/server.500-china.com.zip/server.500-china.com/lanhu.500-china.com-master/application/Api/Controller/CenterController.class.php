<?php
namespace Api\Controller;
Vendor('JPush.autoload');
Vendor('RongCloud.RongCloud');
use JPush\Client as JPushClient;
use RongCloud\RongCloud;
use Think\RtcTokenBuilder;
use Common\Controller\HomebaseController;

class CenterController extends HomebaseController {
	
	function _initialize(){
		parent::_initialize();
	}

	//获取融云用户信息
    public function getRongCloudUserInfo() {
		$rongCloudID=I("post.rongCloudID");
		$RongSDK = new RongCloud(C('RongCloudKEY'), C('RongCloudSECRET'));
    	$user = ['id' => $rongCloudID];
    	$res = $RongSDK->getUser()->get($user);
		$this->successJson("获取融云用户信息成功！",$res);
	}
	
    // 接口中心
	public function index() {
		$this->successJson("接口中心成功！");
    }

	// 获取agora令牌token
	public function getAgoraToken() {
		$uidStr=I("post.mobile");
		$channelName=I("post.channel");
		if(empty($uidStr)){
			$uidStr = "18661289339";
		}
		if(empty($channelName)){
			$channelName = "lanhuapp";
		}
		$appID = "13744d327d96413ab9dfaf2af82ce049";
		$appCertificate = "9765d07d2e2c4310a8b80a66dd731c35";
		$role = RtcTokenBuilder::RoleAttendee;
		$privilegeExpiredTs = time() + 3600*12;
		$token = RtcTokenBuilder::buildTokenWithUserAccount($appID, $appCertificate, $channelName, $uidStr, $role, $privilegeExpiredTs);
		M('Agoratoken')->add(array("uidstr"=>$uidStr,"channelname"=>$channelName,"expiredts"=>$privilegeExpiredTs,"agorartctoken"=>$token,"createtime"=>date("Y-m-d H:i:s",time())));
		$jsonData=array("appID"=>$appID,"appCertificate"=>$appCertificate,"channelName"=>$channelName,"uidStr"=>$uidStr,"role"=>$role,"privilegeExpiredTs"=>$privilegeExpiredTs,"token"=>$token);
		$this->successJson("获取agora令牌token成功！",$jsonData);
    }
}
