<?php
namespace User\Model;

use Common\Model\CommonModel;

class UserAddressModel extends CommonModel {
	protected $_validate = array(
		//array(验证字段,验证规则,错误提示,验证条件,附加规则,验证时间)
		array('consignee', 'require', '收货人不能为空！', 1, 'regex', 3),		
		array('province', 'require', '省不能为空！', 1, 'regex', 3),
		array('city', 'require', '市不能为空！', 1, 'regex', 3),
		array('district', 'require', '区不能为空！', 1, 'regex', 3),
		array('address', 'require', '地址不能为空！', 1, 'regex', 3),
		array('mobile', 'require', '手机不能为空！', 1, 'regex', 3),
	);
	
}
