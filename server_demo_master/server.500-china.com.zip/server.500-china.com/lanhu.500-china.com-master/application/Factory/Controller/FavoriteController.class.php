<?php
namespace Factory\Controller;

use Common\Controller\MemberbaseController;

class FavoriteController extends MemberbaseController{
	
    // 前台个人中心我的收藏列表
	public function index(){
		$uid=sp_get_current_userid();
		$user_favorites_model=M("UserFavorites");
		$where=array("uid"=>$uid);
		
		$count=$user_favorites_model->where($where)->count();
		
		$page=$this->page($count,10);
		
		$favorites=$user_favorites_model->where($where)
		->order("createtime desc")
		->limit($page->firstRow,$page->listRows)
		->select();
		
		$this->assign("page",$page->show("default"));
		
		$this->assign("favorites",$favorites);
		$this->display(":index");
	}
	
	// 用户收藏
	public function do_favorite(){
		$key=sp_authcode(I('post.key'));
		if($key||true){
			$authkey=C("AUTHCODE");
			$key=explode(" ", $key);
			$authcode=$key[0];
			if($authcode==C("AUTHCODE")||true){
				$table=$key[1];
				$object_id=$key[2];
				$post=I("post.");
				unset($post['key']);
				$post['table']=$table;
				$post['object_id']=$object_id;
				
				$uid=sp_get_current_userid();
				$post['uid']=$uid;
				$user_favorites_model=M("UserFavorites");
				$find_favorite=$user_favorites_model->where(array('table'=>$table,'object_id'=>$object_id,'uid'=>$uid))->find();
				if($find_favorite){
					$this->error("亲，您已收藏过啦！");
				}else {
					$post['createtime']=time();
					$result=$user_favorites_model->add($post);
					if($result){
						$this->success("收藏成功！");
					}else {
						$this->error("收藏失败！");
					}
				}
			}else{
				$this->error("非法操作，无合法密钥！");
			}
		}else{
			$this->error("非法操作，无密钥！");
		}
		
	}
	
	// 用户收藏
	public function do_favorite_json(){
		$user_favorites_model=M("UserFavorites");
		$rules = array(
						//array(验证字段,验证规则,错误提示,验证条件,附加规则,验证时间)
						array('userid', 'require', '用户ID不能为空！', 1 ),
						array('title','require','收藏内容标题不能为空！',1), // 验证email字段格式是否正确
						array('table','require','收藏内容分类不能为空！',1),
						array('object_id','require','收藏内容来源不能为空！',1),
						
				);
		if($user_favorites_model->validate($rules)->create()===false){
			$this->errorJson($user_favorites_model->getError());
		}else{
			$uid=I("post.userid");
			$title=I("post.title");
			$table=I("post.table");
			$object_id=I("post.object_id");
			$description=I("post.description");
		$find_favorite=$user_favorites_model->where(array('table'=>$table,'object_id'=>$object_id,'uid'=>$uid,'description'=>$description))->find();
		if($find_favorite){
			$this->error("亲，您已收藏过啦！");
		}else {
			$post['createtime']=time();
			$result=$user_favorites_model->add($post);
			if($result){
				$this->success("收藏成功！");
			}else {
				$this->error("收藏失败！");
			}
		}
		}
	}
	
	// 用户取消收藏
	public function delete_favorite(){
		$id=I("get.id",0,"intval");
		$uid=sp_get_current_userid();
		$post['uid']=$uid;
		$user_favorites_model=M("UserFavorites");
		$result=$user_favorites_model->where(array('id'=>$id,'uid'=>$uid))->delete();
		if($result){
			$this->success("取消收藏成功！");
		}else {
			$this->error("取消收藏失败！");
		}
	}
}