<?php
namespace Factory\Controller;

use Common\Controller\HomebaseController;

use Think\Easemob;

class IndexController extends HomebaseController {
    
    // 前台用户首页 (公开)
	public function index() {
	    
		$id=I("get.id",0,'intval');
		
		$users_model=M("Users");
		
		$user=$users_model->where(array("id"=>$id))->find();
		//echo json_encode($user);exit;
		if(empty($user)){
			$this->error("查无此人！");
		}
		
		$this->assign($user);
		$this->display(":index");

    }
  
  // 保存用户头像
    public function do_avatar_json() {
      	$userid=I('post.userid');
		$imgurl=I('post.imgurl');
		$user_nicename=I('post.user_nicename');
		if(empty($imgurl)){
		$imgurl="avatar/default_header.png";	
		}
		$users_model=M("Users");
		$users_info=$users_model->where(array("id"=>$userid))->find();
		$user_login=$users_info['user_login'];
		//$resultIm=$this->editImNickName($user_login,$user_nicename);
		$result=$users_model->where(array("id"=>$userid))->save(array("avatar"=>$imgurl,"user_nicename"=>$user_nicename));
    	if($result){
        	$this->successJson("资料更新成功！");
    	}else{
    		$this->errorJson("资料更新失败！");
    	}
    		    
	}  
	
	// 设置支付密码
    public function reset_user_paypass() {
      	$userid=I('post.userid');
		$user_paypass=I('post.user_paypass');
		$users_model=M("Users");
		$result=$users_model->where(array("id"=>$userid))->save(array("user_paypass"=>$user_paypass));
    	if($result){
        	$this->successJson("用户支付密码设置成功！");
    	}else{
    		$this->errorJson("用户支付密码设置失败！");
    	}
    		    
	} 
	
	// 获取个人资料
    public function get_user_info() {
      	$user_id=I('post.user_id');
		$userinfo_model=M("UserInfo");
		$result=$userinfo_model->where(array("user_id"=>$user_id))->find();
    	if($result){
		$this->successJson("获取个人资料成功！",$result);
		}else{
		$this->errorJson("获取个人资料失败！");
		}
	}
	
	// 设置个人资料
    public function edit_user_info() {
      	$user_id=I('post.user_id');
		$userinfo_model=M("UserInfo");
		$result=$userinfo_model->where(array("user_id"=>$user_id))->find();
		$real_name=I('post.real_name');
		if(empty($real_name)){
		$real_name=$result['real_name'];	
		}
		$user_idnumber=I('post.user_idnumber');
		if(empty($user_idnumber)){
		$user_idnumber=$result['user_idnumber'];
		}
		$user_address=I('post.user_address');
		if(empty($user_address)){
		$user_address=$result['user_address'];	
		}
		$user_friend=I('post.user_friend');
		if(empty($user_friend)){
		$user_friend=$result['user_friend'];		
		}
		$friend_mobile=I('post.friend_mobile');
		if(empty($friend_mobile)){
		$friend_mobile=$result['friend_mobile'];	
		}
		$user_cardphoto=I('post.user_cardphoto');
		if(empty($user_cardphoto)){
		$user_cardphoto=$result['user_cardphoto'];	
		}
		$data=array(
			'user_id' => $user_id,
			'real_name' => $real_name,
			'user_idnumber' => $user_idnumber,
			'user_address' => $user_address,
			'user_friend' => $user_friend,
			'friend_mobile' => $friend_mobile,
			'user_cardphoto' => $user_cardphoto,
	    );
    	$cresult=$userinfo_model->where(array("user_id"=>$user_id))->save($data);
			if($cresult){
				$this->successJson("设置个人资料成功！");
    		}else{
				$this->errorJson("设置个人资料失败！");
    		}
    		    
	}  
	
	public function editImNickName($username,$nickname){
    	$options['client_id'] = 'YXA6JaYeEG55EeWfDIdFJvc5xQ';
    	$options['client_secret'] = 'YXA6t5BCqNIEnt5h6c2Bb92LMUErQtM'; 
    	$options['org_name'] = 'comcaesar';
    	$options['app_name'] = 'huaxin'; 
    	$e = new Easemob($options);
    	$result_n = $e->editNickname($username,$nickname);
    	return $result_n;
    }
	
	// 获取用组户头像
    public function get_avatararray_json() {
      	$userarray=I('post.userarray');
		$users_model=M("Users");
		//echo json_encode(explode(",", $userarray));exit;
		$result=$users_model->field('id,uuid,user_login,user_nicename,avatar')->where(array("user_login"=>array("in",explode(",", $userarray))))->select();
    	if($result){
        	$this->successJson("获取用户组头像成功！",$result);
    	}else{
    		$this->errorJson("获取用户组头像失败！");
    	}
    		    
	}  
	
	// 获取全部用组户头像
    public function get_allavatars_json() {
		$users_model=M("Users");
		$result=$users_model->field('id,uuid,user_login,user_nicename,avatar')->select();
    	if($result){
        	$this->successJson("获取全部用户组头像成功！",$result);
    	}else{
    		$this->errorJson("获取全部用户组头像失败！");
    	}
    		    
	}  
    
    // 前台ajax 判断用户登录状态接口
    function is_login(){
    	if(sp_is_user_login()){
    		$this->ajaxReturn(array("status"=>1,"user"=>sp_get_current_user()));
    	}else{
    		$this->ajaxReturn(array("status"=>0,"info"=>"此用户未登录！"));
    	}
    }

    //退出
    public function logout(){
    	$ucenter_syn=C("UCENTER_ENABLED");
    	$login_success=false;
    	if($ucenter_syn){
    		include UC_CLIENT_ROOT."client.php";
    		echo uc_user_synlogout();
    	}
    	session("user",null);//只有前台用户退出
    	redirect(__ROOT__."/");
    }
  
  

}
