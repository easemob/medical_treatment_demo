<?php
namespace Factory\Controller;

use Common\Controller\HomebaseController;

class PublicController extends HomebaseController {
    protected $users_model,$role_model;

	public function _initialize() {
		parent::_initialize();
		$this->users_model = D("Common/Users");
		$this->role_model = D("Common/Role");
	}
	
	// 获取用组户头像
    public function get_avatararray_json() {
      	$userarray=I('post.userarray');
		$users_model=M("Users");
		//echo json_encode(explode(",", $userarray));exit;
		$result=$users_model->field('id,uuid,user_login,user_nicename,avatar')->where(array("user_login"=>array("in",explode(",", $userarray))))->select();
    	if($result){
        	$this->successJson("获取用户组头像成功！",$result);
    	}else{
    		$this->errorJson("获取用户组头像失败！");
    	}
    		    
	} 
	
	// 文章浏览
    public function do_hit_json(){
    	
    	$id = I('post.object_id');//posts表中id
    	$posts_model=M("Posts");
    	$common_action_log_model=M("CommonActionLog");
		$action="Portal-Article-do_hits";
		$uid=I("post.userid");
		$object="posts$id";
		if(empty($uid)){
			$this->errorJson("用户ID不能为空！");
		}
		$ip=get_client_ip(0,true);//修复ip获取
		$where=array("user"=>$uid,"action"=>$action,"object"=>$object);
		$find_log=$common_action_log_model->where($where)->find();
		$time=time();
		if($find_log){
			$common_action_log_model->where($where)->save(array("count"=>array("exp","count+1"),"last_time"=>$time,"ip"=>$ip));
		}else{
		$common_action_log_model->add(array("user"=>$uid,"action"=>$action,"object"=>$object,"count"=>array("exp","count+1"),"last_time"=>$time,"ip"=>$ip));
		}
		$posts_model->save(array("id"=>$id,"post_hits"=>array("exp","post_hits+1")));
    	$this->successJson("浏览好啦！");
	
    }
	
	// 文章浏览
    public function do_hits_json(){
    	
    	$id = I('post.object_id');//posts表中id
    	$posts_model=M("Posts");
    	$common_action_log_model=M("CommonActionLog");
		$action="Portal-Article-do_hits";
		$uid=I("post.userid");
		$object="posts$id";
		if(empty($uid)){
			$this->errorJson("用户ID不能为空！");
		}
		$ip=get_client_ip(0,true);//修复ip获取
		$where=array("user"=>$uid,"action"=>$action,"object"=>$object,"postid"=>$id);
		$find_log=$common_action_log_model->where($where)->find();
		$time=time();
		if($find_log){
			$common_action_log_model->where($where)->save(array("count"=>array("exp","count+1"),"last_time"=>$time,"ip"=>$ip));
		}else{
		$common_action_log_model->add(array("user"=>$uid,"action"=>$action,"object"=>$object,"count"=>array("exp","count+1"),"last_time"=>$time,"ip"=>$ip));
		}
    	$this->successJson("浏览好啦！");
	
    }
	
	// 用户类别收藏
    public function do_follow_json(){
		$uid = I('post.userid');//users表中id
		$follow_id = I('post.follow_id');//category表中id
		$users_model=M("Users");
		$user_data=$users_model->field('follow_id')->where(array("id"=>$uid))->find();
		$user_follows=$user_data['follow_id'];
		if(empty($user_follows)){
			$data['follow_id']=$follow_id;
    		$data['id']=$uid;
			$users_model->save($data);
			$this->successJson("用户类别收藏成功！");
		}else{
			$follows_user=false;
			$follow_array =explode(",",$user_follows);
			foreach ($follow_array as $follow){
            	if($follow==$follow_id){
					$follows_user=true;
				}
            }
			//echo json_encode($user_follows);exit;
			if(!$follows_user){
				$data['follow_id']=$user_follows.','.$follow_id;
    			$data['id']=$uid;
				$users_model->save($data);
				$this->successJson("用户类别收藏成功！");
			}else{
				$this->errorJson("您已收藏过该类别！");
			}
		}
	}
	
	// 用户类别收藏
    public function do_nofollow_json(){
		$uid = I('post.userid');//users表中id
		$follow_id = I('post.follow_id');//category表中id
		$users_model=M("Users");
		$user_data=$users_model->field('follow_id')->where(array("id"=>$uid))->find();
		$user_follows=$user_data['follow_id'];
		if(empty($user_follows)){
			$data['follow_id']=$follow_id;
    		$data['id']=$uid;
			$users_model->save($data);
			$this->errorJson("您还未收藏过任何类别！");
		}else{
			$follows_user=false;
			$follow_array =explode(",",$user_follows);
			foreach ($follow_array as $key => $value){
            	if($value==$follow_id){
					$follows_user=true;
					unset($follow_array[$key]);
				}
            }
			//echo json_encode($user_follows);exit;
			if($follows_user){
				if(empty($follow_array)){
					$data['follow_id']='0';	
				}else{
					$data['follow_id']=implode(',',$follow_array);
				}
    			$data['id']=$uid;
				$users_model->save($data);
				$this->successJson("用户取消类别收藏成功！");
			}else{
				$this->errorJson("您还未收藏过该类别！");
			}
		}
	}
	
	// 文章点赞
    public function do_like_json(){
    	
    	$id = I('post.object_id');//posts表中id
    	$posts_model=M("Posts");
    	$common_action_log_model=M("CommonActionLog");
		$action="Portal-Article-do_like";
		$uid=I("post.userid");
		$object="posts$id";
		if(empty($uid)){
			$this->errorJson("用户ID不能为空！");
		}
		$ip=get_client_ip(0,true);//修复ip获取
		$where=array("user"=>$uid,"action"=>$action,"object"=>$object);
		$find_log=$common_action_log_model->where($where)->find();
		$time=time();
		if($find_log){
			$this->errorJson("您已赞过啦！");
		}else{
		$common_action_log_model->add(array("user"=>$uid,"action"=>$action,"object"=>$object,"count"=>array("exp","count+1"),"last_time"=>$time,"ip"=>$ip));
		$posts_model->save(array("id"=>$id,"post_like"=>array("exp","post_like+1")));
    		$this->successJson("赞好啦！");
		}
	
    }
	
	// 用户收藏
	public function do_favorite_json(){
		$user_favorites_model=M("UserFavorites");
		$rules = array(
						//array(验证字段,验证规则,错误提示,验证条件,附加规则,验证时间)
						array('uid', 'require', '用户ID不能为空！', 1 ),
						array('title','require','收藏内容标题不能为空！',1), // 验证email字段格式是否正确
						array('table','require','收藏内容分类不能为空！',1),
						array('object_id','require','收藏内容来源不能为空！',1),
						
				);
		if($user_favorites_model->validate($rules)->create()===false){
			$this->errorJson($user_favorites_model->getError());
		}else{
			$post=I("post.");
			$uid=I("post.uid");
			$title=I("post.title");
			$table=I("post.table");
			$object_id=I("post.object_id");
		$find_favorite=$user_favorites_model->where(array('table'=>$table,'object_id'=>$object_id,'uid'=>$uid))->find();
		if($find_favorite){
			$this->errorJson("亲，您已收藏过啦！");
		}else {
			$post['createtime']=time();
			$result=$user_favorites_model->add($post);
			if($result){
				$this->successJson("收藏成功！");
			}else {
				$this->errorJson("收藏失败！");
			}
		}
		}
	}
	
    // 用户头像api
	public function avatar(){
		$users_model=M("Users");
		$id=I("get.id",0,"intval");
		
		$find_user=$users_model->field('avatar')->where(array("id"=>$id))->find();
		
		$avatar=$find_user['avatar'];
		$avatar=preg_replace("/^avatar\//", '', $avatar);//2.2以后头像路径统一以avatar/开头
		$should_show_default=false;
		
		if(empty($avatar)){
			$should_show_default=true;
		}else{
			if(strpos($avatar,"http")===0){
				header("Location: $avatar");exit();
			}else{
				$avatar_dir=C("UPLOADPATH")."avatar/";
				$avatar=$avatar_dir.$avatar;
				if(file_exists($avatar)){
					$imageInfo = getimagesize($avatar);
					if ($imageInfo !== false) {
					    $fp=fopen($avatar,"r");
					    $file_size=filesize($avatar);
						$mime=$imageInfo['mime'];
						header("Content-type: $mime");
						header("Accept-Length:".$file_size);
						$buffer=1024*64;
						$file_count=0;
						//向浏览器返回数据
						while(!feof($fp) && $file_count<$file_size){
						    $file_content=fread($fp,$buffer);
						    $file_count+=$buffer;
						    echo $file_content;
						    flush();
						    ob_flush();
						}
						fclose($fp);
					}else{
						$should_show_default=true;
					}
				}else{
					$should_show_default=true;
				}
			}
			
			
		}
		
		if($should_show_default){
			$imageInfo = getimagesize("public/images/headicon.png");
			if ($imageInfo !== false) {
				$mime=$imageInfo['mime'];
				header("Content-type: $mime");
				echo file_get_contents("public/images/headicon.png");
			}
			
		}
		exit();
		
	}
  
  // 客户端二维码收款
    public function getcode_for_user() {
		if (IS_POST) {
			$users_model=M("Users");
			$paylist_model=M("UserPaylist");
    	    $user_sum_add=I('post.user_sum_add');
			$sum_touserID=I('post.sum_touserID');
			$sum_foruserID=I('post.sum_foruserID');
    		if(empty($user_sum_add)){
    			$this->error("收款金额不能为空！");
    		}
    		$sum_touser=$users_model->where(array('id'=>$sum_touserID))->find();
			$sum_foruser=$users_model->where(array('id'=>$sum_foruserID))->find();
			$old_sumto=$sum_touser['user_sum'];
			$paytoName=$sum_touser['user_login'];
			if($old_sumto>$user_sum_add){
			$old_sumfor=$sum_foruser['user_sum'];
			$payforName=$sum_touser['user_login'];
			$data['user_sum']=$old_sumto-$user_sum_add;
    		$data['id']=$sum_touserID;
    		$r=$users_model->save($data);
			$data1['user_sum']=$old_sumfor+$user_sum_add;
			$data1['id']=$sum_foruserID;
			$r=$users_model->save($data1);
			$pr=$paylist_model->add(array('payforId'=>$sum_foruserID,'payforName'=>$payforName,'paytoId'=>$sum_touserID,'paytoName'=>$paytoName,'payAmount'=>$user_sum_add,'payforSum'=>$data1['user_sum'],'paytoSum'=>$data['user_sum'],'paydataTime'=>date("Y-m-d H:i:s")));
    		if ($r!==false) {
    			$this->successJson("收款成功！",$data1);
    		} else {
    			$this->errorJson("收款失败！");
    		}}else{
				$this->errorJson("付款方金额不足！");
			}
		}
		
	}
	
	// 客户端余额更新
    public function get_sum_user() {
		if (IS_POST) {
			$users_model=M("Users");
			$userID=I('post.userID');
			$userInfo=$users_model->where(array('id'=>$userID))->find();
			$user_sum=$userInfo['user_sum'];
			if ($userInfo) {
    			$this->successJson("余额更新成功！",$userInfo);
    		} else {
    			$this->errorJson("余额更新失败！");
    		}
		}
	
	}
	
	// 根据用户名查询用户ID
    public function get_userid_forname() {
		if (IS_POST) {
			$users_model=M("Users");
			$username=I('post.username');
			$userInfo=$users_model->where(array('user_login'=>$username))->find();
			if ($userInfo) {
    			$this->successJson("获取用户信息成功！",$userInfo);
    		} else {
    			$this->errorJson("获取用户信息失败！");
    		}
		}
	
	}
	
	// 获取用户交易记录列表
    public function get_user_paylist() {
		if (IS_POST) {
			$paylist_model=M("UserPaylist");
			$userID=I('post.userID');
			$where['payforId']=$userID;
	    	$where['paytoId']=$userID;
	    	$where['_logic'] = 'OR';
			$paylist=$paylist_model->field('payforName,paytoName,payamount,paydataTime')->where($where)->order(array("paydataTime" => "DESC"))->select();
			if ($paylist) {
    			$this->successJson("获取交易记录成功！",$paylist);
    		} else {
    			$this->errorJson("获取交易记录失败！");
    		}
		}
	
	}
	
	
	// 客户端二维码付款
    public function getcode_to_user() {
		if (IS_POST) {
			$users_model=M("Users");
			$paylist_model=M("UserPaylist");
    	    $user_sum_add=I('post.user_sum_add');
			$sum_touserID=I('post.sum_touserID');
			$sum_foruserID=I('post.sum_foruserID');
    		if(empty($user_sum_add)){
    			$this->error("付款金额不能为空！");
    		}
    		$sum_touser=$users_model->where(array('id'=>$sum_touserID))->find();
			$sum_foruser=$users_model->where(array('id'=>$sum_foruserID))->find();
			$old_sumto=$sum_touser['user_sum'];
			$paytoName=$sum_touser['user_login'];
			if($old_sumto>$user_sum_add){
			$old_sumfor=$sum_foruser['user_sum'];
			$payforName=$sum_foruser['user_login'];
			$data['user_sum']=$old_sumto-$user_sum_add;
    		$data['id']=$sum_touserID;
    		$r=$users_model->save($data);
			$data1['user_sum']=$old_sumfor+$user_sum_add;
			$data1['id']=$sum_foruserID;
			$r=$users_model->save($data1);
			$pr=$paylist_model->add(array('payforId'=>$sum_foruserID,'payforName'=>$payforName,'paytoId'=>$sum_touserID,'paytoName'=>$paytoName,'payAmount'=>$user_sum_add,'payforSum'=>$data1['user_sum'],'paytoSum'=>$data['user_sum'],'paydataTime'=>date("Y-m-d H:i:s")));
    		if ($r!==false) {
    			$this->successJson("付款成功！",$data);
    		} else {
    			$this->errorJson("付款失败！");
    		}}else{
				$this->errorJson("付款方金额不足！");
			}
		}
		
	}
	
	// 客户端二维码付款
    public function getcode_to_username() {
		if (IS_POST) {
			$users_model=M("Users");
			$paylist_model=M("UserPaylist");
    	    $user_sum_add=I('post.user_sum_add');
			$sum_touserID=I('post.sum_touserID');
			$sum_foruserName=I('post.sum_foruserName');
    		if(empty($user_sum_add)){
    			$this->error("付款金额不能为空！");
    		}
    		$sum_touser=$users_model->where(array('id'=>$sum_touserID))->find();
			$sum_foruser=$users_model->where(array('user_login'=>$sum_foruserName))->find();
			$old_sumto=$sum_touser['user_sum'];
			$paytoName=$sum_touser['user_login'];
			if($old_sumto>$user_sum_add){
			$old_sumfor=$sum_foruser['user_sum'];
			$payforName=$sum_foruser['user_login'];
			$sum_foruserID=$sum_foruser['id'];
			$data['user_sum']=$old_sumto-$user_sum_add;
    		$data['id']=$sum_touserID;
    		$r=$users_model->save($data);
			$data1['user_sum']=$old_sumfor+$user_sum_add;
			$data1['id']=$sum_foruserID;
			$r=$users_model->save($data1);
			$pr=$paylist_model->add(array('payforId'=>$sum_foruserID,'payforName'=>$payforName,'paytoId'=>$sum_touserID,'paytoName'=>$paytoName,'payAmount'=>$user_sum_add,'payforSum'=>$data1['user_sum'],'paytoSum'=>$data['user_sum'],'paydataTime'=>date("Y-m-d H:i:s")));
    		if ($r!==false) {
    			$this->successJson("付款成功！",$data);
    		} else {
    			$this->errorJson("付款失败！");
    		}}else{
				$this->errorJson("付款方金额不足！");
			}
		}
		
	}
	
	// 管理员添加提交
	public function add_post_json(){
		$role_user_model=M("RoleUser");
		$role_id = $_POST['role_id'];
		$user_id = $_POST['user_id'];
		$user_check_image01 = $_POST['user_check_image01'];
		$user_check_image02 = $_POST['user_check_image02'];
		$user_check_image03 = $_POST['user_check_image03'];
		$result=$role_user_model->add(array("role_id"=>$role_id,"user_id"=>$user_id,"user_check_image01"=>$user_check_image01,"user_check_image02"=>$user_check_image02,"user_check_image03"=>$user_check_image03));
		if ($result!==false) {
			$this->users_model->where(array("id"=>$user_id))->save(array("user_type"=>$role_id));
			$this->errorJson("管理员添加提交成功！");
			}
	}
    

    
}
