<?php
namespace Comment\Controller;

use Common\Controller\MemberbaseController;

class GoodsCommentController extends MemberbaseController{
	
	protected $comments_model;
	
	public function _initialize() {
		parent::_initialize();
		
	}
	
	// 商品评价列表
	public function index($order_id){
		$order = M('GoodsOrder')->where(array("order_id" => $order_id))->find();
		$goods_order = M('GoodsOrderSub')->field('a.*,b.goods_img')
		->alias('a')
		->join('__GOODS__ b ON a.goods_id = b.goods_id')
		->group('a.goods_id')
		->where(array("order_id" => $order_id))
		->select();
				
		$this->assign('order',$order);
		$this->assign('goods_order',$goods_order);
		$this->display(":comment_list");
	}
	
	//评价商品
	public function comment($rec_id){				
		$goods_order = M('GoodsOrderSub')->field('a.*,b.goods_img')
		->alias('a')
		->join('__GOODS__ b ON a.goods_id = b.goods_id')
		->group('a.goods_id')
		->where(array("rec_id" => $rec_id))
		->find();
		$order = M('GoodsOrder')->where(array("order_id" => $goods_order['order_id']))->find();
		$this->assign('order',$order);
		$this->assign('goods_order',$goods_order);
		$this->display(":comment");
	}
	
	
	//提交评价
	public function post_comment(){
		if(IS_POST){
			$content = trim(I('post.content'));
			$order_id = I('post.order_id');	
			$goods_id = I('post.goods_id');	
			$score = I('post.score');	
			$img = I('post.photos_url');
			$user = session('user');
			
			//print_r($img);die;
			
			if(empty($order_id)){
				$this->error('非法操作');
			}
			$order = M('GoodsOrder')->where(array('order_id'=>$order_id,'user_id'=>$user['id']))->find();
			
			if($order['shipping_status'] != 2){
				$this->error('订单还没收货'); //订单是否收货
			}
			
			if($content==''){
				$this->error('请填写评价'); 
			}
			if($score == '' || empty($score)){
				$this->error('请给商品打分'); 
			}
				
			$data['username'] = $user['user_nicename'];
			$data['avatar'] = $user['avatar'];
			$data['user_id'] = $user['id'];
			$data['ip_address'] = $user['last_login_ip'];
			$data['order_id'] = $order_id;
			$data['goods_id'] = $goods_id;
			$data['content'] = $content;
			$data['goods_rank'] = $score;
			$data['img'] = $img == '' ? '' : json_encode($img);
			$data['add_time'] = time();
			$goods = M('GoodsComment')->where(array('order_id'=>$order_id,'goods_id'=>$goods_id))->find();
			if($goods){
				$this->error('您已经评论过该商品了');
			}
			$r1 = M('GoodsComment')->add($data);
			$r2 = M('GoodsOrderSub')->where(array("order_id"=>$order_id,"goods_id"=>$goods_id))->save(array("is_comment"=>1));//修改商品已评论
			$r3 = M('Goods')->where(array("goods_id"=>$goods_id))->setInc('comment_count',1); //商品评论加一				
			
			$comment_count = M('GoodsOrderSub')->where(array("order_id"=>$order_id,"is_comment"=>0))->count();
			if($comment_count == 0){
				$r4 = M('GoodsOrder')->where(array("order_id"=>$order_id))->save(array("order_status"=>2)); //商品订单修改已完成
			}
			if($r1 && $r2 && $r3){
				$this->success('评价成功',U('Comment/GoodsComment/index',array('order_id'=>$order_id)));
			}
			//echo '<pre>';
			//print_r($content);
			//print_r($array);
			//echo '</pre>';
			//die;
		}
	}
	
}