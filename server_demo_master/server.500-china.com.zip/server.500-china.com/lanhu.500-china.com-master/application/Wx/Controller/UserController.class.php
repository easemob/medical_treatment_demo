<?php
namespace Wx\Controller;

use Common\Controller\AdminbaseController;

class UserController extends AdminbaseController{
	
	public function index(){
		
		
		$userlist = include SITE_PATH."/data/wx/userinfo.php";
		$this->assign('userlist',$userlist);
		$this->display(":User/index");
	}
	
	public function userinfo(){
		if(isset($_GET['user'])){
			$file = SITE_PATH.'plugins/wechat/wxuser.php';
			$arr = file_get_contents($file);
		
			$wx_dir = SITE_PATH."/data/wx/";
			if(!file_exists($wx_dir)){
			mkdir($wx_dir);
			}
			$wx_file=$wx_dir."userinfo.php";
			$result = file_put_contents($wx_file, "<?php\treturn array(" . stripslashes($arr) . ");");
			if($result!==false){
				$this->success("操作成功！");
			}else{
				$this->error("操作失败！");
			}
		}
		
	}
}