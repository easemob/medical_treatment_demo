<?php


namespace plugins\Wechat\Controller; //Demo插件英文名，改成你的插件英文就行了
use Api\Controller\PluginController;//插件控制器基类

class IndexController extends PluginController{
	
	function index(){
		//$plugin_demo_model=D("plugins://Demo/PluginDemo");//实例化自定义模型PluginDemo ,需要创建plugin_demo表
		//$plugin_demo_model->test();//调用自定义模型PluginDemo里的test方法
		
		//echo $obj->test();die;
		$t = D("plugins://Wechat/Wechatapi");
		$t->cache();
		
		
		$config=D("plugins");
		$r=$config->where("name='Wechat'")->find();
		$res = json_decode($r['config'],true);
		$appid = $res['appID'];
		$appsecret= $res['appsecret'];
		$token= $res['Token'];
		
		
		
		/*define("TOKEN",$token);
		$echostr = $_GET['echostr'];//随机字符串
		
		if(isset($_GET['echostr']))
		{
			$weapi->valid();
		}
		else
		{
			$weapi->responseMsg();
		}*/
		
		//$users_model=D("Users");//实例化Common模块下的Users模型
		//$users_model=D("Common/Users");//也可以这样实例化Common模块下的Users模型
		//$users=$users_model->limit(0,5)->select();
		
		//$this->assign("users",$users);
		
		$this->display(":index");
	}

}
