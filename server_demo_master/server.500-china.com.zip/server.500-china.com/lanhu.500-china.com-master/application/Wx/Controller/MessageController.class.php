<?php


namespace Wx\Controller;

use Common\Controller\AdminbaseController;

class MessageController extends AdminbaseController{
	
	protected $we_message;
	
	public function _initialize() {
		parent::_initialize();
		$this->we_message = D("Wechat_message");
		
	}
	
	public function index(){
		//$plugin_demo_model=D("plugins://Demo/PluginDemo");//实例化自定义模型PluginDemo ,需要创建plugin_demo表
		//$plugin_demo_model->test();//调用自定义模型PluginDemo里的test方法
		
		//echo $obj->test();die;
		/*$t = D("plugins://Wechat/Wechatapi");
		$t->cache();
		
		
		$config=D("plugins");
		$r=$config->where("name='Wechat'")->find();
		$res = json_decode($r['config'],true);
		$appid = $res['appID'];
		$appsecret= $res['appsecret'];
		$token= $res['Token'];*/						  
		  
		  foreach($a as $key=>$v){
			// echo var_export($v['content'],true);
			  
		  }
		  //print_r($a);die;
		  //die;
		//  echo $a['name'];
		  $b = var_export($a['content'],true);
		 // print_r($a['content']);die;
		  //print_r($test);die;
		 // print_r($a);die;
		//die;
		
		
		$wx_message = $this->we_message->select();
		
		
		
		$this->assign('wx_message',$wx_message);
		$this->display(":Message/index");
	}
	
	public function add(){
		$this->display();
	}
	
	public function add_post(){
		if(IS_POST){
			if(empty($_POST['name'])){
				$this->error("关键词不能为空");
			}
											
			if($_POST['type']==1){
				$json['name'] = trim(I('post.name'));
				$json['type'] = I('post.type');
				$json['description'] = I('post.description');
				$data['content'] = json_encode($json);
			}else if($_POST['type']==2){
				$name = trim(I('post.name'));
				
				/*if(!empty(I('post.title'))){
					$json['Title'] = I('post.title');
					$json['Url'] = trim(I('post.url'));
					$json['Description'] = I('post.description');
					$json['PicUrl'] = sp_get_image_preview_url(sp_asset_relative_url($_POST['thumb']));
					$data['content'] = json_encode(array('name'=>$name,'content'=>array($json)));
				}
				if(!empty(I('post.title2'))){
					$json2['Title'] = I('post.title2');
					$json2['Url'] = trim(I('post.url2'));
					$json2['Description'] = I('post.description2');
					$json2['PicUrl'] = sp_get_image_preview_url(sp_asset_relative_url($_POST['thumb2']));
					$data['content'] = json_encode(array('name'=>$name,'content'=>array($json,$json2)));
				}*/
				
					
				
				//$dataList[] = array('title'=>'thinkphp','description'=>'thinkphp@gamil.com');
				//$dataList[] = array('title'=>'onethink','description'=>'onethink@gamil.com');	
				//print_r($dataList);die;
			
				foreach(I('post.thumb') as $v){
					$pic[] = sp_get_image_preview_url(sp_asset_relative_url($v));
				}
				
				$arrlist=array(I('post.title'),I('post.description'),$pic,I('post.url'));
			
				$p1=array_column($arrlist,0);
				$p2=array_column($arrlist,1);
				$p3=array_column($arrlist,2);
				$p4=array_column($arrlist,3);
				$p5=array_column($arrlist,4);
				
				$key=array('Title','Description','PicUrl','Url');
			
				$json1=array_combine($key,$p1);
				$json2=array_combine($key,$p2);
				$json3=array_combine($key,$p3);
				$json4=array_combine($key,$p4);
				$json5=array_combine($key,$p5);
				
				if($json2!==false && $json3==false && $json4==false && $json5==false){
					$data['content'] = json_encode(array('name'=>$name,'content'=>array($json1,$json2)));
				}
				elseif($json2!==false && $json3!==false && $json4==false && $json5==false){
					$data['content'] = json_encode(array('name'=>$name,'content'=>array($json1,$json2,$json3)));
				}
				elseif($json2!==false && $json3!==false && $json4!==false && $json5==false){
					$data['content'] = json_encode(array('name'=>$name,'content'=>array($json1,$json2,$json3,$json4)));
				}
				elseif($json2!==false && $json3!==false && $json4!==false && $json5!==false){
					$data['content'] = json_encode(array('name'=>$name,'content'=>array($json1,$json2,$json3,$json4,$json5)));
				}else{
					$data['content'] = json_encode(array('name'=>$name,'content'=>array($json1)));
				}
				
				
			}
		
			$data['name'] = trim(I('post.name'));
			$data['type'] = I('post.type');
			$result = $this->we_message->add($data);
			if($result){
				D('Wechatapi')->message_cache();
				D('Wechatapi')->message_pic_cache();
				$this->success("添加成功");
			}else{
				$this->error("添加失败");
			}
		}
	}
	
	public function edit(){
		$id = I('get.id',0,'intval');
		$message = $this->we_message->where(array("id"=>$id))->find();
		$content = json_decode($message['content'],true);		
		$i=0;
		foreach($content['content'] as $key=>$v):			
			$content['content'][$key]['num']=$i;
			$i++;
		endforeach;	
		
		$this->assign('message',$message);
		$this->assign('content',$content);
		$this->display();
	}
	
	public function edit_post(){		
		if(IS_POST){
			$id = I('post.id');
			if(empty($_POST['name'])){
				$this->error("关键词不能为空");
			}
											
			if($_POST['type']==1){
				$json['name'] = trim(I('post.name'));
				//$json['type'] = I('post.type');
				$json['description'] = I('post.description');
				$data['content'] = json_encode($json);
			}else if($_POST['type']==2){
				$name = trim(I('post.name'));
											
				foreach(I('post.thumb') as $v){
					$pic[] = sp_get_image_preview_url(sp_asset_relative_url($v));
				}
				
				$arrlist=array(I('post.title'),I('post.description'),$pic,I('post.url'));
			
				$p1=array_column($arrlist,0);
				$p2=array_column($arrlist,1);
				$p3=array_column($arrlist,2);
				$p4=array_column($arrlist,3);
				$p5=array_column($arrlist,4);
				
				$key=array('Title','Description','PicUrl','Url');
			
				$json1=array_combine($key,$p1);
				$json2=array_combine($key,$p2);
				$json3=array_combine($key,$p3);
				$json4=array_combine($key,$p4);
				$json5=array_combine($key,$p5);
				
				if($json2!==false && $json3==false && $json4==false && $json5==false){
					$data['content'] = json_encode(array('name'=>$name,'content'=>array($json1,$json2)));
				}
				elseif($json2!==false && $json3!==false && $json4==false && $json5==false){
					$data['content'] = json_encode(array('name'=>$name,'content'=>array($json1,$json2,$json3)));
				}
				elseif($json2!==false && $json3!==false && $json4!==false && $json5==false){
					$data['content'] = json_encode(array('name'=>$name,'content'=>array($json1,$json2,$json3,$json4)));
				}
				elseif($json2!==false && $json3!==false && $json4!==false && $json5!==false){
					$data['content'] = json_encode(array('name'=>$name,'content'=>array($json1,$json2,$json3,$json4,$json5)));
				}else{
					$data['content'] = json_encode(array('name'=>$name,'content'=>array($json1)));
				}
				
				
			}
		
			$data['name'] = trim(I('post.name'));
			//$data['type'] = I('post.type');
			$result = $this->we_message->where("id=$id")->save($data);
			if($result!==false){
				D('Wechatapi')->message_cache();
				D('Wechatapi')->message_pic_cache();
				$this->success("保存成功");
			}else{
				$this->error("保存失败");
			}
		}
	}
	
	public function delete(){
		if(isset($_GET['id'])){
			$id = I("get.id",0,'intval');
			$result = $this->we_message->where(array('id'=>$id))->delete();
			if($result!==false){
				$this->success("删除成功！");
			}else{
				$this->error("删除失败！");
			}
		}
		if(isset($_POST['ids'])){
			$ids = I('post.ids/a');			
			if ($this->we_message->where(array('id'=>array('in',$ids)))->delete()!==false) {
				$this->success("删除成功！");
			} else {
				$this->error("删除失败！");
			}
		}
	}

}
