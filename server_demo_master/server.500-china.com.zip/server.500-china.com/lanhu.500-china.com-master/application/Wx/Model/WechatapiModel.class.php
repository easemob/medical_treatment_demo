<?php

namespace Wx\Model;//Demo插件英文名，改成你的插件英文就行了
use Common\Model\CommonModel;//继承CommonModel
class WechatapiModel extends CommonModel{ //Demo插件英文名，改成你的插件英文就行了,插件数据表最好加个plugin前缀再加表名,这个类就是对应“表前缀+plugin_demo”表
		
	/*public function cache(){
		$config=D("plugins");
		$r=$config->where("name='Wechat'")->find();
		$res = json_decode($r['config'],true);
		$wxall = array();
		foreach($res as $key=>$v){
			$wxall[$key] = $v;
		}
		$wx_dir=SITE_PATH."/data/wx/";
		if(!file_exists($wx_dir)){
			mkdir($wx_dir);
		}
		$wx_file=$wx_dir."api.php";

		file_put_contents($wx_file, "<?php\treturn " . stripslashes(var_export($wxall, true)) . ";");
	}*/
	
	public function message_cache(){
		$message = D('Wechat_message');
		$res = $message->where("type=1")->select();
		
		$wxmessage = array();
		
		foreach($res as $key=>$v){
			$content = json_decode(iconv('GB2312','UTF-8',$v['content']),true);			
			$wxmessage[$key] = $content;			
		}
		
		$wx_dir=SITE_PATH."/data/wx/";
		if(!file_exists($wx_dir)){
			mkdir($wx_dir);
		}
		$wx_file=$wx_dir."message.php";
		file_put_contents($wx_file, "<?php\treturn " . stripslashes(var_export($wxmessage, true)) . ";");
		
	}

	public function message_pic_cache(){
		$message = D('Wechat_message');
		$res = $message->where("type=2")->select();
		
		$wxmessage = array();
		
		foreach($res as $key=>$v){
			$content = json_decode(iconv('GB2312','UTF-8',$v['content']),true);			
			$wxmessage[$key] = $content;			
		}
		
		$wx_dir=SITE_PATH."/data/wx/";
		if(!file_exists($wx_dir)){
			mkdir($wx_dir);
		}
		$wx_file=$wx_dir."messagepic.php";
		file_put_contents($wx_file, "<?php\treturn " . stripslashes(var_export($wxmessage, true)) . ";");
		
	} 	
	
}