<?php
/**
 * 配置文件
 */
return array(
    'DB_TYPE' => 'mysql',
    'DB_HOST' => 'localhost',
    'DB_NAME' => 'thinkcmf_lanhu',
    'DB_USER' => 'root',
    'DB_PWD' => 'GhWlJb9weX4fi3qS',
    'DB_PORT' => '3306',
    'DB_PREFIX' => 'cmf_',
    //密钥
    "AUTHCODE" => 'xQ6s5tkrXCGIrFGExx',
    //cookies
    "COOKIE_PREFIX" => 'wlCmJs_',
);
