<?php	return array (
  'tag/华为' => 'portal/tag/index?id=1',
  'tag/黑客' => 'portal/tag/index?id=2',
  'tag/HTC' => 'portal/tag/index?id=3',
  'tag/互联网' => 'portal/tag/index?id=4',
  'tag/黑莓' => 'portal/tag/index?id=5',
  'tag/黑科技' => 'portal/tag/index?id=6',
  'tag/Nike' => 'portal/tag/index?id=7',
);