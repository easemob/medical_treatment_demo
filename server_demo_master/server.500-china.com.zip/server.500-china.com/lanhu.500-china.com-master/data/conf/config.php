<?php	return array (
  'SP_SITE_ADMIN_URL_PASSWORD' => '',
  'SP_DEFAULT_THEME' => 'simplebootx',
  'DEFAULT_THEME' => 'simplebootx',
  'SP_ADMIN_STYLE' => 'flat',
  'URL_MODEL' => '1',
  'URL_HTML_SUFFIX' => '',
  'COMMENT_NEED_CHECK' => 0,
  'COMMENT_TIME_INTERVAL' => 60,
  'MOBILE_TPL_ENABLED' => 0,
  'HTML_CACHE_ON' => false,
  'FILE_UPLOAD_TYPE' => 'Qiniu',
  'UPLOAD_TYPE_CONFIG' => 
  array (
    'accessKey' => '5w2sPc2GIDfgdxUo4KWa9G-yHQ4gGxND0VM7G-EM',
    'secretKey' => 'fy2rdLH42Na7mP_fWlO1FOJ6ye4bSf_-p7H7D98E',
    'upHost' => 'http://up-z2.qiniu.com',
    'domain' => 'qiniu.500-china.com',
    'bucket' => 'caesarxu',
  ),
);